# MasterCube x86-64 Resource-Optimized Implementation

This directory contains the x86-64 implementation used for the Word report's
`Resource-optimized` implementation type.

Compile command:

```sh
gcc -Os -march=x86-64 -mavx2 -flto \
  -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra
```

With this command, `mastercube.h` selects the AVX2 entry points while GCC
optimizes for smaller code size.
