#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

CC="${CC:-gcc}"
SECONDS_PER_POINT="${SECONDS_PER_POINT:-3}"
OUT_DIR="${OUT_DIR:-$PKG_ROOT/data/run_$(date -u +%Y%m%d_%H%M%S)}"
BUILD_DIR="${BUILD_DIR:-$PKG_ROOT/build/run_openssl3s}"
PIN_CPU="${PIN_CPU:-}"

BENCH_SRC="$SCRIPT_DIR/openssl_style_3s_cpb_bench.c"
STUB_INCLUDE="$SCRIPT_DIR/openssl_stub"
SRC64="$PKG_ROOT/64/Optimized_Implementation"
SRC32="$PKG_ROOT/32/Optimized_Implementation"

BASE_CFLAGS=(-O3 -std=c11 -Wall -Wextra -Wno-unused-function -Wno-unused-variable -D_GNU_SOURCE -D__USE_MINGW_ANSI_STDIO=1 -I"$STUB_INCLUDE")

mkdir -p "$BUILD_DIR" "$OUT_DIR/raw" "$OUT_DIR/summary"

run_prefix=()
if [[ -n "$PIN_CPU" ]] && command -v taskset >/dev/null 2>&1; then
    run_prefix=(taskset -c "$PIN_CPU")
fi

build_bench() {
    local label="$1"
    local src_dir="$2"
    local exe="$3"
    shift 3
    local flags=("$@")
    echo "[build] $label"
    "$CC" "${BASE_CFLAGS[@]}" -I"$src_dir" "${flags[@]}" \
        "$BENCH_SRC" "$src_dir"/MasterCube-*.c -o "$exe"
}

run_bench() {
    local label="$1"
    local exe="$2"
    local raw="$OUT_DIR/raw/${label}.csv"
    echo "[bench] $label seconds=$SECONDS_PER_POINT"
    "${run_prefix[@]}" "$exe" "$label" "$SECONDS_PER_POINT" > "$raw"
}

build_bench round4_x86_64_plain "$SRC64" "$BUILD_DIR/bench_round4_x86_64_plain"
build_bench round4_x86_64_sse42 "$SRC64" "$BUILD_DIR/bench_round4_x86_64_sse42" -msse4.2
build_bench round4_x86_64_avx2 "$SRC64" "$BUILD_DIR/bench_round4_x86_64_avx2" -mavx2
build_bench round4_x86_64_avx512 "$SRC64" "$BUILD_DIR/bench_round4_x86_64_avx512" -mavx512f -mavx512bw -mavx512vl
build_bench round4_x86_32_plain "$SRC32" "$BUILD_DIR/bench_round4_x86_32_plain" -m32

run_bench round4_x86_64_plain "$BUILD_DIR/bench_round4_x86_64_plain"
run_bench round4_x86_64_sse42 "$BUILD_DIR/bench_round4_x86_64_sse42"
run_bench round4_x86_64_avx2 "$BUILD_DIR/bench_round4_x86_64_avx2"
run_bench round4_x86_64_avx512 "$BUILD_DIR/bench_round4_x86_64_avx512"
run_bench round4_x86_32_plain "$BUILD_DIR/bench_round4_x86_32_plain"

python3 - "$OUT_DIR" <<'PY'
import csv
import sys
from pathlib import Path

out_dir = Path(sys.argv[1])
raw_dir = out_dir / "raw"
summary_dir = out_dir / "summary"
summary_dir.mkdir(parents=True, exist_ok=True)

rows = []
for path in sorted(raw_dir.glob("*.csv")):
    with path.open(newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            row["source_file"] = path.name
            rows.append(row)

combined = summary_dir / "combined_raw.csv"
with combined.open("w", newline="") as f:
    if rows:
        fields = list(rows[0].keys())
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

lengths = sorted({int(r["msg_bytes"]) for r in rows})
wide = summary_dir / "openssl3s_cpb_wide.csv"
with wide.open("w", newline="") as f:
    fields = ["platform", "algorithm", "impl"] + [f"{n}B" for n in lengths]
    writer = csv.DictWriter(f, fieldnames=fields)
    writer.writeheader()
    for label in sorted({r["label"] for r in rows}):
        platform = "x86-32" if "x86_32" in label else "x86-64"
        impl = label.rsplit("_", 1)[-1].upper()
        impl = {"PLAIN": "Plain", "SSE42": "SSE4.2", "AVX2": "AVX2", "AVX512": "AVX512"}.get(impl, impl)
        for digest in sorted({int(r["digest_bits"]) for r in rows if r["label"] == label}):
            rec = {"platform": platform, "algorithm": f"MasterCube-{digest}", "impl": impl}
            for n in lengths:
                match = [
                    r for r in rows
                    if r["label"] == label and int(r["digest_bits"]) == digest and int(r["msg_bytes"]) == n
                ]
                rec[f"{n}B"] = f"{float(match[0]['cycles_per_byte']):.6f}" if match else ""
            writer.writerow(rec)

print(f"combined raw: {combined}")
print(f"wide summary: {wide}")
PY

echo "Done: $OUT_DIR"
