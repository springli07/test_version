#include <cpuid.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <x86intrin.h>

#include "mastercube.h"

typedef int (*hash_fn)(const unsigned char *, unsigned long long, unsigned char *);

struct bench_case {
    int digest_bits;
    int digest_bytes;
    hash_fn fn;
};

static volatile uint32_t bench_sink = 0;

static uint64_t xorshift64(uint64_t *state)
{
    uint64_t x = *state;
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    *state = x;
    return x;
}

static void fill_message(unsigned char *message, size_t bytes)
{
    uint64_t seed = 0x243f6a8885a308d3ULL;
    for (size_t i = 0; i < bytes; ++i)
        message[i] = (unsigned char)(xorshift64(&seed) >> 56);
}

static uint32_t digest_fold(const unsigned char *digest, int digest_bytes)
{
    uint32_t x = 2166136261u;
    for (int i = 0; i < digest_bytes; ++i) {
        x ^= (uint32_t)digest[i];
        x *= 16777619u;
    }
    return x;
}

static inline void serialize_cpuid(void)
{
    unsigned int a, b, c, d;
    __cpuid(0, a, b, c, d);
}

static inline uint64_t cycle_start(void)
{
    serialize_cpuid();
    return __rdtsc();
}

static inline uint64_t cycle_end(void)
{
    unsigned int aux;
    uint64_t t = __rdtscp(&aux);
    serialize_cpuid();
    return t;
}

static double now_seconds(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC_RAW, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

static void run_one(const char *label,
                    const struct bench_case *bc,
                    const unsigned char *message,
                    size_t bytes,
                    double seconds)
{
    unsigned char digest[128];
    unsigned long long bits = (unsigned long long)bytes * 8ULL;
    uint64_t iterations = 0;

    if (bc->fn(message, bits, digest) != 0) {
        fprintf(stderr, "hash failed before timing digest=%d bytes=%zu\n",
                bc->digest_bits, bytes);
        exit(5);
    }
    bench_sink ^= digest_fold(digest, bc->digest_bytes);

    double t0 = now_seconds();
    uint64_t c0 = cycle_start();
    for (;;) {
        if (bc->fn(message, bits, digest) != 0) {
            fprintf(stderr, "hash failed digest=%d bytes=%zu\n",
                    bc->digest_bits, bytes);
            exit(5);
        }
        bench_sink ^= digest_fold(digest, bc->digest_bytes);
        ++iterations;

        if ((iterations & 0xffu) == 0) {
            double elapsed = now_seconds() - t0;
            if (elapsed >= seconds)
                break;
        }
    }
    uint64_t c1 = cycle_end();
    double elapsed = now_seconds() - t0;
    double cpb = (double)(c1 - c0) / ((double)iterations * (double)bytes);
    double ops_per_sec = (double)iterations / elapsed;

    printf("%s,%d,%zu,%.6f,%" PRIu64 ",%" PRIu64 ",%.6f,%.6f,%u\n",
           label,
           bc->digest_bits,
           bytes,
           elapsed,
           iterations,
           c1 - c0,
           cpb,
           ops_per_sec,
           (unsigned)bench_sink);
}

int main(int argc, char **argv)
{
    const char *label = argc >= 2 ? argv[1] : "openssl_style";
    double seconds = argc >= 3 ? atof(argv[2]) : 3.0;
    static const size_t lengths[] = {16, 64, 256, 1024, 4096, 16384, 65536};
    static const struct bench_case cases[] = {
        {512, 64, MasterCube512},
        {768, 96, MasterCube768},
        {1024, 128, MasterCube1024},
    };
    unsigned char *message = (unsigned char *)malloc(65536);

    if (message == NULL) {
        fprintf(stderr, "malloc failed\n");
        return 2;
    }
    if (seconds <= 0.0) {
        fprintf(stderr, "seconds must be positive\n");
        free(message);
        return 2;
    }

    fill_message(message, 65536);

    printf("label,digest_bits,msg_bytes,elapsed_seconds,iterations,cycles,cycles_per_byte,ops_per_second,sink\n");
    for (size_t ci = 0; ci < sizeof(cases) / sizeof(cases[0]); ++ci) {
        for (size_t li = 0; li < sizeof(lengths) / sizeof(lengths[0]); ++li)
            run_one(label, &cases[ci], message, lengths[li], seconds);
    }

    free(message);
    return 0;
}
