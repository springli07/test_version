#ifndef MASTERCUBE_H
#define MASTERCUBE_H

#ifdef __cplusplus
extern "C"
{
#endif

    /// @brief Input message to get message digests of specified lengths
    /// @param message The base address of message
    /// @param messagebitlen The total BITS of message
    /// @param digest The base address of digest
    /// @return 0 for success, others for error

    #if defined (__AVX512F__) || defined (__AVX512BW__)
        #define  MasterCube512  MasterCube512_avx512_256
        #define  MasterCube768  MasterCube768_avx512_256
        #define MasterCube1024 MasterCube1024_avx512_256
    #elif defined (__AVX2__)
        #define  MasterCube512  MasterCube512_avx2
        #define  MasterCube768  MasterCube768_avx2
        #define MasterCube1024 MasterCube1024_avx2
    #elif defined (__SSE4_2__)
        #define  MasterCube512  MasterCube512_sse
        #define  MasterCube768  MasterCube768_sse
        #define MasterCube1024 MasterCube1024_sse
    #else
        #define  MasterCube512  MasterCube512_plain
        #define  MasterCube768  MasterCube768_plain
        #define MasterCube1024 MasterCube1024_plain
    #endif

    int  MasterCube512(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
    int  MasterCube768(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
    int MasterCube1024(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);

#ifdef __cplusplus
}
#endif

#endif
