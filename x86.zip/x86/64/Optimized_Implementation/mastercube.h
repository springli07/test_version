#ifndef MASTERCUBE_H
#define MASTERCUBE_H

#ifdef __cplusplus
extern "C"
{
#endif

    /*
     * Generic API selection:
     * - MCUBE_USE_SSE2NEON selects the SSE implementation translated through sse2neon on ARM.
     * - x86 paths keep the original ISA-based dispatch order.
     */
    #if defined(MCUBE_USE_SSE2NEON)
        #define  MasterCube512  MasterCube512_sse
        #define  MasterCube768  MasterCube768_sse
        #define MasterCube1024 MasterCube1024_sse
    #elif defined (__AVX512F__) && defined (__AVX512BW__) && defined (__AVX512VL__)
        #define  MasterCube512  MasterCube512_avx512_256
        #define  MasterCube768  MasterCube768_avx512_256
        #define MasterCube1024 MasterCube1024_avx512_256
    #elif defined (__AVX2__)
        #define  MasterCube512  MasterCube512_avx2
        #define  MasterCube768  MasterCube768_avx2
        #define MasterCube1024 MasterCube1024_avx2
    #elif defined (__SSE4_2__)
        #define  MasterCube512  MasterCube512_sse
        #define  MasterCube768  MasterCube768_sse
        #define MasterCube1024 MasterCube1024_sse
    #else
        #define  MasterCube512  MasterCube512_plain
        #define  MasterCube768  MasterCube768_plain
        #define MasterCube1024 MasterCube1024_plain
    #endif

    int  MasterCube512(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
    int  MasterCube768(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
    int MasterCube1024(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);

    int  MasterCube512_plain(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
    int  MasterCube768_plain(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
    int MasterCube1024_plain(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);

#if !defined(MCUBE_USE_SSE2NEON) && (defined(__aarch64__) || defined(__arm64__))
    int  MasterCube512_arm64_plain(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
    int  MasterCube768_arm64_plain(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
    int MasterCube1024_arm64_plain(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
#endif

    int  MasterCube512_sse(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
    int  MasterCube768_sse(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
    int MasterCube1024_sse(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);

#if defined(MCUBE_USE_SSE2NEON) && defined(MCUBE_ENABLE_ARM64_NEON_B003)
    int  MasterCube512_neon_b003(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
#endif

#if defined(MCUBE_USE_SSE2NEON) && (defined(__aarch64__) || defined(__arm64__))
    int  MasterCube512_arm64_neon(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
    int  MasterCube768_arm64_neon(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
    int MasterCube1024_arm64_neon(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
#endif

    int  MasterCube512_avx2(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
    int  MasterCube768_avx2(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
    int MasterCube1024_avx2(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);

    int  MasterCube512_avx512_256(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
    int  MasterCube768_avx512_256(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
    int MasterCube1024_avx512_256(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);

#ifdef __cplusplus
}
#endif

#endif
