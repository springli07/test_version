# MasterCube Round4 x86 OpenSSL-Style 3s CPB Report

Generated from the Round4 x86 benchmark data in this package.

## Benchmark Method

- Benchmark driver: `tools/openssl_style_3s_cpb_bench.c`.
- Timing method: serialized `RDTSC/RDTSCP` on x86.
- Metric: CPU cycles per byte (`cycles_per_byte`).
- Time window: 3 seconds per digest/length point.
- Message lengths measured by the benchmark: 16B, 64B, 256B, 1KB, 4KB, 16KB, and 64KB.
- The publication-style table below shows 16B, 64B, 256B, 1KB, 16KB, and 64KB. The 4KB point remains in the CSV data files.

## Result Table

All results are reported in CPU cycles per byte.

| Platform | Algorithm | Impl. | 16B | 64B | 256B | 1KB | 16KB | 64KB |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| x86-64 | MasterCube-512 | Plain | 332.39 | 81.65 | 59.62 | 43.88 | 42.70 | 43.58 |
| x86-64 | MasterCube-512 | SSE4.2 | 180.51 | 45.99 | 32.94 | 23.42 | 21.52 | 21.44 |
| x86-64 | MasterCube-512 | AVX2 | 95.38 | 23.90 | 15.89 | 11.43 | 10.64 | 10.45 |
| x86-64 | MasterCube-512 | AVX512 | 87.14 | 21.95 | 14.33 | 10.31 | 9.59 | 9.84 |
| x86-64 | MasterCube-768 | Plain | 666.90 | 166.31 | 80.87 | 64.49 | 59.63 | 56.99 |
| x86-64 | MasterCube-768 | SSE4.2 | 348.93 | 87.70 | 43.73 | 34.48 | 30.20 | 30.58 |
| x86-64 | MasterCube-768 | AVX2 | 181.31 | 45.43 | 21.22 | 16.91 | 14.67 | 14.52 |
| x86-64 | MasterCube-768 | AVX512 | 165.86 | 40.30 | 18.65 | 14.68 | 13.42 | 13.27 |
| x86-64 | MasterCube-1024 | Plain | 1021.99 | 332.16 | 143.28 | 104.98 | 90.93 | 90.75 |
| x86-64 | MasterCube-1024 | SSE4.2 | 551.75 | 180.74 | 75.91 | 54.40 | 48.05 | 47.67 |
| x86-64 | MasterCube-1024 | AVX2 | 257.85 | 84.03 | 36.28 | 26.12 | 22.11 | 22.09 |
| x86-64 | MasterCube-1024 | AVX512 | 244.35 | 77.85 | 33.13 | 24.18 | 20.65 | 20.54 |
| x86-32 | MasterCube-512 | Plain | 1288.76 | 325.49 | 242.20 | 174.64 | 163.93 | 166.25 |
| x86-32 | MasterCube-768 | Plain | 2397.89 | 585.21 | 284.22 | 229.29 | 212.49 | 211.50 |
| x86-32 | MasterCube-1024 | Plain | 3796.99 | 1240.25 | 532.70 | 393.13 | 356.16 | 342.98 |

## Recorded Data

- x86-64 raw CSV: `data/64/raw/round4_x86_64_plain.csv`, `data/64/raw/round4_x86_64_sse42.csv`, `data/64/raw/round4_x86_64_avx2.csv`, `data/64/raw/round4_x86_64_avx512.csv`.
- x86-64 summary CSV: `data/64/summary/round4_cpb_wide.csv`.
- x86-32 raw CSV: `data/32/raw/round4_x86_32_plain.csv`.
- x86-32 summary CSV: `data/32/summary/x86_32_plain_cpb_wide.csv`.

## Reproduction

```bash
cd software/Implementations/optmized_round4/x86
SECONDS_PER_POINT=3 ./tools/run_openssl3s_x86.sh
```

Use `PIN_CPU=<cpu-id>` to pin the benchmark process when desired.
