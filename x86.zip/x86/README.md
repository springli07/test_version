# MasterCube Round4 x86 Implementation

This package contains the Round4 x86 implementations and the OpenSSL-style 3-second CPU cycles/byte benchmark used for the x86 results.

## Layout

- `64/Optimized_Implementation/`: x86-64 implementation with Plain, SSE4.2, AVX2, and AVX512 entry points selected by compiler flags.
- `32/Optimized_Implementation/`: x86-32 Plain implementation.
- `tools/openssl_style_3s_cpb_bench.c`: benchmark driver. It uses serialized `RDTSC/RDTSCP` and reports CPU cycles per byte.
- `tools/run_openssl3s_x86.sh`: convenience script that builds and runs all x86 Round4 benchmark variants.
- `data/64/`: recorded x86-64 raw and summary CSV data.
- `data/32/`: recorded x86-32 raw and summary CSV data.
- `REPORT_OPENSSL3S_CPB.md`: benchmark report.

## Build And Run

Run all x86 Round4 OpenSSL-style 3-second benchmarks:

```bash
cd software/Implementations/optmized_round4/x86
SECONDS_PER_POINT=3 ./tools/run_openssl3s_x86.sh
```

Optional environment variables:

- `CC=gcc`: C compiler.
- `SECONDS_PER_POINT=3`: seconds per digest/length benchmark point.
- `PIN_CPU=0`: pin benchmark execution to one CPU with `taskset -c`.
- `OUT_DIR=/path/to/output`: output directory for raw and summary CSV.
- `BUILD_DIR=/path/to/build`: build directory.

Manual examples:

```bash
# x86-64 Plain
gcc -O3 -std=c11 -D_GNU_SOURCE -Itools/openssl_stub -I64/Optimized_Implementation   tools/openssl_style_3s_cpb_bench.c 64/Optimized_Implementation/MasterCube-*.c   -o build/bench_x86_64_plain
./build/bench_x86_64_plain round4_x86_64_plain 3

# x86-64 SSE4.2
gcc -O3 -std=c11 -D_GNU_SOURCE -Itools/openssl_stub -I64/Optimized_Implementation -msse4.2   tools/openssl_style_3s_cpb_bench.c 64/Optimized_Implementation/MasterCube-*.c   -o build/bench_x86_64_sse42
./build/bench_x86_64_sse42 round4_x86_64_sse42 3

# x86-64 AVX2
gcc -O3 -std=c11 -D_GNU_SOURCE -Itools/openssl_stub -I64/Optimized_Implementation -mavx2   tools/openssl_style_3s_cpb_bench.c 64/Optimized_Implementation/MasterCube-*.c   -o build/bench_x86_64_avx2
./build/bench_x86_64_avx2 round4_x86_64_avx2 3

# x86-64 AVX512
gcc -O3 -std=c11 -D_GNU_SOURCE -Itools/openssl_stub -I64/Optimized_Implementation   -mavx512f -mavx512bw -mavx512vl   tools/openssl_style_3s_cpb_bench.c 64/Optimized_Implementation/MasterCube-*.c   -o build/bench_x86_64_avx512
./build/bench_x86_64_avx512 round4_x86_64_avx512 3

# x86-32 Plain, requires gcc multilib / 32-bit libc
gcc -m32 -O3 -std=c11 -D_GNU_SOURCE -Itools/openssl_stub -I32/Optimized_Implementation   tools/openssl_style_3s_cpb_bench.c 32/Optimized_Implementation/MasterCube-*.c   -o build/bench_x86_32_plain
./build/bench_x86_32_plain round4_x86_32_plain 3
```

## OpenSSL-Style 3s CPB Table

All values are CPU cycles per byte. The benchmark uses 3 seconds per point and reports the measured `cycles_per_byte` from the CSV output.

| Platform | Algorithm | Impl. | 16B | 64B | 256B | 1KB | 16KB | 64KB |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| x86-64 | MasterCube-512 | Plain | 332.39 | 81.65 | 59.62 | 43.88 | 42.70 | 43.58 |
| x86-64 | MasterCube-512 | SSE4.2 | 180.51 | 45.99 | 32.94 | 23.42 | 21.52 | 21.44 |
| x86-64 | MasterCube-512 | AVX2 | 95.38 | 23.90 | 15.89 | 11.43 | 10.64 | 10.45 |
| x86-64 | MasterCube-512 | AVX512 | 87.14 | 21.95 | 14.33 | 10.31 | 9.59 | 9.84 |
| x86-64 | MasterCube-768 | Plain | 666.90 | 166.31 | 80.87 | 64.49 | 59.63 | 56.99 |
| x86-64 | MasterCube-768 | SSE4.2 | 348.93 | 87.70 | 43.73 | 34.48 | 30.20 | 30.58 |
| x86-64 | MasterCube-768 | AVX2 | 181.31 | 45.43 | 21.22 | 16.91 | 14.67 | 14.52 |
| x86-64 | MasterCube-768 | AVX512 | 165.86 | 40.30 | 18.65 | 14.68 | 13.42 | 13.27 |
| x86-64 | MasterCube-1024 | Plain | 1021.99 | 332.16 | 143.28 | 104.98 | 90.93 | 90.75 |
| x86-64 | MasterCube-1024 | SSE4.2 | 551.75 | 180.74 | 75.91 | 54.40 | 48.05 | 47.67 |
| x86-64 | MasterCube-1024 | AVX2 | 257.85 | 84.03 | 36.28 | 26.12 | 22.11 | 22.09 |
| x86-64 | MasterCube-1024 | AVX512 | 244.35 | 77.85 | 33.13 | 24.18 | 20.65 | 20.54 |
| x86-32 | MasterCube-512 | Plain | 1288.76 | 325.49 | 242.20 | 174.64 | 163.93 | 166.25 |
| x86-32 | MasterCube-768 | Plain | 2397.89 | 585.21 | 284.22 | 229.29 | 212.49 | 211.50 |
| x86-32 | MasterCube-1024 | Plain | 3796.99 | 1240.25 | 532.70 | 393.13 | 356.16 | 342.98 |

## Data Files

- `data/64/summary/round4_cpb_wide.csv`: x86-64 table data.
- `data/64/raw/`: x86-64 raw benchmark CSV files.
- `data/32/summary/x86_32_plain_cpb_wide.csv`: x86-32 table data.
- `data/32/raw/`: x86-32 raw benchmark CSV file.
