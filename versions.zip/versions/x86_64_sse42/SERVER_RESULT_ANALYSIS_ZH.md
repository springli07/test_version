# x86_64_sse42 服务器结果分析

## 为什么前一轮提升少

SSE4.2 版本使用 128-bit XMM 寄存器，一个 1536-bit state 要拆成 12 个 `__m128i`。前一轮主攻 `_core/_core_inverse` 内部的 state copy、final xor、`MixColumns` 和 swap 展开时，单点 helper 看起来有收益，但进入完整 `zip_prf` 后经常增加寄存器压力、代码体积或调度波动；512/1024 尤其容易在 16KB/64KB 固定长度退化。因此按 6/6 固定长度严格门禁只能保留早先 S001 的 768 `CrossMixs`。

本轮继续按 SSE 指令集逐行检查后，真正稳定的收益来自两个位置：一是 squeeze 输出路径，digest 已经写完后还会额外做一次未使用的 `transform(state)`；二是 512 的 `AddConstant`，把运行时 `_mm_set_epi64x + _mm_set1_epi16(rn)` 改成 18 轮对齐常量表后，可以补足 direct squeeze 在长消息上的不足。

## 保留

- S016 512-only direct squeeze + `AddConstant` 常量表：`MasterCube-512.c` 直接用 4 条 SSE store 输出 64 bytes，并把 `AddConstant` 改成 18 轮 `alignas(16)` 静态常量表。r21 512 speedup 为 `1.5082/1.4963/1.1978/1.0664/1.0259/1.0244`，保留。
- S013 768-only direct squeeze：`MasterCube-768.c` 用 SSE store 直接输出 96 bytes，并删除最后一次无用 transform。r41 768 speedup 为 `1.5604/1.5584/1.2655/1.0789/1.0100/1.0032`，保留。
- S014 1024-only skip final squeeze transform：`MasterCube-1024.c` 只在还有下一个输出 block 时执行 `transform(state)`。r41 1024 speedup 为 `1.3382/1.2381/1.1371/1.0613/1.0049/1.0084`，保留。

## 拒绝

- S009 state copy、S010 final xor、S011 `MixColumns` 展开、S012 inverse swap 展开：r21/r41 或 digest-only 复测后至少一个固定长度 speedup 不大于 1。
- S013 full direct squeeze：1024 的 16KB/64KB 退化。
- S013 512/768 direct squeeze：512 的 16KB/64KB r41 退化；拆出 768-only 后保留。
- S014 full skip-final-transform：512 长消息退化；拆出 1024-only 后保留。
- S014 768 skip-final-transform：可加速，但不如 S013 768 direct squeeze，因此不作为 768 最终形态。
- S015 512-only direct squeeze：短消息加速明显，但 r21 512 的 16KB/64KB 为 `0.9992/0.9933`，单独不保留；作为 S016 的一部分与 512-only `AddConstant` 常量表组合后保留。
- S017 1024 direct squeeze：短消息小幅提升，但 r21 1024 的 1KB/16KB/64KB 为 `0.9897/0.9985/0.9941`，平均不如 S014，拒绝。

## 最终结果

- 语义：`version_results/server_sse42_after_S016_retained_semantic50000/semantic_kat_random.log`，512/768/1024 均 `KAT_2_12 PASS` 和 `RANDOM PASS`。
- pair r21：`version_results/server_sse42_after_S016_retained_vs_reference_pair_r21/pair_cycles_summary.csv`。

固定长度顺序：`16B/64B/256B/1KB/16KB/64KB`。

- 512：`1.4874/1.5113/1.1793/1.0770/1.0189/1.0171`。
- 768：`1.5797/1.6052/1.2804/1.0859/1.0040/0.9994`。
- 1024：`1.3053/1.2213/1.1292/1.0492/1.0046/0.9990`。

顶层 `optimized_versions/x86_64_sse42` 交付目录同步 S016 后，pair r21 为：512 `1.5375/1.5002/1.2018/1.0807/1.0224/1.0182`；768 `1.5515/1.5897/1.2912/1.0873/1.0015/1.0048`；1024 `1.3027/1.2279/1.1379/1.0489/1.0020/1.0078`。
