﻿# x86_64_sse42 修改日志

## 2026-06-13

- 初始化 Round2 独立目录。
- 建立 SSE baseline：`KAT_2_12 + random 10000` 通过，记录 16B、64B、256B、1KB、16KB、64KB 的 CPU cycles/byte。
- 完成 SSE baseline 函数拆分 profile：主要耗时在 `zip_prf/_core/_core_inverse`，辅助函数中 `MixRows` 最大，其次是 `CrossMixs/ShiftRows/MixColumns`。
- S001 `CrossMixs` direct-register 候选：把 SSE `CrossMixs` 的 `tmp[12] + memcpy + loop` 改成 12 个 `__m128i` 局部寄存器直接计算。
  - 全量候选语义通过 `KAT_2_12 + random 10000`。
  - 512：64KB 从 `15.355843` 到 `15.823231` cycles/byte，退化，已回退。
  - 768：6/6 个长度全部加速，保留。
  - 1024：16KB 从 `35.626203` 到 `35.812747` cycles/byte，退化，已回退。
  - 当前保留状态：仅 `MasterCube-768.c` 保留 S001；`MasterCube-512.c`、`MasterCube-1024.c` 保持 baseline。
  - 部分保留版已通过 `KAT_2_12 + random 50000`。
- S002 `MixRows` fixed shuffle 候选：把 SSE `mix_row_32x4` 的 `ror128_optimized(x, 4/12)` 直接改成 `_mm_shuffle_epi32`。
  - 全量候选语义通过 `KAT_2_12 + random 10000`。
  - 全量候选相对 S001 部分保留版：512 的 256B/16KB 退化，768 的 16B 轻微退化，1024 的 256B/1KB/64KB 退化。
  - 拆成 768-only 后仍退化：768 的 16B `427.767311 -> 433.731987` cycles/byte，64B `102.965580 -> 106.649883` cycles/byte。
  - 结论：S002 全部拒绝；当前源码已回退到 S001 部分保留状态，hash 对比一致。
- S003 `ShiftRows` unrolled fixed shuffle 候选：把 SSE `ShiftRows` 的两个 6 行循环展开为固定 `_mm_shuffle_epi8/_mm_shuffle_epi32`。
  - 全量候选语义通过 `KAT_2_12 + random 10000`。
  - 全量候选：768 和 1024 在 6/6 个长度加速，但 512 的 64KB 退化，因此不能全量保留。
  - 拆成 768/1024 后：1024 的 16KB/64KB 退化。
  - 拆成 768-only 后：r21 与 r41 都显示 768 的 16KB/64KB 退化。
  - 结论：S003 全部拒绝；当前源码已回退到 S001 部分保留状态，hash 对比一致。
- S004 `AddConstant` static constants 候选：把 SSE `AddConstant` 的 `_mm_set_epi64x + _mm_set1_epi16(rn)` 改成 18 轮预计算 128-bit 静态常量。
  - 全量候选语义通过 `KAT_2_12 + random 10000`。
  - 全量候选：512 的 1KB 从 `12.569298` 到 `12.681457` cycles/byte，退化；768 的 16KB 从 `20.673941` 到 `20.844813` cycles/byte，退化；1024 在全量候选中 6/6 加速。
  - 拆成 1024-only 后重新测试最终可保留形态：1024 的 256B 从 `73.024466` 到 `73.192495` cycles/byte，64KB 从 `32.594303` 到 `32.985314` cycles/byte，均退化。
  - 结论：S004 全部拒绝；当前源码已回退到 S001 部分保留状态，hash 对比一致。
- S005 `_core/_core_inverse` pragma unroll 候选：尝试给两个 9 轮核心循环加 `#pragma GCC unroll 9`。
  - 语义通过 `KAT_2_12 + random 10000`。
  - 编译器输出 `ignoring #pragma GCC unroll`，说明当前 GCC/MinGW 不支持该 pragma；候选没有真实代码生成收益，并引入 warning。
  - 结论：S005 拒绝，已回退。
- S006 explicit `_core9/_core_inverse9` 候选：新增显式 9 轮正向/逆向核心路径，`zip_prf` 直接调用专用函数。
  - 语义通过 `KAT_2_12 + random 10000`。
  - 512：6/6 全部退化，16B speedup `0.5461x`，64KB speedup `0.5613x`。
  - 768：小消息加速但 1KB/16KB/64KB 退化，64KB speedup `0.9602x`。
  - 1024：6/6 全部退化，16KB speedup `0.5575x`，64KB speedup `0.5816x`。
  - 结论：S006 全部拒绝；当前源码已回退到 S001 部分保留状态，hash 对比一致。
- S007 编译方法候选：测试 SSE 独立版本的 native 编译参数。
  - `-march=native` 在当前 gcc/SSE 源码组织下构建失败：SSE 源文件内的 AVX2 helper 在 `AddConstant_avx2` 处触发 `_mm256_zextsi128_si256` 声明/类型错误，因此拒绝。
  - `-mtune=native` 语义通过 `KAT_2_12 + random 10000`。
  - `-mtune=native` 的 21 轮 pair benchmark 为混合结果：512 的 16B/256B/1KB 变慢，768 的 64B/256B/1KB/16KB/64KB 变慢，1024 的 64B/256B/16KB/64KB 变慢。
  - 结论：S007 全部拒绝；不保留任何 SSE 编译参数修改，当前源码仍为 S001 部分保留状态。
- S008 768-only `MAndRXs` 固定参数专门化 + 6 行展开候选：为四组固定参数 `(0,1,8)`、`(14,5,0)`、`(9,12,8)`、`(8,9,0)` 新增专门函数，并展开 6 行赋值。
  - 候选通过 `KAT_2_12 + random 10000`。
  - r21 中目标 768 的 16B/64B/256B/1KB/16KB/64KB 全部退化，speedup 为 0.9170x、0.9021x、0.9366x、0.9103x、0.9182x、0.9092x。
  - 结论：S008 拒绝；该候选只测试外部快照，最终 `versions/x86_64_sse42` 没有被修改，当前源码继续保持 S001 部分保留状态。

## 2026-06-13 SSE4.2 server continuation

- S009 `zip_prf` 12 个 `__m128i` state copy 显式赋值：语义 `KAT_2_12 + random 10000` 通过；r21 speedup 512=`1.0081/0.9693/0.9946/0.9987/0.9839/0.9962`，768=`0.9827/0.9966/0.9983/0.9923/1.0102/1.0016`，1024=`1.0025/0.9992/1.0006/1.0015/0.9997/1.0034`；拒绝。
- S010 `zip_prf` final xor 展开 12 条 `_mm_xor_si128`：语义通过；full r41 中 512 全过但 full candidate 混合修改不直接保留；拆分 `S010_512only` 后 r41 512=`1.0074/1.0041/1.0121/0.9989/1.0136/0.9972`，未满足 6/6，拒绝。
- S011 `MixColumns` 两个 2-iteration 循环显式展开：语义通过；r41 512=`0.9915/0.9994/0.9923/0.9969/0.9905/0.9979`，768=`0.9967/1.0055/1.0024/1.0090/1.0170/1.0157`，1024=`1.0065/1.0034/1.0007/0.9996/0.9969/0.9956`；拒绝。
- S012 `_core_inverse` 六组 left/right swap 显式展开：语义通过；r41 512=`0.9991/0.9972/0.9988/1.0010/1.0010/0.9995`，768=`0.9974/0.9954/1.0000/1.0091/1.0178/1.0188`，1024=`1.0012/0.9819/0.9980/0.9986/1.0023/1.0104`；拒绝。
- 截至 S012 未新增 retained 源码，当时仍保持 S001 部分保留状态。
- S012 后 retained 通过 `KAT_2_12 + random 50000`，日志 `version_results/server_final_x86_64_sse42_retained_semantic50000/semantic_kat_random.log`。
- S012 后 retained-vs-original r21 CSV：`version_results/server_final_x86_64_sse42_retained_vs_reference_pair_r21/pair_cycles_summary.csv`；speedup 512=`0.9998/0.9996/1.0037/1.0007/0.9974/1.0036`，768=`1.0180/1.0174/1.0070/1.0038/1.0036/1.0018`，1024=`0.9935/0.9978/0.9895/1.0004/1.0011/1.0012`。

## 2026-06-14 SSE4.2 squeeze continuation

- 复查原因：S009-S012 这类核心 helper 展开在 SSE4.2 上提升少，主要因为 1536-bit state 要拆成 12 个 XMM 寄存器，展开后容易增加寄存器压力和代码体积；512/1024 的大消息长度尤其容易在 r41 中退化。
- S013 direct squeeze 候选：检查 `_sponge_squeeze_helper` 后发现 digest 输出完成后仍执行一次无用尾部 `transform(state)`。
  - full 候选语义通过；512/768 短消息明显加速，但 1024 的 16KB/64KB 退化，不能全量保留。
  - 512/768 split 候选语义通过；r41 中 512 的 16KB/64KB 退化，512 拒绝。
  - 768-only 候选语义通过；r41 768 speedup=`1.5604/1.5584/1.2655/1.0789/1.0100/1.0032`，6/6 固定长度加速，保留到 `MasterCube-768.c`。
- S014 skip final squeeze transform 候选：
  - 正确 full 候选语义通过；512 长消息退化，768 加速但不如 S013 direct squeeze，1024 需要拆分确认。
  - 1024-only 候选语义通过；r41 1024 speedup=`1.3382/1.2381/1.1371/1.0613/1.0049/1.0084`，6/6 固定长度加速，保留到 `MasterCube-1024.c`。
- 最终 retained 语义通过 `KAT_2_12 + random 50000`，日志 `version_results/server_sse42_after_S013_S014_retained_semantic50000/semantic_kat_random.log`。
- 最终 retained-vs-reference r21 CSV：`version_results/server_sse42_after_S013_S014_retained_vs_reference_pair_r21/pair_cycles_summary.csv`；speedup 512=`0.9982/0.9915/0.9984/0.9989/1.0069/1.0050`，768=`1.5469/1.5927/1.2858/1.0898/1.0104/1.0081`，1024=`1.3369/1.2290/1.1327/1.0503/1.0064/1.0074`。
- 顶层 `optimized_versions/x86_64_sse42` 已同步，并通过 `KAT_2_12 + random 10000`；pair r21 CSV 为 `version_results/optimized_versions_x86_64_sse42_after_S013_S014_vs_reference_pair_r21/pair_cycles_summary.csv`。

## 2026-06-14 SSE4.2 512 continuation

- S015 512-only direct squeeze 候选：只在 `MasterCube-512.c` 中直接用 4 条 `_mm_storeu_si128` 输出 64 bytes，并跳过无用尾部 transform。
  - 语义通过 `KAT_2_12 + random 10000`。
  - r21 512 speedup=`1.5175/1.5119/1.1897/1.0625/0.9992/0.9933`，16KB/64KB 未满足 6/6，单独拒绝。
- S016 512-only direct squeeze + `AddConstant` 静态常量表：
  - 在 S015 基础上，将 512 的 `AddConstant` 改成 18 轮 `alignas(16)` 128-bit 常量表，用 `_mm_load_si128` 取代运行时 `_mm_set_epi64x + _mm_set1_epi16(rn)`。
  - 语义通过 `KAT_2_12 + random 10000`。
  - r21 512 speedup=`1.5082/1.4963/1.1978/1.0664/1.0259/1.0244`，6/6 固定长度加速，保留到 `MasterCube-512.c`。
- S016 后最终 retained 语义通过 `KAT_2_12 + random 50000`，日志 `version_results/server_sse42_after_S016_retained_semantic50000/semantic_kat_random.log`。
- S016 后最终 retained-vs-reference r21 CSV：`version_results/server_sse42_after_S016_retained_vs_reference_pair_r21/pair_cycles_summary.csv`；speedup 512=`1.4874/1.5113/1.1793/1.0770/1.0189/1.0171`，768=`1.5797/1.6052/1.2804/1.0859/1.0040/0.9994`，1024=`1.3053/1.2213/1.1292/1.0492/1.0046/0.9990`。
- 顶层 `optimized_versions/x86_64_sse42` 已同步 S016 并通过 `KAT_2_12 + random 10000`；pair r21 CSV 为 `version_results/optimized_versions_x86_64_sse42_after_S016_vs_reference_pair_r21/pair_cycles_summary.csv`，speedup 512=`1.5375/1.5002/1.2018/1.0807/1.0224/1.0182`，768=`1.5515/1.5897/1.2912/1.0873/1.0015/1.0048`，1024=`1.3027/1.2279/1.1379/1.0489/1.0020/1.0078`。
