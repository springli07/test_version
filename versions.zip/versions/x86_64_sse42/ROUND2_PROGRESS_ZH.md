# x86_64_sse42 Round2 进展

本轮先完成 S009-S012 四个核心路径源码候选。它们全部通过 `KAT_2_12 + random 10000`，但 state copy、final xor、`MixColumns` 展开和 `_core_inverse` swap 展开在 r21/r41 或 digest-only 复测后仍存在固定长度退化，因此未保留。

随后按 SSE4.2 128-bit XMM 数据路径继续逐行检查，发现三个 digest 的 squeeze 输出函数在写完最后一块 digest 后仍会执行一次未被使用的尾部 `transform(state)`；768 还可以直接用 `_mm_storeu_si128/_mm_storel_epi64` 输出 96 bytes，绕开临时缓冲。该方向不是照搬 AVX-512/plain，而是利用 SSE 的 128-bit state 布局减少无效尾部计算和内存拷贝。

## 新增 retained

- S016 `MasterCube-512.c`：在 512-only 版本里组合 direct squeeze 和 `AddConstant` 18 轮静态常量表。`S015` direct squeeze 单独测试时短消息很快，但 16KB/64KB 仍退化；加入 512-only `AddConstant` 后 r21 512 speedup 为 `1.5082/1.4963/1.1978/1.0664/1.0259/1.0244`，6/6 固定长度加速，保留。
- S013 `MasterCube-768.c`：768-only `_sponge_squeeze_helper` 改为直接 SSE store 输出 80B + transform + 8B，并跳过最后一次无用 transform。`KAT_2_12 + random 10000` 通过；r41 768 speedup 为 `1.5604/1.5584/1.2655/1.0789/1.0100/1.0032`，6/6 固定长度加速，保留。
- S014 `MasterCube-1024.c`：1024-only `_sponge_squeeze_helper` 在最后一个输出 block 后不再调用无用 `transform(state)`。`KAT_2_12 + random 10000` 通过；r41 1024 speedup 为 `1.3382/1.2381/1.1371/1.0613/1.0049/1.0084`，6/6 固定长度加速，保留。

## 拒绝项

- S013 full direct squeeze：512/768 短消息明显加速，但 1024 的 16KB/64KB 退化，不能全量保留。
- S013 512/768 direct squeeze：r41 中 512 的 16KB/64KB 退化，512 拒绝；768 拆成 digest-only 后保留。
- S014 full skip-final-transform：512 的 16KB/64KB 退化，1024 的 64KB 需要 r41 复测；最终只保留 1024-only。
- S014 768 skip-final-transform 虽然加速，但 S013 的 768 direct squeeze 更快，因此 768 采用 S013。
- S015 512-only direct squeeze：`KAT_2_12 + random 10000` 通过，r21 512=`1.5175/1.5119/1.1897/1.0625/0.9992/0.9933`；16KB/64KB 未满足 6/6，因此拒绝为单独 retained。
- S017 1024 direct squeeze：`KAT_2_12 + random 10000` 通过，r21 1024=`1.0206/1.0104/1.0005/0.9897/0.9985/0.9941`；短消息小幅提升但 1KB/长消息回退，平均不如 S014，拒绝。

## 最终验证

- retained 语义：`version_results/server_sse42_after_S016_retained_semantic50000/semantic_kat_random.log`，512/768/1024 均 `KAT_2_12 PASS` 和 `RANDOM PASS`。
- retained-vs-reference r21：`version_results/server_sse42_after_S016_retained_vs_reference_pair_r21/pair_cycles_summary.csv`。

固定长度顺序：`16B/64B/256B/1KB/16KB/64KB`。

- 512：`1.4874/1.5113/1.1793/1.0770/1.0189/1.0171`。
- 768：`1.5797/1.6052/1.2804/1.0859/1.0040/0.9994`。
- 1024：`1.3053/1.2213/1.1292/1.0492/1.0046/0.9990`。

顶层 `optimized_versions/x86_64_sse42` 同步 S016 后的 r21 交付表为：

- 512：`1.5375/1.5002/1.2018/1.0807/1.0224/1.0182`。
- 768：`1.5515/1.5897/1.2912/1.0873/1.0015/1.0048`。
- 1024：`1.3027/1.2279/1.1379/1.0489/1.0020/1.0078`。
