#include <openssl/evp.h>
#include <stdint.h>
#include <stdalign.h>
#include <stdint.h>
#include <string.h>

#include "mastercube.h"
#include "macros.h"
#include "common.h"

#if (!defined (__AVX512F__) || !defined (__AVX512BW__) || !defined (__AVX512VL__)) && !defined(__AVX2__) && !defined(__SSE4_2__)

static const int N_ROUNDS = 18;

/*
 * row-major matrices
 */
struct xy_slice {
    union {
        alignas(16) uint16_t slice[6][8];
        uint16_t row[6][8];
        uint16_t raw_data[48];
    };
};
struct mc_state {
    union {
        struct {
            struct xy_slice left;
            struct xy_slice right;
        };

        uint16_t row[12][8];
        uint16_t raw_data[96];
        uint32_t pair32[6][8];
        uint64_t pair64[6][4];
    };
};

static inline uint16_t ror16(const uint16_t x, const int n_ror)
{
    if (n_ror == 0) return x;
    return (x >> n_ror) | (x << (16 - n_ror));
}

static inline void MAndRXs(struct xy_slice *state_l, struct xy_slice *state_r, const int alpha, const int beta, const int gamma)
{
    for (int i = 0; i < 6; ++i)
        for (int j = 0; j < 8; ++j) {
            const uint16_t x = state_l->slice[i][j];
            const uint16_t y = state_r->slice[i][j];
            const uint16_t a = ror16(x, alpha);
            const uint16_t b = ror16(x, beta);
            const uint16_t c = ror16(x, gamma);
            state_r->slice[i][j] = (a & b) ^ c ^ y;
        }

    return;
}

static inline void ShiftRows(struct xy_slice *state_l, struct xy_slice *state_r)
{
    //#pragma GCC unroll 6
    for (int i = 0; i < 6; ++i) {
        uint16_t v[8];
        memcpy(v, state_l->slice[i], 16);

        state_l->slice[i][0] = v[(0 + i) % 8];
        state_l->slice[i][1] = v[(1 + i) % 8];
        state_l->slice[i][2] = v[(2 + i) % 8];
        state_l->slice[i][3] = v[(3 + i) % 8];
        state_l->slice[i][4] = v[(4 + i) % 8];
        state_l->slice[i][5] = v[(5 + i) % 8];
        state_l->slice[i][6] = v[(6 + i) % 8];
        state_l->slice[i][7] = v[(7 + i) % 8];
    }

    //#pragma GCC unroll 6
    for (int i = 0; i < 6; ++i) {
        uint16_t v[8];
        memcpy(v, state_r->slice[i], 16);

        state_r->slice[i][0] = v[(0 - i + 8) % 8];
        state_r->slice[i][1] = v[(1 - i + 8) % 8];
        state_r->slice[i][2] = v[(2 - i + 8) % 8];
        state_r->slice[i][3] = v[(3 - i + 8) % 8];
        state_r->slice[i][4] = v[(4 - i + 8) % 8];
        state_r->slice[i][5] = v[(5 - i + 8) % 8];
        state_r->slice[i][6] = v[(6 - i + 8) % 8];
        state_r->slice[i][7] = v[(7 - i + 8) % 8];
    }

    return;
}

static inline void mix_row_32x4(uint16_t x[8])
{
    uint32_t x0;
    uint32_t x1;
    uint32_t x2;
    uint32_t x3;
    uint32_t y0;
    uint32_t y1;
    uint32_t y2;
    uint32_t y3;

    memcpy(&x0, x + 0, sizeof(x0));
    memcpy(&x1, x + 2, sizeof(x1));
    memcpy(&x2, x + 4, sizeof(x2));
    memcpy(&x3, x + 6, sizeof(x3));

    y0 = x3 ^ x0 ^ x1;
    y1 = x0 ^ x1 ^ x2;
    y2 = x1 ^ x2 ^ x3;
    y3 = x2 ^ x3 ^ x0;

    memcpy(x + 0, &y0, sizeof(y0));
    memcpy(x + 2, &y1, sizeof(y1));
    memcpy(x + 4, &y2, sizeof(y2));
    memcpy(x + 6, &y3, sizeof(y3));
}

static inline void MixRows(struct mc_state *state)
{
    for (int i = 0; i < 6; ++i) {
        mix_row_32x4(state->left.slice[i]);
        mix_row_32x4(state->right.slice[i]);
    }

    return;
}

static inline void SwapRows(struct mc_state *state)
{
    struct xy_slice tmp;
    memcpy(tmp.raw_data, state->right.raw_data, sizeof(struct xy_slice));

    memcpy(state->right.slice[0], tmp.slice[1], 16);
    memcpy(state->right.slice[1], tmp.slice[0], 16);

    memcpy(state->right.slice[2], tmp.slice[3], 16);
    memcpy(state->right.slice[3], tmp.slice[2], 16);

    memcpy(state->right.slice[4], tmp.slice[5], 16);
    memcpy(state->right.slice[5], tmp.slice[4], 16);

    return;
}

static inline void CrossMixs(struct mc_state *state)
{
#if defined(__ARM_ARCH_7EM__) || defined(__ARM_ARCH_7M__)
    for (int j = 0; j < 8; ++j) {
        const uint32_t x0 = state->pair32[0][j];
        const uint32_t x1 = state->pair32[1][j];
        const uint32_t x2 = state->pair32[2][j];
        const uint32_t x3 = state->pair32[3][j];
        const uint32_t x4 = state->pair32[4][j];
        const uint32_t x5 = state->pair32[5][j];

        state->pair32[0][j] = x0 ^ x1 ^ x4;
        state->pair32[1][j] = x1 ^ x2 ^ x5;
        state->pair32[2][j] = x2 ^ x3 ^ x0;
        state->pair32[3][j] = x3 ^ x4 ^ x1;
        state->pair32[4][j] = x4 ^ x5 ^ x2;
        state->pair32[5][j] = x5 ^ x0 ^ x3;
    }
#else
    for (int j = 0; j < 4; ++j) {
        const uint64_t x0 = state->pair64[0][j];
        const uint64_t x1 = state->pair64[1][j];
        const uint64_t x2 = state->pair64[2][j];
        const uint64_t x3 = state->pair64[3][j];
        const uint64_t x4 = state->pair64[4][j];
        const uint64_t x5 = state->pair64[5][j];

        state->pair64[0][j] = x0 ^ x1 ^ x4;
        state->pair64[1][j] = x1 ^ x2 ^ x5;
        state->pair64[2][j] = x2 ^ x3 ^ x0;
        state->pair64[3][j] = x3 ^ x4 ^ x1;
        state->pair64[4][j] = x4 ^ x5 ^ x2;
        state->pair64[5][j] = x5 ^ x0 ^ x3;
    }
#endif


    return;
}

static inline uint32_t load_u16_pair32(const uint16_t *src)
{
    uint32_t v;
    memcpy(&v, src, sizeof(v));
    return v;
}

static inline void store_u16_pair32(uint16_t *dst, const uint32_t v)
{
    memcpy(dst, &v, sizeof(v));
}

static inline void MixColumns(struct mc_state *state)
{
#define MIX_COLUMNS_LEFT_PAIR(r0, r2, r4, k) do {                         \
        const uint32_t x0 = load_u16_pair32(&state->row[(r0)][(k)]);      \
        const uint32_t x2 = load_u16_pair32(&state->row[(r2)][(k)]);      \
        const uint32_t x4 = load_u16_pair32(&state->row[(r4)][(k)]);      \
        const uint32_t y0 = x2 ^ x4;                                      \
        const uint32_t y2 = x0 ^ x4;                                      \
        const uint32_t y4 = x0 ^ y0;                                      \
        store_u16_pair32(&state->row[(r0)][(k)], y0);                     \
        store_u16_pair32(&state->row[(r2)][(k)], y2);                     \
        store_u16_pair32(&state->row[(r4)][(k)], y4);                     \
    } while (0)

#define MIX_COLUMNS_RIGHT_PAIR(r6, r8, r10, k) do {                       \
        const uint32_t x6 = load_u16_pair32(&state->row[(r6)][(k)]);      \
        const uint32_t x8 = load_u16_pair32(&state->row[(r8)][(k)]);      \
        const uint32_t x10 = load_u16_pair32(&state->row[(r10)][(k)]);    \
        const uint32_t y6 = x6 ^ x10;                                     \
        const uint32_t y8 = x8 ^ x10;                                     \
        const uint32_t y10 = x8 ^ y6;                                     \
        store_u16_pair32(&state->row[(r6)][(k)], y6);                     \
        store_u16_pair32(&state->row[(r8)][(k)], y8);                     \
        store_u16_pair32(&state->row[(r10)][(k)], y10);                   \
    } while (0)

    MIX_COLUMNS_LEFT_PAIR(0, 2, 4, 0);
    MIX_COLUMNS_LEFT_PAIR(0, 2, 4, 2);
    MIX_COLUMNS_LEFT_PAIR(0, 2, 4, 4);
    MIX_COLUMNS_LEFT_PAIR(0, 2, 4, 6);
    MIX_COLUMNS_LEFT_PAIR(1, 3, 5, 0);
    MIX_COLUMNS_LEFT_PAIR(1, 3, 5, 2);
    MIX_COLUMNS_LEFT_PAIR(1, 3, 5, 4);
    MIX_COLUMNS_LEFT_PAIR(1, 3, 5, 6);

    MIX_COLUMNS_RIGHT_PAIR(6, 8, 10, 0);
    MIX_COLUMNS_RIGHT_PAIR(6, 8, 10, 2);
    MIX_COLUMNS_RIGHT_PAIR(6, 8, 10, 4);
    MIX_COLUMNS_RIGHT_PAIR(6, 8, 10, 6);
    MIX_COLUMNS_RIGHT_PAIR(7, 9, 11, 0);
    MIX_COLUMNS_RIGHT_PAIR(7, 9, 11, 2);
    MIX_COLUMNS_RIGHT_PAIR(7, 9, 11, 4);
    MIX_COLUMNS_RIGHT_PAIR(7, 9, 11, 6);

#undef MIX_COLUMNS_RIGHT_PAIR
#undef MIX_COLUMNS_LEFT_PAIR

    return;
}

static inline void AddConstant(struct mc_state *state, const int rn)
{
    const uint32_t r = ((uint32_t)(uint16_t)rn) * 0x00010001u;

    store_u16_pair32(&state->row[0][0], load_u16_pair32(&state->row[0][0]) ^ (0x03707344u ^ r));
    store_u16_pair32(&state->row[0][2], load_u16_pair32(&state->row[0][2]) ^ (0x13198A2Eu ^ r));
    store_u16_pair32(&state->row[0][4], load_u16_pair32(&state->row[0][4]) ^ (0x85A308D3u ^ r));
    store_u16_pair32(&state->row[0][6], load_u16_pair32(&state->row[0][6]) ^ (0x243F6A88u ^ r));

    return;
}

static inline void _core(struct mc_state *state, const int n_rounds)
{
    //#pragma GCC unroll 20
    for (int i = 0; i < n_rounds; ++i) {
        CrossMixs(state);
        SwapRows(state);

        MAndRXs(&state->left, &state->right,  0, 1, 8);
        MAndRXs(&state->right, &state->left, 14, 5, 0);
        MAndRXs(&state->left, &state->right, 9, 12, 8);
        MAndRXs(&state->right, &state->left, 14, 5, 0);
        MAndRXs(&state->left, &state->right, 0, 1, 8);
        MAndRXs(&state->right, &state->left, 8, 9, 0);

        CrossMixs(state);
        SwapRows(state);

        MixColumns(state);
        ShiftRows(&state->left, &state->right);
        MixRows(state);

        AddConstant(state, i);
    }

    return;
}

static inline void _core_inverse(struct mc_state *state, const int n_rounds)
{

    for (int i = n_rounds - 1; i >= 0; --i) {
        AddConstant(state, i + 9); // for 18 rounds mcube

        MixRows(state);

        ShiftRows(&state->right, &state->left);

        MixColumns(state);

        SwapRows(state);
        CrossMixs(state);

        MAndRXs(&state->right, &state->left, 8, 9, 0);
        MAndRXs(&state->left, &state->right, 0, 1, 8);
        MAndRXs(&state->right, &state->left, 14, 5, 0);
        MAndRXs(&state->left, &state->right, 9, 12, 8);
        MAndRXs(&state->right, &state->left, 14, 5, 0);
        MAndRXs(&state->left, &state->right,  0, 1, 8);

        struct xy_slice tmp;
        memcpy(tmp.raw_data, state->left.raw_data, sizeof(struct xy_slice));
        memcpy(state->left.raw_data, state->right.raw_data, sizeof(struct xy_slice));
        memcpy(state->right.raw_data, tmp.raw_data, sizeof(struct xy_slice));

        SwapRows(state);
        CrossMixs(state);
    }

    return;
}

static inline void zip_prf(struct mc_state *state)
{
    struct mc_state state_copy;
    memcpy(state_copy.raw_data, state->raw_data, sizeof(struct mc_state));

    _core(state, N_ROUNDS / 2);

    _core_inverse(&state_copy, N_ROUNDS / 2);

    for (int i = 0; i < 12; ++i)
        for (int j = 0; j < 8; ++j)
            state->row[i][j] ^= state_copy.row[i][j];

    return;
}

static inline void SwapSlices32_768(struct mc_state *state)
{
    for (int i = 0; i < 24; ++i) {
        const int k = 2 * i;
        const uint32_t left = load_u16_pair32(&state->left.raw_data[k]);
        const uint32_t right = load_u16_pair32(&state->right.raw_data[k]);
        store_u16_pair32(&state->left.raw_data[k], right);
        store_u16_pair32(&state->right.raw_data[k], left);
    }
}

#define CORE_ROUND_768(state_ptr, round_number) do {        \
        CrossMixs((state_ptr));                             \
        SwapRows((state_ptr));                              \
                                                            \
        MAndRXs(&(state_ptr)->left, &(state_ptr)->right, 0, 1, 8);   \
        MAndRXs(&(state_ptr)->right, &(state_ptr)->left, 14, 5, 0);  \
        MAndRXs(&(state_ptr)->left, &(state_ptr)->right, 9, 12, 8);  \
        MAndRXs(&(state_ptr)->right, &(state_ptr)->left, 14, 5, 0);  \
        MAndRXs(&(state_ptr)->left, &(state_ptr)->right, 0, 1, 8);   \
        MAndRXs(&(state_ptr)->right, &(state_ptr)->left, 8, 9, 0);   \
                                                            \
        CrossMixs((state_ptr));                             \
        SwapRows((state_ptr));                              \
                                                            \
        MixColumns((state_ptr));                            \
        ShiftRows(&(state_ptr)->left, &(state_ptr)->right); \
        MixRows((state_ptr));                               \
                                                            \
        AddConstant((state_ptr), (round_number));           \
    } while (0)

static inline void _core9_unrolled(struct mc_state *state)
{
    CORE_ROUND_768(state, 0);
    CORE_ROUND_768(state, 1);
    CORE_ROUND_768(state, 2);
    CORE_ROUND_768(state, 3);
    CORE_ROUND_768(state, 4);
    CORE_ROUND_768(state, 5);
    CORE_ROUND_768(state, 6);
    CORE_ROUND_768(state, 7);
    CORE_ROUND_768(state, 8);
}

#define CORE_INVERSE_ROUND_768(state_ptr, round_number) do { \
        AddConstant((state_ptr), (round_number) + 9);        \
                                                            \
        MixRows((state_ptr));                               \
                                                            \
        ShiftRows(&(state_ptr)->right, &(state_ptr)->left); \
                                                            \
        MixColumns((state_ptr));                            \
                                                            \
        SwapRows((state_ptr));                              \
        CrossMixs((state_ptr));                             \
                                                            \
        MAndRXs(&(state_ptr)->right, &(state_ptr)->left, 8, 9, 0);   \
        MAndRXs(&(state_ptr)->left, &(state_ptr)->right, 0, 1, 8);   \
        MAndRXs(&(state_ptr)->right, &(state_ptr)->left, 14, 5, 0);  \
        MAndRXs(&(state_ptr)->left, &(state_ptr)->right, 9, 12, 8);  \
        MAndRXs(&(state_ptr)->right, &(state_ptr)->left, 14, 5, 0);  \
        MAndRXs(&(state_ptr)->left, &(state_ptr)->right, 0, 1, 8);   \
                                                            \
        SwapSlices32_768((state_ptr));                      \
                                                            \
        SwapRows((state_ptr));                              \
        CrossMixs((state_ptr));                             \
    } while (0)

static inline void _core_inverse9_unrolled(struct mc_state *state)
{
    CORE_INVERSE_ROUND_768(state, 8);
    CORE_INVERSE_ROUND_768(state, 7);
    CORE_INVERSE_ROUND_768(state, 6);
    CORE_INVERSE_ROUND_768(state, 5);
    CORE_INVERSE_ROUND_768(state, 4);
    CORE_INVERSE_ROUND_768(state, 3);
    CORE_INVERSE_ROUND_768(state, 2);
    CORE_INVERSE_ROUND_768(state, 1);
    CORE_INVERSE_ROUND_768(state, 0);
}

#undef CORE_INVERSE_ROUND_768
#undef CORE_ROUND_768

static inline void zip_prf_unrolled(struct mc_state *state)
{
    struct mc_state state_copy;
    memcpy(state_copy.raw_data, state->raw_data, sizeof(struct mc_state));

    _core9_unrolled(state);

    _core_inverse9_unrolled(&state_copy);

    for (int i = 0; i < 12; ++i)
        for (int j = 0; j < 8; ++j)
            state->row[i][j] ^= state_copy.row[i][j];

    return;
}

static void mc_transform(struct mc_state *state)
{
    zip_prf(state);
    return;
}

static void mc_transform_unrolled(struct mc_state *state)
{
    zip_prf_unrolled(state);
    return;
}


static inline void _sponge_absorb_helper(void (*transform)(struct mc_state *), struct mc_state *state, const int block_bits, const unsigned char *message, const uint64_t message_bits)
{
    for (int i = 0; i < 12; ++i)
        for (int j = 0; j < 8; ++j)
            state->row[i][j] = 0x0000;

    const int block_bytes = block_bits / 8;
    const int n_m128_per_block = block_bits / 128; // _m128i reg
    const uint64_t message_bytes = (message_bits + 7) / 8;
    const uint64_t n_block = message_bits / block_bits; // number of full blocks
    uint8_t last_block[136] = {0x00}; // the last and unaligned block, allocate the largest potential needed size, and pad with 0x00

    // copy and turn the last unaligned block to a padded full block
    const uint64_t last_index = n_block * block_bytes;
    memcpy(last_block, message + last_index, message_bytes - last_index);
    pad10star1(last_block, message_bits % block_bits, block_bits);

    for (uint64_t i = 0; i < n_block; ++i) {
        for (int j = 0; j < n_m128_per_block; ++j) {
            for (int k = 0; k < 8; ++k)
                state->row[j][k] ^= ((uint16_t *)(message + block_bytes * i + 16 * j))[k];
        }
        for (int k = 0; k < 4; ++k)
            state->row[n_m128_per_block][k] ^= ((uint16_t *)(message + block_bytes * i + 16 * n_m128_per_block))[k];

        transform(state);
    }
    {
        for (int j = 0; j < n_m128_per_block; ++j) {
            for (int k = 0; k < 8; ++k)
                state->row[j][k] ^= ((uint16_t *)(last_block + 16 * j))[k];
        }
        for (int k = 0; k < 4; ++k)
            state->row[n_m128_per_block][k] ^= ((uint16_t *)(last_block + 16 * n_m128_per_block))[k];

        transform(state);
    }

    return;
}

static inline void _sponge_squeeze_helper(void (*transform)(struct mc_state *), struct mc_state *state, const int block_bits, unsigned char *digest, const int digest_bits)
{
    const int digest_bytes = digest_bits / 8;
    const int block_bytes = block_bits / 8;
    const int n_block = (digest_bytes + block_bytes - 1) / block_bytes;

    const int n_m128_per_block  = (block_bits  + 128 - 1) / 128; // _m128i reg
    const int n_m128_per_digest = (digest_bits + 128 - 1) / 128; // _m128i reg
    const int n_m128_per_iter   = n_m128_per_block < n_m128_per_digest ? n_m128_per_block : n_m128_per_digest;

    uint8_t buffer[3][768 / 8];

    for (int i = 0; i < n_block; ++i) { // max: 3 (the 1024 case)
        for (int j = 0; j < n_m128_per_iter; ++j) // max: 6 (the 768 case)
            memcpy(buffer[i] + 16 * j, state->row[j], 16);

        transform(state);
    }

    if (digest_bytes <= block_bytes) {
        memcpy(digest, buffer[0], digest_bytes);
    } else if (digest_bytes <= 2 * block_bytes) {
        memcpy(digest, buffer[0], block_bytes);
        memcpy(digest + block_bytes, buffer[1], digest_bytes - block_bytes);
    } else if (digest_bytes <= 3 * block_bytes) {
        memcpy(digest, buffer[0], block_bytes);
        memcpy(digest + block_bytes, buffer[1], block_bytes);
        memcpy(digest + 2 * block_bytes, buffer[2], digest_bytes - 2 * block_bytes);
    }

    return;
}

static inline void _sponge_squeeze_768_direct(void (*transform)(struct mc_state *), struct mc_state *state, unsigned char *digest)
{
    memcpy(digest, state->row[0], 16);
    memcpy(digest + 16, state->row[1], 16);
    memcpy(digest + 32, state->row[2], 16);
    memcpy(digest + 48, state->row[3], 16);
    memcpy(digest + 64, state->row[4], 16);
    memcpy(digest + 80, state->row[5], 8);

    transform(state);

    memcpy(digest + 88, state->row[0], 8);

    return;
}


int MasterCube768_plain(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest)
{
    struct mc_state state = {0};

    enum {
        digest_bits = 768, // bits
        block_bits = 704 // bits
    };

    _sponge_absorb_helper(mc_transform, &state, block_bits, message, message_bit_len);
    _sponge_squeeze_768_direct(mc_transform, &state, digest);

    (void)block_bits;
    (void)digest_bits;

    return 0;
}

#else

int MasterCube768_plain(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest)
{
    UNUSED(message);
    UNUSED(message_bit_len);
    UNUSED(digest);
    return 1;
}

#endif
