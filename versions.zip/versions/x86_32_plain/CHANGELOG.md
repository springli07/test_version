﻿# x86_32_plain 修改日志

## 2026-06-13

- 初始化 Round2 独立目录。
- baseline 通过项目 `KAT_2_12 + random 10000`，并完成 16B、64B、256B、1KB、16KB、64KB 的 CPU cycles/byte 测试。
- P001 `MixRows` row32 直接视图候选在 `KAT_2_12_512_case_0` 失败，语义不一致，已拒绝并回退。
- P002 `MixRows` local32 候选通过语义测试。全量候选中 512 出现退化，拆成 768/1024 后 1024 出现退化，因此最终只在 `MasterCube-768.c` 保留。
- P002 768-only 最终形态通过 `KAT_2_12 + random 50000`，并通过 41 轮 interleaved pair benchmark 确认 768 的 6 个固定长度全部加速。
- P003 `MixColumns` local32 候选通过语义测试。全量候选中 512 的 1KB、1024 的 16KB 退化，因此 512/1024 已回退；最终只在 `MasterCube-768.c` 保留。
- P003 768-only 最终形态通过 `KAT_2_12 + random 50000`，并通过 41 轮 interleaved pair benchmark 确认相对 P002 retained 的 768 六个长度全部加速；相对最初 baseline 的累计 speedup 为 1.0759x 到 1.1722x。
- P004 `MAndRXs` 固定参数专门化候选通过语义测试，但 768 的 256B、1KB、16KB、64KB 退化，因此 rejected；`MasterCube-768.c` 已回退到 P003 retained。
- P005 `CrossMixs` x86 32-bit `pair32` 分支候选通过语义测试，但 768 六个固定长度全部退化，因此 rejected；`MasterCube-768.c` 已回退到 P003 retained。该结果说明当前 MinGW 32 位 x86 下原 `pair64` 分支仍更快。
- P006 `zip_prf` final xor32 候选通过语义测试，但 41 轮 pair benchmark 中 768 的 64KB 退化到 0.9936x，因此 rejected；`MasterCube-768.c` 已回退到 P003 retained，回退后通过 `KAT_2_12 + random 10000`。
- P007 `_core_inverse` left/right slice 交换候选通过语义测试，但 21 轮 pair benchmark 中 768 的 16KB 退化到 0.9881x，因此 rejected；`MasterCube-768.c` 已回退到 P003 retained，回退后通过 `KAT_2_12 + random 10000`。
- P008 `AddConstant` 18 轮 `uint16_t` 预计算常量表候选通过语义测试，但 21 轮 pair benchmark 中 768 的 64KB 退化到 0.9953x，因此 rejected；`MasterCube-768.c` 已回退到 P003 retained，回退后通过 `KAT_2_12 + random 10000`。
- P009 `SwapRows` local32 行交换候选通过语义测试，但 21 轮 pair benchmark 中 768 六个固定长度全部退化，因此 rejected；`MasterCube-768.c` 已回退到 P003 retained，回退后通过 `KAT_2_12 + random 10000`。
- P010 `ShiftRows` 显式 row rotate 展开候选通过语义测试；21 轮测试中 768 的 1KB 退化到 0.9955x，41 轮复测中 768 的 256B 仍略慢（80.382755 -> 80.385370 cycles/byte），因此 rejected；`MasterCube-768.c` 已回退到 P003 retained，回退后通过 `KAT_2_12 + random 10000`。
- P011 `_core/_core_inverse` 9-round 专门化候选通过语义测试；21 轮 pair benchmark 中 768 的 256B、1KB、16KB、64KB 加速，但 16B 为 0.9824x、64B 为 0.9851x，因此 rejected；`MasterCube-768.c` 已回退到 P003 retained，回退后通过 `KAT_2_12 + random 10000`。
- P012 `AddConstant` 32-bit immediate pair 候选通过语义测试；21 轮 pair benchmark 中 768 的 16B、64B、256B、16KB、64KB 加速，但 1KB 为 0.9905x，因此 rejected；`MasterCube-768.c` 已回退到 P003 retained，回退后通过 `KAT_2_12 + random 10000`。
- P013 `MixColumns` 32-bit pair 完全展开候选通过语义测试；21 轮 pair benchmark 中 768 的 16B、64B、256B、1KB、16KB 加速，但 64KB 为 0.9834x，因此 rejected；`MasterCube-768.c` 已回退到 P003 retained，回退后通过 `KAT_2_12 + random 10000`。
- P014 `MixColumns` 完全展开 + `AddConstant` 32-bit immediate pair 组合候选通过语义测试；41 轮 pair benchmark 中 768 的六个固定长度全部加速，因此 retained；最终保留版通过 `KAT_2_12 + random 50000`，当前 `MasterCube-768.c` hash 为 `D834C49673B64523475CC0954A36E1A4ACAD281DC4EB8F84AE1E11365EB277CB`。
- P015 `zip_prf` final xor32 after P014 候选通过语义测试；21 轮 pair benchmark 中 768 的 64B、256B、1KB、64KB 加速，但 16B 为 0.9793x、16KB 为 0.9918x，因此 rejected；`MasterCube-768.c` 已回退到 P014 retained，回退后通过 `KAT_2_12 + random 10000`。
- P016 `_core/_core_inverse` 9-round 宏完全展开 after P014 候选通过语义测试；21 轮 pair benchmark 中 768 的 256B、1KB、16KB、64KB 明显加速，但 16B 为 0.9005x、64B 为 0.9129x，因此 direct-unroll 形态 rejected。
- P017 长度分流 `_core/_core_inverse` 9-round 展开候选通过语义测试；小于 2048 bit 走 P014 原 `zip_prf`，大于等于 2048 bit 走展开核心。41 轮 pair benchmark 中 768 六个固定长度全部加速，因此 retained；最终保留版通过 `KAT_2_12 + random 50000`，当前 `MasterCube-768.c` hash 为 `7D020C0FC887EFDF3D0B522FD14C8EB6BB15AB3A6975420A77B0C7176E26335D`。
- P018 `zip_prf_unrolled` final xor32 after P017 候选通过语义测试；21 轮 pair benchmark 中 768 六个固定长度全部退化，最差 64KB 为 0.7348x，因此 rejected；`MasterCube-768.c` 已回退到 P017 retained，回退后通过 `KAT_2_12 + random 10000`。
- P019 `zip_prf_unrolled` 展开路径 `_core_inverse` left/right slice 交换候选通过语义测试；将每轮末尾三次 `memcpy` 临时交换替换为 24 次安全 `uint32_t` 局部 load/store 交换。21 轮初测中 16B/64B 轻微退化，但这两个长度不执行展开路径，因此加跑 41 轮复测；r41 中 768 六个固定长度全部加速，speedup 为 1.0020x、1.0022x、1.0072x、1.0344x、1.0544x、1.0527x，因此 retained。最终保留版通过 `KAT_2_12 + random 50000`，当前 `MasterCube-768.c` hash 为 `6897BAF9C2DCEBCA4858D39A86B3AD24E064836A24F7AB5821B2F74A2A16874C`。
- P020 `zip_prf_unrolled` 展开路径 `_core_inverse` XOR-swap32 候选通过语义测试；将 P019 的局部临时变量交换改为 `left ^= right; right ^= left; left ^= right;`。21 轮 pair benchmark 中 768 的 16B、1KB、16KB 变慢，speedup 分别为 0.9951x、0.9801x、0.9749x，因此 rejected；`MasterCube-768.c` 已回退到 P019 retained，回退后通过 `KAT_2_12 + random 10000`。

## 2026-06-13 x86_32 server continuation

- 本轮 native 32-bit 使用 `attempts/tooling/gcc-m32.sh` wrapper，内容为 `exec gcc -m32 "$@"`。
- P021 `zip_prf` state copy 显式 `pair32` 复制：语义 `KAT_2_12 + random 10000` 通过；r21 speedup 512=`0.9420/0.9392/0.9513/0.9620/0.9391/0.9478`，768=`0.9821/0.9879/0.9921/1.0046/0.9988/0.9962`，1024=`0.9450/0.9565/0.9511/0.9490/0.9279/0.9489`；拒绝。
- P022 768 final xor `pair32` 展开：语义通过；r21 768=`0.9774/0.9843/0.9953/1.0081/1.0088/1.0078`；拒绝。
- P023 768-only `CrossMixs` direct/shared-XOR `pair32`：语义通过；r21 768=`0.9872/0.9696/0.9781/0.9853/0.9961/0.9850`；拒绝。
- P024 768-only retained 长消息路径 `MAndRXs` 固定参数专门化：语义通过；r41 768=`1.0110/0.9970/0.9967/1.0041/0.9949/0.9989`；拒绝。
- 本轮未新增 retained 源码，当前仍保持 P019 retained。
- 最终 retained 通过 `KAT_2_12 + random 50000`，日志 `version_results/server_final_x86_32_plain_retained_semantic50000/semantic_kat_random.log`。
- 最终 retained-vs-reference r21 CSV：`version_results/server_final_x86_32_plain_retained_vs_reference_pair_r21/pair_cycles_summary.csv`；speedup 512=`1.0013/1.0049/1.0021/1.0063/1.0021/1.0051`，768=`1.0884/1.0842/0.9622/0.9555/0.9451/0.9481`，1024=`0.9819/0.9892/0.9784/1.0157/0.9976/0.9916`。

## 2026-06-14 x86_32 server direct-squeeze continuation

- 用户更新目标为按平均 speedup 继续优化未达标实现。本轮继续使用 `attempts/tooling/gcc-m32.sh` 做 native 32-bit 编译。
- P025 `768` direct squeeze：新增 `_sponge_squeeze_768_direct`，输出 88B 后 transform，再输出 8B；语义 `KAT_2_12 + random 10000` 通过；r21 768=`1.4883/1.4941/1.2473/1.0770/1.0042/1.0035`，保留 `MasterCube-768.c`。
- P026 `1024` direct squeeze：输出 56B、transform、56B、transform、16B；语义通过；r21 1024=`1.2668/1.2108/1.1324/1.0461/1.0052/1.0021`，保留 `MasterCube-1024.c`。
- P027 `512` direct squeeze：digest 64B 小于 960-bit rate，直接输出 4 行 state 并跳过无用尾部 transform；语义通过；r21 512=`1.9709/1.9711/1.3411/1.1075/0.9963/0.9916`，按平均提升规则保留 `MasterCube-512.c`。
- P028 `512` gated direct squeeze：语义通过；短消息快但 256B/1KB 回退，平均不如 P027，拒绝。
- P029 `512` short-only direct squeeze：语义通过；仅 16B/64B 明显加速，平均不如 P027，拒绝。
- P030 `768` 普通 transform + direct squeeze：去掉 P019/P025 长消息 unrolled transform 分流，统一使用 `mc_transform`；语义通过；r21 vs retained 的 768=`0.9980/1.0156/1.1451/1.1430/1.1438/1.1558`，显著修复长消息，保留 `MasterCube-768.c`。
- 最终 retained 通过 `KAT_2_12 + random 50000`，日志 `version_results/server_final_x86_32_plain_after_P025_P026_P027_P030_semantic50000/semantic_kat_random.log`。
- 最终 retained-vs-reference r21 CSV：`version_results/server_final_x86_32_plain_after_P025_P026_P027_P030_vs_reference_pair_r21/pair_cycles_summary.csv`；speedup 512=`1.9777/1.9844/1.3468/1.1022/1.0043/0.9965`，768=`1.6242/1.6215/1.3617/1.1980/1.0890/1.0914`，1024=`1.2618/1.2097/1.1195/1.0373/1.0075/1.0058`。






