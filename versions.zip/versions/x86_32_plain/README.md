﻿# x86_32_plain

Round2 独立优化目录。

- 512/768/1024 源码独立保存在本目录。
- 优化进度统一记录在 ../../ROUND2_PROGRESS_ZH.md。
- 原始目录不修改；本目录只保留通过语义测试且性能稳定加速的改动。
- 当前保留状态：仅 `MasterCube-768.c` 保留 P002 `MixRows local32` 和 P003 `MixColumns local32`；`MasterCube-512.c`、`MasterCube-1024.c` 与 `Reference_Implementation` 源码一致。
- 当前验证：P003 768-only 已通过 `KAT_2_12 + random 50000`，并通过 41 轮 interleaved pair benchmark；相对最初 baseline 的 768 累计 speedup 为 1.0759x 到 1.1722x。



