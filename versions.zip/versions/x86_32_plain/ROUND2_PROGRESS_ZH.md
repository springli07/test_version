# x86_32_plain Round2 进展

本轮使用 native 32-bit wrapper `attempts/tooling/gcc-m32.sh`，内容为 `exec gcc -m32 "$@"`。在 P021-P024 拒绝后，继续按 digest-only 方式优化 squeeze 路径，最终保留 P025、P026、P027、P030。

固定长度顺序为 `16B/64B/256B/1KB/16KB/64KB`。

## 新增 retained

- P025 `MasterCube-768.c` direct squeeze：语义 `KAT_2_12 + random 10000` 通过；r21 vs retained 的 768 speedup 为 `1.4883/1.4941/1.2473/1.0770/1.0042/1.0035`，保留。
- P026 `MasterCube-1024.c` direct squeeze：语义通过；r21 vs retained 的 1024 speedup 为 `1.2668/1.2108/1.1324/1.0461/1.0052/1.0021`，保留。
- P027 `MasterCube-512.c` direct squeeze：语义通过；r21 vs retained 的 512 speedup 为 `1.9709/1.9711/1.3411/1.1075/0.9963/0.9916`，平均显著提升，保留。
- P030 `MasterCube-768.c` 普通 transform + direct squeeze：语义通过；r21 vs retained 的 768 speedup 为 `0.9980/1.0156/1.1451/1.1430/1.1438/1.1558`，修复 P025/P019 长消息路径相对 reference 的回退，保留。

## 拒绝项

- P021 state copy、P022 768 final xor、P023 768 CrossMixs direct/shared-XOR、P024 768 长消息 MAndRXs 专门化：语义均通过，但目标 digest 平均或固定长度结果不如 retained，拒绝。
- P028/P029 512 gated/short direct squeeze：语义通过，但相对 P027 的平均收益更低，拒绝。

## 最终验证

最终 retained 语义 `KAT_2_12 + random 50000` 全 PASS；日志为 `version_results/server_final_x86_32_plain_after_P025_P026_P027_P030_semantic50000/semantic_kat_random.log`。

最终 pair CSV 为 `version_results/server_final_x86_32_plain_after_P025_P026_P027_P030_vs_reference_pair_r21/pair_cycles_summary.csv`。
