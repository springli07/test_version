# x86_32_plain 服务器结果分析

- 保留：P025 768 direct squeeze，P026 1024 direct squeeze，P027 512 direct squeeze，P030 768 普通 transform + direct squeeze。
- 拒绝：P021-P024、P028、P029。P028/P029 虽然能改善 512 短消息，但平均不如 P027。
- 最终语义：`version_results/server_final_x86_32_plain_after_P025_P026_P027_P030_semantic50000/semantic_kat_random.log`，512/768/1024 均 `KAT_2_12 PASS` 和 `RANDOM PASS`。
- 最终 pair：`version_results/server_final_x86_32_plain_after_P025_P026_P027_P030_vs_reference_pair_r21/pair_cycles_summary.csv`。

固定长度顺序为 `16B/64B/256B/1KB/16KB/64KB`。

| digest | speedup | 平均 |
| --- | --- | --- |
| 512 | `1.9777/1.9844/1.3468/1.1022/1.0043/0.9965` | `1.4020` |
| 768 | `1.6242/1.6215/1.3617/1.1980/1.0890/1.0914` | `1.3310` |
| 1024 | `1.2618/1.2097/1.1195/1.0373/1.0075/1.0058` | `1.1069` |

说明：P030 将 768 的 16KB/64KB 从旧 final 的 `0.9546/0.9507` 修正为 `1.0890/1.0914`，因此最终 768 平均达到 `1.3310`。
