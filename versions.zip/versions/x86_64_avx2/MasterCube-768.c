#include <stdalign.h>
#include <stdint.h>
#include <string.h>
#if defined(MCUBE_USE_SSE2NEON)
#include "sse2neon.h"
#else
#include <immintrin.h>
#endif

#include "mastercube.h"
#include "macros.h"
#include "common.h"

#if !defined(_mm_loadu_si64)
static inline __m128i mc_loadu_si64_compat(const void *p)
{
    return _mm_loadl_epi64((const __m128i *)p);
}
#define _mm_loadu_si64(p) mc_loadu_si64_compat((p))
#endif

/****************************************************************************
 * SSE4.2 Implementation
 ****************************************************************************/
#if defined(MCUBE_USE_SSE2NEON) || ((!defined (__AVX512F__) || !defined (__AVX512BW__) || !defined (__AVX512VL__)) && !defined (__AVX2__) && defined(__SSE4_2__))

static const int N_ROUNDS = 18;

// regard the 128-bit reg as a 16-byte reg and rotate bytes not bits.
//static inline __m128i ror128(const __m128i x, const int n_ror) { return _mm_or_si128(_mm_srli_si128(x, n_ror), _mm_slli_si128(x, 16 - n_ror)); }
static inline __m128i ror128_optimized(const __m128i x, const int n_ror) {
    switch (n_ror) {
        case 0:
        case 16:
            return x;
            break;

        case 1:
            return _mm_shuffle_epi8(x, _mm_setr_epi8(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0));
            break;

        case 2:
            return _mm_shuffle_epi8(x, _mm_setr_epi8(2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0, 1));
            break;

        case 3:
            return _mm_shuffle_epi8(x, _mm_setr_epi8(3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2));
            break;

        case 4:
            return _mm_shuffle_epi32(x, _MM_SHUFFLE_R(1, 2, 3, 0));
            break;

        case 5:
            return _mm_shuffle_epi8(x, _mm_setr_epi8(5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4));
            break;

        case 6:
            return _mm_shuffle_epi8(x, _mm_setr_epi8(6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5));
            break;

        case 7:
            return _mm_shuffle_epi8(x, _mm_setr_epi8(7, 8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6));
            break;

        case 8:
            return _mm_shuffle_epi32(x, _MM_SHUFFLE_R(2, 3, 0, 1));
            break;

        case 9:
            return _mm_shuffle_epi8(x, _mm_setr_epi8(9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7, 8));
            break;

        case 10:
            return _mm_shuffle_epi8(x, _mm_setr_epi8(10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9));
            break;

        case 11:
            return _mm_shuffle_epi8(x, _mm_setr_epi8(11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10));
            break;

        case 12:
            return _mm_shuffle_epi32(x, _MM_SHUFFLE_R(3, 0, 1, 2));
            break;

        case 13:
            return _mm_shuffle_epi8(x, _mm_setr_epi8(13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12));
            break;

        case 14:
            return _mm_shuffle_epi8(x, _mm_setr_epi8(14, 15, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13));
            break;

        case 15:
            return _mm_shuffle_epi8(x, _mm_setr_epi8(15, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14));
            break;

        default:
            return _mm_setzero_si128();
            break;
    }
}

//static inline __m128i ror64(const __m128i x, const int n_ror) { return _mm_or_si128(_mm_srli_epi64(x, n_ror), _mm_slli_epi64(x, 64 - n_ror)); }
static inline __m128i ror64_optimized(const __m128i x, const int n_ror) {
    switch (n_ror) {
        case 0:
        case 64:
            return x;
            break;

        case 8:
            return _mm_shuffle_epi8(x, _mm_setr_epi8(1, 2, 3, 4, 5, 6, 7, 0, 9, 10, 11, 12, 13, 14, 15, 8));
            break;

        case 16:
            return _mm_shuffle_epi8(x, _mm_setr_epi8(2, 3, 4, 5, 6, 7, 0, 1, 10, 11, 12, 13, 14, 15, 8, 9));
            break;

        case 24:
            return _mm_shuffle_epi8(x, _mm_setr_epi8(3, 4, 5, 6, 7, 0, 1, 2, 11, 12, 13, 14, 15, 8, 9, 10));
            break;

        case 32:
            return _mm_shuffle_epi8(x, _mm_setr_epi8(4, 5, 6, 7, 0, 1, 2, 3, 12, 13, 14, 15, 8, 9, 10, 11));
            break;

        case 40:
            return _mm_shuffle_epi8(x, _mm_setr_epi8(5, 6, 7, 0, 1, 2, 3, 4, 13, 14, 15, 8, 9, 10, 11, 12));
            break;

        case 48:
            return _mm_shuffle_epi8(x, _mm_setr_epi8(6, 7, 0, 1, 2, 3, 4, 5, 14, 15, 8, 9, 10, 11, 12, 13));
            break;

        case 56:
            return _mm_shuffle_epi8(x, _mm_setr_epi8(7, 0, 1, 2, 3, 4, 5, 6, 15, 8, 9, 10, 11, 12, 13, 14));
            break;

        default:
            return _mm_or_si128(_mm_srli_epi64(x, n_ror), _mm_slli_epi64(x, 64 - n_ror));
    }
}
//static inline __m128i ror32(const __m128i x, const int n_ror) { return _mm_or_si128(_mm_srli_epi32(x, n_ror), _mm_slli_epi32(x, 32 - n_ror)); }
//static inline __m128i ror16(const __m128i x, const int n_ror) { return _mm_or_si128(_mm_srli_epi16(x, n_ror), _mm_slli_epi16(x, 16 - n_ror)); }
static inline __m128i ror16_optimized(const __m128i x, const int n_ror) {
    switch (n_ror) {
        case 0:
        case 16:
            return x;
            break;

        case 8:
            return _mm_shuffle_epi8(x, _mm_setr_epi8(1, 0, 3, 2, 5, 4, 7, 6, 9, 8, 11, 10, 13, 12, 15, 14));
            break;

        default:
            return _mm_or_si128(_mm_srli_epi16(x, n_ror), _mm_slli_epi16(x, 16 - n_ror));
    }
}

static inline void MAndRXs(__m128i state_l[6], __m128i state_r[6], const int alpha, const int beta, const int gamma)
{
    for (int i = 0; i < 6; ++i) {
        const __m128i x = state_l[i];
        const __m128i y = state_r[i];
        const __m128i a = ror16_optimized(x, alpha);
        const __m128i b = ror16_optimized(x, beta);
        const __m128i c = ror16_optimized(x, gamma);
        const __m128i r = _mm_xor_si128(_mm_and_si128(a, b), c);
        state_r[i] = _mm_xor_si128(r, y);
    }

    return;
}

static inline void ShiftRows(__m128i state_l[6], __m128i state_r[6])
{
    //#pragma GCC unroll 6
    for (int row = 0; row < 6; ++row) {
        const __m128i x = state_l[row];
        state_l[row] = ror128_optimized(x, 2 * row);
    }

    //#pragma GCC unroll 6
    for (int row = 0; row < 6; ++row) {
        const __m128i x = state_r[row];
        state_r[row] = ror128_optimized(x, 16 - 2 * row);
    }

    return;
}

static inline __m128i mix_row_32x4(__m128i x)
{
    const __m128i pre  = ror128_optimized(x, 32 / 8);
    const __m128i post = ror128_optimized(x, 3 * 32 / 8);

    return _mm_xor_si128(pre, _mm_xor_si128(x, post));
}

static inline void MixRows(__m128i state[12])
{
    state[ 0] = mix_row_32x4(state[ 0]);
    state[ 1] = mix_row_32x4(state[ 1]);

    state[ 2] = mix_row_32x4(state[ 2]);
    state[ 3] = mix_row_32x4(state[ 3]);

    state[ 4] = mix_row_32x4(state[ 4]);
    state[ 5] = mix_row_32x4(state[ 5]);

    state[ 6] = mix_row_32x4(state[ 6]);
    state[ 7] = mix_row_32x4(state[ 7]);

    state[ 8] = mix_row_32x4(state[ 8]);
    state[ 9] = mix_row_32x4(state[ 9]);

    state[10] = mix_row_32x4(state[10]);
    state[11] = mix_row_32x4(state[11]);

    return;
}

static inline void SwapRows(__m128i state[12])
{
    __m128i tmp0 = state[6];
    state[6] = state[7];
    state[7] = tmp0;

    __m128i tmp1 = state[8];
    state[8] = state[9];
    state[9] = tmp1;

    __m128i tmp2 = state[10];
    state[10] = state[11];
    state[11] = tmp2;

    return;
}

static inline void CrossMixs(__m128i state[12])
{
    static const int arrange[6] = {0, 2, 4, 6, 8, 10};
    __m128i tmp[12];
    memcpy(tmp, state, sizeof(tmp));

    //#pragma GCC unroll 6
    for (int j = 0; j < 6; ++j) {
        __m128i a = tmp[arrange[j]];
        __m128i b = tmp[arrange[(j + 1) % 6]];
        __m128i c = tmp[arrange[(j + 4) % 6]];
        state[arrange[j]] = _mm_xor_si128(_mm_xor_si128(a, b), c);
    }

    //#pragma GCC unroll 6
    for (int j = 0; j < 6; ++j) {
        __m128i a = tmp[arrange[j] + 1];
        __m128i b = tmp[arrange[(j + 1) % 6] + 1];
        __m128i c = tmp[arrange[(j + 4) % 6] + 1];
        state[arrange[j] + 1] = _mm_xor_si128(_mm_xor_si128(a, b), c);
    }

    return;
}

static inline void MixColumns(__m128i state[12])
{
    for (int i = 0; i < 2; ++i) {
        __m128i tmp0 = _mm_xor_si128(state[2 + i], state[4 + i]);
        __m128i tmp1 = _mm_xor_si128(state[0 + i], state[4 + i]);
        __m128i tmp2 = _mm_xor_si128(state[0 + i], tmp0);
        state[0 + i] = tmp0;
        state[2 + i] = tmp1;
        state[4 + i] = tmp2;
    }

    for (int i = 0; i < 2; ++i) {
        __m128i tmp0 = _mm_xor_si128(state[6 + i], state[10 + i]);
        __m128i tmp1 = _mm_xor_si128(state[8 + i], state[10 + i]);
        __m128i tmp2 = _mm_xor_si128(state[8 + i], tmp0);
        state[6 + i] = tmp0;
        state[8 + i] = tmp1;
        state[10 + i] = tmp2;
    }

    return;
}

static inline void AddConstant(__m128i state[12], const int rn)
{
    __m128i c = _mm_set_epi64x(
        0x243F6A8885A308D3ULL,  // high 64 bits
        0x13198A2E03707344ULL   // low 64 bits
    );
    __m128i x = _mm_set1_epi16((short)rn);
    state[0] = _mm_xor_si128(_mm_xor_si128(state[0], c), x);

    return;
}

static inline void _core(__m128i state[12], const int n_rounds)
{
    //#pragma GCC unroll 20
    for (int i = 0; i < n_rounds; ++i) {
        CrossMixs(state);
        SwapRows(state);

        MAndRXs(state, state + 6,  0, 1, 8);
        MAndRXs(state + 6, state, 14, 5, 0);
        MAndRXs(state, state + 6, 9, 12, 8);
        MAndRXs(state + 6, state, 14, 5, 0);
        MAndRXs(state, state + 6, 0, 1, 8);
        MAndRXs(state + 6, state, 8, 9, 0);

        CrossMixs(state);
        SwapRows(state);

        MixColumns(state);
        ShiftRows(state, state + 6);
        MixRows(state);

        AddConstant(state, i);
    }

    return;
}

static inline void _core_inverse(__m128i state[12], const int n_rounds)
{
    for (int i = n_rounds - 1; i >= 0; --i) {
        AddConstant(state, i + 9);

        MixRows(state);
        ShiftRows(state + 6, state);
        MixColumns(state);

        SwapRows(state);
        CrossMixs(state);

        MAndRXs(state + 6, state, 8, 9, 0);
        MAndRXs(state, state + 6,  0, 1, 8);
        MAndRXs(state + 6, state, 14, 5, 0);
        MAndRXs(state, state + 6, 9, 12, 8);
        MAndRXs(state + 6, state, 14, 5, 0);
        MAndRXs(state, state + 6, 0, 1, 8);

        for (int j = 0; j < 6; ++j) {
            __m128i tmp = state[j];
            state[j] = state[j + 6];
            state[j + 6] = tmp;
        }

        SwapRows(state);
        CrossMixs(state);
    }

    return;
}

static inline void zip_prf(__m128i state[12])
{
    __m128i state_copy[12];
    memcpy(state_copy, state, 12 * sizeof(__m128i));

    _core(state, N_ROUNDS / 2);

    _core_inverse(state_copy, N_ROUNDS / 2);

    for (int i = 0; i < 12; ++i)
        state[i] = _mm_xor_si128(state[i], state_copy[i]);

    return;
}

static void mc_transform(__m128i state[12])
{
    zip_prf(state);
    return;
}


static inline void _sponge_absorb_helper(void (*transform)(__m128i *), __m128i state[12], const int block_bits, const unsigned char *message, const uint64_t message_bits)
{
    for (int row = 0; row < 12; ++row)
        state[row] = _mm_setzero_si128();

    const int block_bytes = block_bits / 8;
    const int n_m128_per_block = block_bits / 128; // _m128i reg
    const uint64_t message_bytes = (message_bits + 7) / 8;
    const uint64_t n_block = message_bits / block_bits; // number of full blocks
    uint8_t last_block[136] = {0x00}; // the last and unaligned block, allocate the largest potential needed size, and pad with 0x00

    // copy and turn the last unaligned block to a padded full block
    const uint64_t last_index = n_block * block_bytes;
    memcpy(last_block, message + last_index, message_bytes - last_index);
    pad10star1(last_block, message_bits % block_bits, block_bits);

    for (uint64_t i = 0; i < n_block; ++i) {
        for (int j = 0; j < n_m128_per_block; ++j) {
            __m128i chunk = _mm_loadu_si128((const __m128i*)(message + block_bytes * i + 16 * j));
            state[j] = _mm_xor_si128(state[j], chunk);
        }
        __m128i chunk64 = _mm_loadu_si64(message + block_bytes * i + 16 * n_m128_per_block);
        state[n_m128_per_block] = _mm_xor_si128(state[n_m128_per_block], chunk64);

        transform(state);
    }
    {
        for (int j = 0; j < n_m128_per_block; ++j) {
            __m128i chunk = _mm_loadu_si128((const __m128i*)(last_block + 16 * j));
            state[j] = _mm_xor_si128(state[j], chunk);
        }
        __m128i chunk64 = _mm_loadu_si64(last_block + 16 * n_m128_per_block);
        state[n_m128_per_block] = _mm_xor_si128(state[n_m128_per_block], chunk64);

        transform(state);
    }

    return;
}

static inline void _sponge_squeeze_helper(void (*transform)(__m128i *), __m128i state[12], const int block_bits, unsigned char *digest, const int digest_bits)
{
    const int digest_bytes = digest_bits / 8;
    const int block_bytes = block_bits / 8;
    const int n_block = (digest_bytes + block_bytes - 1) / block_bytes;

    const int n_m128_per_block  = (block_bits  + 128 - 1) / 128; // _m128i reg
    const int n_m128_per_digest = (digest_bits + 128 - 1) / 128; // _m128i reg
    const int n_m128_per_iter   = n_m128_per_block < n_m128_per_digest ? n_m128_per_block : n_m128_per_digest;

    uint8_t buffer[3][768 / 8];

    for (int i = 0; i < n_block; ++i) { // max: 3 (the 1024 case)
        for (int j = 0; j < n_m128_per_iter; ++j) // max: 6 (the 768 case)
            _mm_storeu_si128((__m128i *)(buffer[i] + 16 * j), state[j]);

        transform(state);
    }

    if (digest_bytes <= block_bytes) {
        memcpy(digest, buffer[0], digest_bytes);
    } else if (digest_bytes <= 2 * block_bytes) {
        memcpy(digest, buffer[0], block_bytes);
        memcpy(digest + block_bytes, buffer[1], digest_bytes - block_bytes);
    } else if (digest_bytes <= 3 * block_bytes) {
        memcpy(digest, buffer[0], block_bytes);
        memcpy(digest + block_bytes, buffer[1], block_bytes);
        memcpy(digest + 2 * block_bytes, buffer[2], digest_bytes - 2 * block_bytes);
    }

    return;
}

int MasterCube768_sse(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest)
{
    __m128i state[12] = {0};

    enum {
        digest_bits = 768, // bits
        block_bits = 704 // bits
    };

    _sponge_absorb_helper(mc_transform, state, block_bits, message, message_bit_len);
    _sponge_squeeze_helper(mc_transform, state, block_bits, digest, digest_bits);

    return 0;
}

#endif /* SSE4.2 */


/****************************************************************************
 * AVX2 Implementation
 ****************************************************************************/
#if (!defined (__AVX512F__) || !defined (__AVX512BW__) || !defined (__AVX512VL__)) && defined (__AVX2__)

static const int N_ROUNDS_avx2 = 18;

static inline __m256i ror16_optimized_avx2(const __m256i x, const int n_ror) {
    switch (n_ror) {
        case 0:
        case 16:
            return x;
            break;

        case 8:
            return _mm256_shuffle_epi8(
                x,
                _mm256_setr_epi8(
                    1, 0, 3, 2, 5, 4, 7, 6, 9, 8, 11, 10, 13, 12, 15, 14,
                    1, 0, 3, 2, 5, 4, 7, 6, 9, 8, 11, 10, 13, 12, 15, 14
                )
            );
            break;

        default:
            return _mm256_or_si256(
                _mm256_srli_epi16(x, n_ror),
                _mm256_slli_epi16(x, 16 - n_ror)
            );
    }
}

static inline void MAndRXs_avx2(__m256i state_l[3], __m256i state_r[3], const int alpha, const int beta, const int gamma)
{
    for (int i = 0; i < 3; ++i) {
        const __m256i x = state_l[i];
        const __m256i y = state_r[i];
        const __m256i a = ror16_optimized_avx2(x, alpha);
        const __m256i b = ror16_optimized_avx2(x, beta);
        const __m256i c = ror16_optimized_avx2(x, gamma);
        const __m256i r = _mm256_xor_si256(_mm256_and_si256(a, b), c);
        state_r[i] = _mm256_xor_si256(r, y);
    }

    return;
}

static inline void ShiftRows_avx2(__m256i state_l[3], __m256i state_r[3])
{
    state_l[0] = _mm256_shuffle_epi8(
        state_l[0],
        _mm256_setr_epi8(
            0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
            2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0, 1
        )
    );
    state_l[1] = _mm256_shuffle_epi8(
        state_l[1],
        _mm256_setr_epi8(
            4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3,
            6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5
        )
    );
    state_l[2] = _mm256_shuffle_epi8(
        state_l[2],
        _mm256_setr_epi8(
            8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7,
            10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9
        )
    );

    state_r[0] = _mm256_shuffle_epi8(
        state_r[0],
        _mm256_setr_epi8(
            0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
            14, 15, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13
        )
    );
    state_r[1] = _mm256_shuffle_epi8(
        state_r[1],
        _mm256_setr_epi8(
            12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11,
            10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9
        )
    );
    state_r[2] = _mm256_shuffle_epi8(
        state_r[2],
        _mm256_setr_epi8(
            8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7,
            6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5
        )
    );

    return;
}

static inline __m256i mix_row_32x4_avx2(__m256i x)
{
    // Rotate left by 32 bits (1 word) in each 128-bit lane
    __m256i pre = _mm256_shuffle_epi32(x, _MM_SHUFFLE_R(1, 2, 3, 0));
    // Rotate left by 96 bits (3 words) in each 128-bit lane
    __m256i post = _mm256_shuffle_epi32(x, _MM_SHUFFLE_R(3, 0, 1, 2));

    return _mm256_xor_si256(pre, _mm256_xor_si256(x, post));
}

static inline void MixRows_avx2(__m256i state[6])
{
    state[0] = mix_row_32x4_avx2(state[0]);
    state[1] = mix_row_32x4_avx2(state[1]);
    state[2] = mix_row_32x4_avx2(state[2]);
    state[3] = mix_row_32x4_avx2(state[3]);
    state[4] = mix_row_32x4_avx2(state[4]);
    state[5] = mix_row_32x4_avx2(state[5]);

    return;
}

static inline void SwapRows_avx2(__m256i state[6])
{
    //#pragma GCC unroll 3
    for (int i = 0; i < 3; ++i) {
        __m256i x = state[i + 3];
        state[i + 3] = _mm256_permute2x128_si256(x, x, 0x01);
    }
    return;
}

static inline void CrossMixs_avx2(__m256i state[6])
{
    static const int arrange[6] = {0, 1, 2, 3, 4, 5};
    __m256i tmp[6];
    memcpy(tmp, state, sizeof(tmp));

    //#pragma GCC unroll 6
    for (int j = 0; j < 6; ++j) {
        __m256i a = tmp[arrange[j]];
        __m256i b = tmp[arrange[(j + 1) % 6]];
        __m256i c = tmp[arrange[(j + 4) % 6]];
        state[arrange[j]] = _mm256_xor_si256(_mm256_xor_si256(a, b), c);
    }

    return;
}

static inline void MixColumns_avx2(__m256i state[6])
{
    __m256i tmp0 = _mm256_xor_si256(state[1], state[2]);
    __m256i tmp1 = _mm256_xor_si256(state[0], state[2]);
    __m256i tmp2 = _mm256_xor_si256(state[0], tmp0);
    state[0] = tmp0;
    state[1] = tmp1;
    state[2] = tmp2;

    __m256i tmp3 = _mm256_xor_si256(state[3], state[5]);
    __m256i tmp4 = _mm256_xor_si256(state[4], state[5]);
    __m256i tmp5 = _mm256_xor_si256(state[4], tmp3);
    state[3] = tmp3;
    state[4] = tmp4;
    state[5] = tmp5;

    return;
}

static inline void AddConstant_avx2(__m256i state[6], const int rn)
{
    static const alignas(32) uint64_t round_constants[18][4] = {
        {0x13198A2E03707344ULL, 0x243F6A8885A308D3ULL, 0, 0},
        {0x13188A2F03717345ULL, 0x243E6A8985A208D2ULL, 0, 0},
        {0x131B8A2C03727346ULL, 0x243D6A8A85A108D1ULL, 0, 0},
        {0x131A8A2D03737347ULL, 0x243C6A8B85A008D0ULL, 0, 0},
        {0x131D8A2A03747340ULL, 0x243B6A8C85A708D7ULL, 0, 0},
        {0x131C8A2B03757341ULL, 0x243A6A8D85A608D6ULL, 0, 0},
        {0x131F8A2803767342ULL, 0x24396A8E85A508D5ULL, 0, 0},
        {0x131E8A2903777343ULL, 0x24386A8F85A408D4ULL, 0, 0},
        {0x13118A260378734CULL, 0x24376A8085AB08DBULL, 0, 0},
        {0x13108A270379734DULL, 0x24366A8185AA08DAULL, 0, 0},
        {0x13138A24037A734EULL, 0x24356A8285A908D9ULL, 0, 0},
        {0x13128A25037B734FULL, 0x24346A8385A808D8ULL, 0, 0},
        {0x13158A22037C7348ULL, 0x24336A8485AF08DFULL, 0, 0},
        {0x13148A23037D7349ULL, 0x24326A8585AE08DEULL, 0, 0},
        {0x13178A20037E734AULL, 0x24316A8685AD08DDULL, 0, 0},
        {0x13168A21037F734BULL, 0x24306A8785AC08DCULL, 0, 0},
        {0x13098A3E03607354ULL, 0x242F6A9885B308C3ULL, 0, 0},
        {0x13088A3F03617355ULL, 0x242E6A9985B208C2ULL, 0, 0}
    };

    const __m256i c = _mm256_load_si256((const __m256i *)round_constants[rn]);
    state[0] = _mm256_xor_si256(state[0], c);

    return;
}

static inline void _core_avx2(__m256i state[6], const int n_rounds)
{
    //#pragma GCC unroll 20
    for (int i = 0; i < n_rounds; ++i) {
        CrossMixs_avx2(state);
        SwapRows_avx2(state);

        MAndRXs_avx2(state, state + 3,  0, 1, 8);
        MAndRXs_avx2(state + 3, state, 14, 5, 0);
        MAndRXs_avx2(state, state + 3, 9, 12, 8);
        MAndRXs_avx2(state + 3, state, 14, 5, 0);
        MAndRXs_avx2(state, state + 3,  0, 1, 8);
        MAndRXs_avx2(state + 3, state,  8, 9, 0);

        CrossMixs_avx2(state);
        SwapRows_avx2(state);

        MixColumns_avx2(state);
        ShiftRows_avx2(state, state + 3);
        MixRows_avx2(state);

        AddConstant_avx2(state, i);
    }

    return;
}

static inline void _core_inverse_avx2(__m256i state[6], const int n_rounds)
{
    //#pragma GCC unroll 20
    for (int i = n_rounds - 1; i >= 0; --i) {
        AddConstant_avx2(state, i + 9);

        MixRows_avx2(state);
        ShiftRows_avx2(state + 3, state);
        MixColumns_avx2(state);

        SwapRows_avx2(state);
        CrossMixs_avx2(state);

        MAndRXs_avx2(state + 3, state,  8, 9, 0);
        MAndRXs_avx2(state, state + 3,  0, 1, 8);
        MAndRXs_avx2(state + 3, state, 14, 5, 0);
        MAndRXs_avx2(state, state + 3, 9, 12, 8);
        MAndRXs_avx2(state + 3, state, 14, 5, 0);
        MAndRXs_avx2(state, state + 3,  0, 1, 8);

        for (int j = 0; j < 3; ++j) {
            __m256i tmp = state[j];
            state[j] = state[j + 3];
            state[j + 3] = tmp;
        }

        SwapRows_avx2(state);
        CrossMixs_avx2(state);
    }

    return;
}

static inline void zip_prf_avx2(__m256i state[6])
{
    __m256i state_copy[6];
    memcpy(state_copy, state, 6 * sizeof(__m256i));

    _core_avx2(state, N_ROUNDS_avx2 / 2);

    _core_inverse_avx2(state_copy, N_ROUNDS_avx2 / 2);

    for (int i = 0; i < 6; ++i)
        state[i] = _mm256_xor_si256(state[i], state_copy[i]);

    return;
}

static void mc_transform_avx2(__m256i state[6])
{
    zip_prf_avx2(state);
    return;
}


static inline void _sponge_absorb_helper_avx2(void (*transform)(__m256i *), __m256i state[6], const int block_bits, const unsigned char *message, const uint64_t message_bits)
{
    for (int row = 0; row < 6; ++row)
        state[row] = _mm256_setzero_si256();

    const int block_bytes = block_bits / 8;
    const int n_m256_per_block = block_bits / 256; // _m256i reg
    const int m256_bytes = 256 / 8; // _m256i reg
    const uint64_t message_bytes = (message_bits + 7) / 8;
    const uint64_t n_block = message_bits / block_bits; // number of full blocks
    uint8_t last_block[136] = {0x00}; // the last and unaligned block, allocate the largest potential needed size, and pad with 0x00

    // copy and turn the last unaligned block to a padded full block
    const uint64_t last_index = n_block * block_bytes;
    memcpy(last_block, message + last_index, message_bytes - last_index);
    pad10star1(last_block, message_bits % block_bits, block_bits);

    for (uint64_t i = 0; i < n_block; ++i) {
        for (int j = 0; j < n_m256_per_block; ++j) {
            __m256i chunk = _mm256_loadu_si256((const __m256i*)(message + block_bytes * i + m256_bytes * j));
            state[j] = _mm256_xor_si256(state[j], chunk);
        }

        uint8_t unaligned_piece[32] = {0};
        memcpy(unaligned_piece, message + block_bytes * i + m256_bytes * n_m256_per_block, block_bytes - m256_bytes * n_m256_per_block);
        __m256i chunk = _mm256_loadu_si256((const __m256i*)unaligned_piece);
        state[n_m256_per_block] = _mm256_xor_si256(state[n_m256_per_block], chunk);

        transform(state);
    }
    {
        for (int j = 0; j < n_m256_per_block; ++j) {
            __m256i chunk = _mm256_loadu_si256((const __m256i*)(last_block + m256_bytes * j));
            state[j] = _mm256_xor_si256(state[j], chunk);
        }
        uint8_t unaligned_piece[32] = {0};
        memcpy(unaligned_piece, last_block + m256_bytes * n_m256_per_block, block_bytes - m256_bytes * n_m256_per_block);
        __m256i chunk = _mm256_loadu_si256((const __m256i*)unaligned_piece);
        state[n_m256_per_block] = _mm256_xor_si256(state[n_m256_per_block], chunk);

        transform(state);
    }

    return;
}

static inline void _sponge_squeeze_helper_avx2(void (*transform)(__m256i *), __m256i state[6], const int block_bits, unsigned char *digest, const int digest_bits)
{
    const int digest_bytes = digest_bits / 8;
    const int block_bytes = block_bits / 8;
    const int n_block = (digest_bytes + block_bytes - 1) / block_bytes;

    const int n_m256_per_block  = (block_bits  + 256 - 1) / 256; // _m128i reg
    const int n_m256_per_digest = (digest_bits + 256 - 1) / 256; // _m128i reg
    const int n_m256_per_iter   = n_m256_per_block < n_m256_per_digest ? n_m256_per_block : n_m256_per_digest;

    uint8_t buffer[3][768 / 8];

    for (int i = 0; i < n_block; ++i) { // max: 3 (the 1024 case)
        for (int j = 0; j < n_m256_per_iter; ++j) // max: 3 (the 768 case)
            _mm256_storeu_si256((__m256i *)(buffer[i] + 32 * j), state[j]);

        transform(state);
    }

    if (digest_bytes <= block_bytes) {
        memcpy(digest, buffer[0], digest_bytes);
    } else if (digest_bytes <= 2 * block_bytes) {
        memcpy(digest, buffer[0], block_bytes);
        memcpy(digest + block_bytes, buffer[1], digest_bytes - block_bytes);
    } else if (digest_bytes <= 3 * block_bytes) {
        memcpy(digest, buffer[0], block_bytes);
        memcpy(digest + block_bytes, buffer[1], block_bytes);
        memcpy(digest + 2 * block_bytes, buffer[2], digest_bytes - 2 * block_bytes);
    }

    return;
}

static inline void _sponge_squeeze_768_direct_avx2(void (*transform)(__m256i *), __m256i state[6], unsigned char *digest)
{
    _mm256_storeu_si256((__m256i *)(void *)(digest + 0), state[0]);
    _mm256_storeu_si256((__m256i *)(void *)(digest + 32), state[1]);
    _mm_storeu_si128((__m128i *)(void *)(digest + 64), _mm256_castsi256_si128(state[2]));
    _mm_storel_epi64((__m128i *)(void *)(digest + 80), _mm256_extracti128_si256(state[2], 1));

    transform(state);

    _mm_storel_epi64((__m128i *)(void *)(digest + 88), _mm256_castsi256_si128(state[0]));

    return;
}

int MasterCube768_avx2(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest)
{
    __m256i state[6] = {0};

    enum {
        digest_bits = 768, // bits
        block_bits = 704 // bits
    };

    _sponge_absorb_helper_avx2(mc_transform_avx2, state, block_bits, message, message_bit_len);
    _sponge_squeeze_768_direct_avx2(mc_transform_avx2, state, digest);

    return 0;
}

#endif /* AVX2 */


/****************************************************************************
 * AVX-512 (256-bit) Implementation
 ****************************************************************************/
#if defined (__AVX512F__) && defined (__AVX512BW__) && defined (__AVX512VL__)

static const int N_ROUNDS_a512 = 18;

static inline __m256i ror16_optimized_a512(const __m256i x, const int n_ror)
{
    switch (n_ror) {
        case 0:
        case 16:
            return x;
            break;

        case 8:
            return _mm256_shuffle_epi8(
                x,
                _mm256_setr_epi8(
                    1, 0, 3, 2, 5, 4, 7, 6, 9, 8, 11, 10, 13, 12, 15, 14,
                    1, 0, 3, 2, 5, 4, 7, 6, 9, 8, 11, 10, 13, 12, 15, 14
                )
            );
            break;

        default:
            return _mm256_or_si256(
                _mm256_srli_epi16(x, n_ror),
                _mm256_slli_epi16(x, 16 - n_ror)
            );
    }
}

static inline void MAndRXs_a512(__m256i state_l[3], __m256i state_r[3], const int alpha, const int beta, const int gamma)
{
    for (int i = 0; i < 3; ++i) {
        const __m256i x = state_l[i];
        const __m256i y = state_r[i];
        const __m256i a = ror16_optimized_a512(x, alpha);
        const __m256i b = ror16_optimized_a512(x, beta);
        const __m256i c = ror16_optimized_a512(x, gamma);
        state_r[i] = _mm256_ternarylogic_epi32(_mm256_xor_si256(c, y), b, a, 0x78);
    }

    return;
}

static inline void ShiftRows_a512(__m256i state_l[3], __m256i state_r[3])
{
    state_l[0] = _mm256_shuffle_epi8(
        state_l[0],
        _mm256_setr_epi8(
            0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
            2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0, 1
        )
    );
    state_l[1] = _mm256_shuffle_epi8(
        state_l[1],
        _mm256_setr_epi8(
            4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3,
            6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5
        )
    );
    state_l[2] = _mm256_shuffle_epi8(
        state_l[2],
        _mm256_setr_epi8(
            8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7,
            10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9
        )
    );

    state_r[0] = _mm256_shuffle_epi8(
        state_r[0],
        _mm256_setr_epi8(
            0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
            14, 15, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13
        )
    );
    state_r[1] = _mm256_shuffle_epi8(
        state_r[1],
        _mm256_setr_epi8(
            12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11,
            10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9
        )
    );
    state_r[2] = _mm256_shuffle_epi8(
        state_r[2],
        _mm256_setr_epi8(
            8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5, 6, 7,
            6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0, 1, 2, 3, 4, 5
        )
    );

    return;
}

static inline __m256i mix_row_32x4_a512(__m256i x)
{
    // Rotate left by 32 bits (1 word) in each 128-bit lane
    __m256i pre = _mm256_shuffle_epi32(x, _MM_SHUFFLE_R(1, 2, 3, 0));
    // Rotate left by 96 bits (3 words) in each 128-bit lane
    __m256i post = _mm256_shuffle_epi32(x, _MM_SHUFFLE_R(3, 0, 1, 2));

    return _mm256_ternarylogic_epi32(pre, x, post, 0x96);
}

static inline void MixRows_a512(__m256i state[6])
{
    state[0] = mix_row_32x4_a512(state[0]);
    state[1] = mix_row_32x4_a512(state[1]);
    state[2] = mix_row_32x4_a512(state[2]);
    state[3] = mix_row_32x4_a512(state[3]);
    state[4] = mix_row_32x4_a512(state[4]);
    state[5] = mix_row_32x4_a512(state[5]);

    return;
}

static inline void SwapRows_a512(__m256i state[6])
{
    //#pragma GCC unroll 3
    for (int i = 0; i < 3; ++i) {
        __m256i x = state[i + 3];
        state[i + 3] = _mm256_permute2x128_si256(x, x, 0x01);
    }
    return;
}

static inline void CrossMixs_a512(__m256i state[6])
{
    static const int arrange[6] = {0, 1, 2, 3, 4, 5};
    __m256i tmp[6];
    memcpy(tmp, state, sizeof(tmp));

    //#pragma GCC unroll 6
    for (int j = 0; j < 6; ++j) {
        __m256i a = tmp[arrange[j]];
        __m256i b = tmp[arrange[(j + 1) % 6]];
        __m256i c = tmp[arrange[(j + 4) % 6]];
        state[arrange[j]] = _mm256_ternarylogic_epi32(a, b, c, 0x96);
    }

    return;
}

static inline void MixColumns_a512(__m256i state[6])
{
    __m256i tmp0 = _mm256_xor_si256(state[1], state[2]);
    __m256i tmp1 = _mm256_xor_si256(state[0], state[2]);
    __m256i tmp2 = _mm256_ternarylogic_epi32(state[0], state[1], state[2], 0x96);
    state[0] = tmp0;
    state[1] = tmp1;
    state[2] = tmp2;

    __m256i tmp3 = _mm256_xor_si256(state[3], state[5]);
    __m256i tmp4 = _mm256_xor_si256(state[4], state[5]);
    __m256i tmp5 = _mm256_ternarylogic_epi32(state[3], state[4], state[5], 0x96);
    state[3] = tmp3;
    state[4] = tmp4;
    state[5] = tmp5;

    return;
}

static inline void AddConstant_a512(__m256i state[6], const int rn)
{
    const __m128i c = _mm_set_epi64x(
        0x243F6A8885A308D3ULL,  // high 64 bits
        0x13198A2E03707344ULL   // low 64 bits
    );
    const __m256i c256 = _mm256_zextsi128_si256(c);

    const __m128i x = _mm_set1_epi16((short)rn);
    const __m256i x256 = _mm256_zextsi128_si256(x);

    state[0] = _mm256_ternarylogic_epi32(state[0], c256, x256, 0x96);

    return;
}

static inline void _core_a512(__m256i state[6], const int n_rounds)
{
    //#pragma GCC unroll 20
    for (int i = 0; i < n_rounds; ++i) {
        CrossMixs_a512(state);
        SwapRows_a512(state);

        MAndRXs_a512(state, state + 3,  0, 1, 8);
        MAndRXs_a512(state + 3, state, 14, 5, 0);
        MAndRXs_a512(state, state + 3, 9, 12, 8);
        MAndRXs_a512(state + 3, state, 14, 5, 0);
        MAndRXs_a512(state, state + 3,  0, 1, 8);
        MAndRXs_a512(state + 3, state,  8, 9, 0);

        CrossMixs_a512(state);
        SwapRows_a512(state);

        MixColumns_a512(state);
        ShiftRows_a512(state, state + 3);
        MixRows_a512(state);

        AddConstant_a512(state, i);
    }

    return;
}

static inline void _core_inverse_a512(__m256i state[6], const int n_rounds)
{
    //#pragma GCC unroll 20
    for (int i = n_rounds - 1; i >= 0; --i) {
        AddConstant_a512(state, i + 9);

        MixRows_a512(state);
        ShiftRows_a512(state + 3, state);
        MixColumns_a512(state);

        SwapRows_a512(state);
        CrossMixs_a512(state);

        MAndRXs_a512(state + 3, state,  8, 9, 0);
        MAndRXs_a512(state, state + 3,  0, 1, 8);
        MAndRXs_a512(state + 3, state, 14, 5, 0);
        MAndRXs_a512(state, state + 3, 9, 12, 8);
        MAndRXs_a512(state + 3, state, 14, 5, 0);
        MAndRXs_a512(state, state + 3,  0, 1, 8);

        for (int j = 0; j < 3; ++j) {
            __m256i tmp = state[j];
            state[j] = state[j + 3];
            state[j + 3] = tmp;
        }

        SwapRows_a512(state);
        CrossMixs_a512(state);
    }

    return;
}

static inline void zip_prf_a512(__m256i state[6])
{
    __m256i state_copy[6];
    memcpy(state_copy, state, 6 * sizeof(__m256i));

    _core_a512(state, N_ROUNDS_a512 / 2);

    _core_inverse_a512(state_copy, N_ROUNDS_a512 / 2);

    for (int i = 0; i < 6; ++i)
        state[i] = _mm256_xor_si256(state[i], state_copy[i]);

    return;
}

static void mc_transform_a512(__m256i state[6])
{
    zip_prf_a512(state);
    return;
}


static inline void _sponge_absorb_helper_a512(void (*transform)(__m256i *), __m256i state[6], const int block_bits, const unsigned char *message, const uint64_t message_bits)
{
    for (int row = 0; row < 6; ++row)
        state[row] = _mm256_setzero_si256();

    const int block_bytes = block_bits / 8;
    const int n_m256_per_block = block_bits / 256; // _m256i reg
    const int m256_bytes = 256 / 8; // _m256i reg
    const uint64_t message_bytes = (message_bits + 7) / 8;
    const uint64_t n_block = message_bits / block_bits; // number of full blocks
    uint8_t last_block[136] = {0x00}; // the last and unaligned block, allocate the largest potential needed size, and pad with 0x00

    // copy and turn the last unaligned block to a padded full block
    const uint64_t last_index = n_block * block_bytes;
    memcpy(last_block, message + last_index, message_bytes - last_index);
    pad10star1(last_block, message_bits % block_bits, block_bits);

    for (uint64_t i = 0; i < n_block; ++i) {
        for (int j = 0; j < n_m256_per_block; ++j) {
            __m256i chunk = _mm256_loadu_si256((const __m256i*)(message + block_bytes * i + m256_bytes * j));
            state[j] = _mm256_xor_si256(state[j], chunk);
        }

        const int tail_bytes = block_bytes - m256_bytes * n_m256_per_block;
        const __mmask32 k = (__mmask32)((1u << tail_bytes) - 1u);
        __m256i chunk = _mm256_maskz_loadu_epi8(k, message + block_bytes * i + m256_bytes * n_m256_per_block);
        state[n_m256_per_block] = _mm256_xor_si256(state[n_m256_per_block], chunk);

        transform(state);
    }
    {
        for (int j = 0; j < n_m256_per_block; ++j) {
            __m256i chunk = _mm256_loadu_si256((const __m256i*)(last_block + m256_bytes * j));
            state[j] = _mm256_xor_si256(state[j], chunk);
        }

        const int tail_bytes = block_bytes - m256_bytes * n_m256_per_block;
        const __mmask32 k = (__mmask32)((1u << tail_bytes) - 1u);
        __m256i chunk = _mm256_maskz_loadu_epi8(k, last_block + m256_bytes * n_m256_per_block);
        state[n_m256_per_block] = _mm256_xor_si256(state[n_m256_per_block], chunk);

        transform(state);
    }

    return;
}

static inline void _sponge_squeeze_helper_a512(void (*transform)(__m256i *), __m256i state[6], const int block_bits, unsigned char *digest, const int digest_bits)
{
    const int digest_bytes = digest_bits / 8;
    const int block_bytes = block_bits / 8;
    const int n_block = (digest_bytes + block_bytes - 1) / block_bytes;

    const int n_m256_per_block  = (block_bits  + 256 - 1) / 256; // _m128i reg
    const int n_m256_per_digest = (digest_bits + 256 - 1) / 256; // _m128i reg
    const int n_m256_per_iter   = n_m256_per_block < n_m256_per_digest ? n_m256_per_block : n_m256_per_digest;

    uint8_t buffer[3][768 / 8];

    for (int i = 0; i < n_block; ++i) { // max: 3 (the 1024 case)
        for (int j = 0; j < n_m256_per_iter; ++j) // max: 3 (the 768 case)
            _mm256_storeu_si256((__m256i *)(buffer[i] + 32 * j), state[j]);

        transform(state);
    }

    if (digest_bytes <= block_bytes) {
        memcpy(digest, buffer[0], digest_bytes);
    } else if (digest_bytes <= 2 * block_bytes) {
        memcpy(digest, buffer[0], block_bytes);
        memcpy(digest + block_bytes, buffer[1], digest_bytes - block_bytes);
    } else if (digest_bytes <= 3 * block_bytes) {
        memcpy(digest, buffer[0], block_bytes);
        memcpy(digest + block_bytes, buffer[1], block_bytes);
        memcpy(digest + 2 * block_bytes, buffer[2], digest_bytes - 2 * block_bytes);
    }

    return;
}

int MasterCube768_avx512_256(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest)
{
    __m256i state[6] = {0};

    enum {
        digest_bits = 768, // bits
        block_bits = 704 // bits
    };

    _sponge_absorb_helper_a512(mc_transform_a512, state, block_bits, message, message_bit_len);
    _sponge_squeeze_helper_a512(mc_transform_a512, state, block_bits, digest, digest_bits);

    return 0;
}

#endif /* AVX-512 */
