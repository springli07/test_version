# x86_64_avx2 Round2 进展

本轮先完成 A036-A039 四个源码候选，随后继续按 digest-only 优化 squeeze/absorb 热路径。最终保留 A040、A043、A046；A041、A042、A044、A045、A047、A048 拒绝。

固定长度顺序为 `16B/64B/256B/1KB/16KB/64KB`。

## 新增 retained

- A040 `768` direct squeeze：语义 `KAT_2_12 + random 10000` 通过；r21 768=`1.4440/1.4457/1.2575/1.0755/1.0072/1.0012`，保留 `MasterCube-768.c`。
- A043 `512` CrossMixs direct + direct squeeze/tail24：语义通过；r21 512=`1.4408/1.4254/1.1797/1.0748/1.0341/1.0229`，保留 `MasterCube-512.c`。
- A046 `1024` specialized absorb + direct squeeze：语义通过；r21 1024=`1.3340/1.2800/1.1786/1.0840/1.0390/1.0422`，保留 `MasterCube-1024.c`。

## 拒绝项

- A041 tail24 load all：收益小且不稳定，拒绝。
- A042/A044/A045 1024 direct squeeze 变体：短消息快但长消息或平均不如 A046，拒绝。
- A047 zipcopy/final xor on A046：1024 六个长度全部慢，拒绝。
- A048 maskload tail24 on A046：语义通过，但收益不稳定且 64KB 回退，拒绝。

最终 retained 语义 `KAT_2_12 + random 50000` 全 PASS；日志为 `version_results/server_final_x86_64_avx2_after_A040_A043_A046_semantic50000/semantic_kat_random.log`。最终 pair CSV 为 `version_results/server_final_x86_64_avx2_after_A040_A043_A046_vs_original_pair_r21/pair_cycles_summary.csv`。
