# x86_64_avx2 服务器结果分析

- 保留：A040 768 direct squeeze，A043 512 CrossMixs direct + direct squeeze/tail24，A046 1024 specialized absorb + direct squeeze。
- 拒绝：A041、A042、A044、A045、A047、A048；这些候选语义通过，但平均不如最终 retained 或存在长消息回退。
- 最终语义：`version_results/server_final_x86_64_avx2_after_A040_A043_A046_semantic50000/semantic_kat_random.log`，512/768/1024 均 `KAT_2_12 PASS` 和 `RANDOM PASS`。
- 最终 pair：`version_results/server_final_x86_64_avx2_after_A040_A043_A046_vs_original_pair_r21/pair_cycles_summary.csv`。

固定长度顺序为 `16B/64B/256B/1KB/16KB/64KB`。

| digest | speedup | 平均 |
| --- | --- | --- |
| 512 | `1.4672/1.4513/1.2000/1.0752/1.0366/1.0308` | `1.2102` |
| 768 | `1.4980/1.4765/1.2645/1.1119/1.0293/1.0269` | `1.2345` |
| 1024 | `1.3930/1.3279/1.2027/1.1105/1.0787/1.0682` | `1.1968` |

说明：512/768 平均超过 20%；1024 平均 `1.1968`，非常接近 20%，且六个固定长度全部加速。
