#include <openssl/evp.h>
#include <stdint.h>
#include <stdalign.h>
#include <stdint.h>
#include <string.h>

#include "mastercube.h"
#include "macros.h"
#include "common.h"

#if (!defined (__AVX512F__) || !defined (__AVX512BW__) || !defined (__AVX512VL__)) && !defined(__AVX2__) && !defined(__SSE4_2__)

static const int N_ROUNDS = 18;

static const uint16_t MC_ADD_CONSTANT[8] = {
    0x7344, 0x0370, 0x8A2E, 0x1319,
    0x08D3, 0x85A3, 0x6A88, 0x243F
};

/*
 * row-major matrices
 */
struct xy_slice {
    union {
        alignas(16) uint16_t slice[6][8];
        uint16_t row[6][8];
        uint64_t row64[6][2];
        uint16_t raw_data[48];
    };
};
struct mc_state {
    union {
        struct {
            struct xy_slice left;
            struct xy_slice right;
        };

        uint16_t row[12][8];
        uint64_t row64[12][2];
        uint32_t row32[12][4];
        uint16_t raw_data[96];
        uint32_t pair32[6][8];
        uint64_t pair64[6][4];
    };
};

static inline uint16_t ror16(const uint16_t x, const int n_ror)
{
    if (n_ror == 0) return x;
    return (x >> n_ror) | (x << (16 - n_ror));
}

static inline void rotl_row16_1(uint64_t x[2])
{
    const uint64_t a = x[0];
    const uint64_t b = x[1];
    x[0] = (a >> 16) | (b << 48);
    x[1] = (b >> 16) | (a << 48);
}

static inline void rotl_row16_2(uint64_t x[2])
{
    const uint64_t a = x[0];
    const uint64_t b = x[1];
    x[0] = (a >> 32) | (b << 32);
    x[1] = (b >> 32) | (a << 32);
}

static inline void rotl_row16_3(uint64_t x[2])
{
    const uint64_t a = x[0];
    const uint64_t b = x[1];
    x[0] = (a >> 48) | (b << 16);
    x[1] = (b >> 48) | (a << 16);
}

static inline void rotl_row16_4(uint64_t x[2])
{
    const uint64_t a = x[0];
    x[0] = x[1];
    x[1] = a;
}

static inline void rotl_row16_5(uint64_t x[2])
{
    const uint64_t a = x[0];
    const uint64_t b = x[1];
    x[0] = (b >> 16) | (a << 48);
    x[1] = (a >> 16) | (b << 48);
}

static inline void rotr_row16_1(uint64_t x[2])
{
    const uint64_t a = x[0];
    const uint64_t b = x[1];
    x[0] = (a << 16) | (b >> 48);
    x[1] = (b << 16) | (a >> 48);
}

static inline void rotr_row16_2(uint64_t x[2])
{
    const uint64_t a = x[0];
    const uint64_t b = x[1];
    x[0] = (a << 32) | (b >> 32);
    x[1] = (b << 32) | (a >> 32);
}

static inline void rotr_row16_3(uint64_t x[2])
{
    rotl_row16_5(x);
}

static inline void rotr_row16_4(uint64_t x[2])
{
    rotl_row16_4(x);
}

static inline void rotr_row16_5(uint64_t x[2])
{
    rotl_row16_3(x);
}

static inline void MAndRXs(struct xy_slice *state_l, struct xy_slice *state_r, const int alpha, const int beta, const int gamma)
{
    for (int i = 0; i < 6; ++i)
        for (int j = 0; j < 8; ++j) {
            const uint16_t x = state_l->slice[i][j];
            const uint16_t y = state_r->slice[i][j];
            const uint16_t a = ror16(x, alpha);
            const uint16_t b = ror16(x, beta);
            const uint16_t c = ror16(x, gamma);
            state_r->slice[i][j] = (a & b) ^ c ^ y;
        }

    return;
}

static inline void ShiftRows(struct xy_slice *state_l, struct xy_slice *state_r)
{
    rotl_row16_1(state_l->row64[1]);
    rotl_row16_2(state_l->row64[2]);
    rotl_row16_3(state_l->row64[3]);
    rotl_row16_4(state_l->row64[4]);
    rotl_row16_5(state_l->row64[5]);

    rotr_row16_1(state_r->row64[1]);
    rotr_row16_2(state_r->row64[2]);
    rotr_row16_3(state_r->row64[3]);
    rotr_row16_4(state_r->row64[4]);
    rotr_row16_5(state_r->row64[5]);
}

static inline void mix_row_64x2(uint64_t x[2])
{
    const uint64_t a = x[0];
    const uint64_t b = x[1];
    x[0] = a ^ ((a >> 32) | (b << 32)) ^ ((a << 32) | (b >> 32));
    x[1] = b ^ ((b >> 32) | (a << 32)) ^ ((b << 32) | (a >> 32));
}

static inline void MixRows(struct mc_state *state)
{
    for (int i = 0; i < 12; ++i)
        mix_row_64x2(state->row64[i]);
}

static inline void SwapRows(struct mc_state *state)
{
    struct xy_slice tmp;
    memcpy(tmp.raw_data, state->right.raw_data, sizeof(struct xy_slice));

    memcpy(state->right.slice[0], tmp.slice[1], 16);
    memcpy(state->right.slice[1], tmp.slice[0], 16);

    memcpy(state->right.slice[2], tmp.slice[3], 16);
    memcpy(state->right.slice[3], tmp.slice[2], 16);

    memcpy(state->right.slice[4], tmp.slice[5], 16);
    memcpy(state->right.slice[5], tmp.slice[4], 16);

    return;
}

static inline void SwapSlices64(struct mc_state *state)
{
    for (int i = 0; i < 6; ++i) {
        const uint64_t l0 = state->left.row64[i][0];
        const uint64_t l1 = state->left.row64[i][1];
        state->left.row64[i][0] = state->right.row64[i][0];
        state->left.row64[i][1] = state->right.row64[i][1];
        state->right.row64[i][0] = l0;
        state->right.row64[i][1] = l1;
    }
}

static inline void CrossMixs(struct mc_state *state)
{
#if defined(__ARM_ARCH_7EM__) || defined(__ARM_ARCH_7M__)
    for (int j = 0; j < 8; ++j) {
        const uint32_t x0 = state->pair32[0][j];
        const uint32_t x1 = state->pair32[1][j];
        const uint32_t x2 = state->pair32[2][j];
        const uint32_t x3 = state->pair32[3][j];
        const uint32_t x4 = state->pair32[4][j];
        const uint32_t x5 = state->pair32[5][j];

        state->pair32[0][j] = x0 ^ x1 ^ x4;
        state->pair32[1][j] = x1 ^ x2 ^ x5;
        state->pair32[2][j] = x2 ^ x3 ^ x0;
        state->pair32[3][j] = x3 ^ x4 ^ x1;
        state->pair32[4][j] = x4 ^ x5 ^ x2;
        state->pair32[5][j] = x5 ^ x0 ^ x3;
    }
#else
    for (int j = 0; j < 4; ++j) {
        const uint64_t x0 = state->pair64[0][j];
        const uint64_t x1 = state->pair64[1][j];
        const uint64_t x2 = state->pair64[2][j];
        const uint64_t x3 = state->pair64[3][j];
        const uint64_t x4 = state->pair64[4][j];
        const uint64_t x5 = state->pair64[5][j];

        state->pair64[0][j] = x0 ^ x1 ^ x4;
        state->pair64[1][j] = x1 ^ x2 ^ x5;
        state->pair64[2][j] = x2 ^ x3 ^ x0;
        state->pair64[3][j] = x3 ^ x4 ^ x1;
        state->pair64[4][j] = x4 ^ x5 ^ x2;
        state->pair64[5][j] = x5 ^ x0 ^ x3;
    }
#endif


    return;
}

static inline void MixColumns(struct mc_state *state)
{
    for (int j = 0; j < 2; ++j) {
        const uint64_t x0 = state->row64[0][j];
        const uint64_t x2 = state->row64[2][j];
        const uint64_t x4 = state->row64[4][j];
        state->row64[0][j] = x2 ^ x4;
        state->row64[2][j] = x0 ^ x4;
        state->row64[4][j] = x0 ^ x2 ^ x4;

        const uint64_t x1 = state->row64[1][j];
        const uint64_t x3 = state->row64[3][j];
        const uint64_t x5 = state->row64[5][j];
        state->row64[1][j] = x3 ^ x5;
        state->row64[3][j] = x1 ^ x5;
        state->row64[5][j] = x1 ^ x3 ^ x5;

        const uint64_t x6 = state->row64[6][j];
        const uint64_t x8 = state->row64[8][j];
        const uint64_t x10 = state->row64[10][j];
        state->row64[6][j] = x6 ^ x10;
        state->row64[8][j] = x8 ^ x10;
        state->row64[10][j] = x6 ^ x8 ^ x10;

        const uint64_t x7 = state->row64[7][j];
        const uint64_t x9 = state->row64[9][j];
        const uint64_t x11 = state->row64[11][j];
        state->row64[7][j] = x7 ^ x11;
        state->row64[9][j] = x9 ^ x11;
        state->row64[11][j] = x7 ^ x9 ^ x11;
    }
}

static inline void AddConstant(struct mc_state *state, const int rn)
{
    const uint16_t r = (uint16_t)rn;
    state->row[0][0] ^= MC_ADD_CONSTANT[0] ^ r;
    state->row[0][1] ^= MC_ADD_CONSTANT[1] ^ r;
    state->row[0][2] ^= MC_ADD_CONSTANT[2] ^ r;
    state->row[0][3] ^= MC_ADD_CONSTANT[3] ^ r;
    state->row[0][4] ^= MC_ADD_CONSTANT[4] ^ r;
    state->row[0][5] ^= MC_ADD_CONSTANT[5] ^ r;
    state->row[0][6] ^= MC_ADD_CONSTANT[6] ^ r;
    state->row[0][7] ^= MC_ADD_CONSTANT[7] ^ r;
}

static inline void _core(struct mc_state *state, const int n_rounds)
{
    //#pragma GCC unroll 20
    for (int i = 0; i < n_rounds; ++i) {
        CrossMixs(state);
        SwapRows(state);

        MAndRXs(&state->left, &state->right,  0, 1, 8);
        MAndRXs(&state->right, &state->left, 14, 5, 0);
        MAndRXs(&state->left, &state->right, 9, 12, 8);
        MAndRXs(&state->right, &state->left, 14, 5, 0);
        MAndRXs(&state->left, &state->right, 0, 1, 8);
        MAndRXs(&state->right, &state->left, 8, 9, 0);

        CrossMixs(state);
        SwapRows(state);

        MixColumns(state);
        ShiftRows(&state->left, &state->right);
        MixRows(state);

        AddConstant(state, i);
    }

    return;
}

static inline void _core_inverse(struct mc_state *state, const int n_rounds)
{

    for (int i = n_rounds - 1; i >= 0; --i) {
        AddConstant(state, i + 9); // for 18 rounds mcube

        MixRows(state);

        ShiftRows(&state->right, &state->left);

        MixColumns(state);

        SwapRows(state);
        CrossMixs(state);

        MAndRXs(&state->right, &state->left, 8, 9, 0);
        MAndRXs(&state->left, &state->right, 0, 1, 8);
        MAndRXs(&state->right, &state->left, 14, 5, 0);
        MAndRXs(&state->left, &state->right, 9, 12, 8);
        MAndRXs(&state->right, &state->left, 14, 5, 0);
        MAndRXs(&state->left, &state->right,  0, 1, 8);

        SwapSlices64(state);

        SwapRows(state);
        CrossMixs(state);
    }

    return;
}

static inline void zip_prf(struct mc_state *state)
{
    struct mc_state state_copy;
    memcpy(state_copy.raw_data, state->raw_data, sizeof(struct mc_state));

    _core(state, N_ROUNDS / 2);

    _core_inverse(&state_copy, N_ROUNDS / 2);

    for (int i = 0; i < 12; ++i)
        for (int j = 0; j < 8; ++j)
            state->row[i][j] ^= state_copy.row[i][j];

    return;
}

static void mc_transform(struct mc_state *state)
{
    zip_prf(state);
    return;
}


static inline void _sponge_absorb_helper(void (*transform)(struct mc_state *), struct mc_state *state, const int block_bits, const unsigned char *message, const uint64_t message_bits)
{
    for (int i = 0; i < 12; ++i)
        for (int j = 0; j < 8; ++j)
            state->row[i][j] = 0x0000;

    const int block_bytes = block_bits / 8;
    const int n_m128_per_block = block_bits / 128; // _m128i reg
    const uint64_t message_bytes = (message_bits + 7) / 8;
    const uint64_t n_block = message_bits / block_bits; // number of full blocks
    uint8_t last_block[136] = {0x00}; // the last and unaligned block, allocate the largest potential needed size, and pad with 0x00

    // copy and turn the last unaligned block to a padded full block
    const uint64_t last_index = n_block * block_bytes;
    memcpy(last_block, message + last_index, message_bytes - last_index);
    pad10star1(last_block, message_bits % block_bits, block_bits);

    for (uint64_t i = 0; i < n_block; ++i) {
        for (int j = 0; j < n_m128_per_block; ++j) {
            for (int k = 0; k < 8; ++k)
                state->row[j][k] ^= ((uint16_t *)(message + block_bytes * i + 16 * j))[k];
        }
        for (int k = 0; k < 4; ++k)
            state->row[n_m128_per_block][k] ^= ((uint16_t *)(message + block_bytes * i + 16 * n_m128_per_block))[k];

        transform(state);
    }
    {
        for (int j = 0; j < n_m128_per_block; ++j) {
            for (int k = 0; k < 8; ++k)
                state->row[j][k] ^= ((uint16_t *)(last_block + 16 * j))[k];
        }
        for (int k = 0; k < 4; ++k)
            state->row[n_m128_per_block][k] ^= ((uint16_t *)(last_block + 16 * n_m128_per_block))[k];

        transform(state);
    }

    return;
}

static inline void _sponge_squeeze_helper(void (*transform)(struct mc_state *), struct mc_state *state, const int block_bits, unsigned char *digest, const int digest_bits)
{
    const int digest_bytes = digest_bits / 8;
    const int block_bytes = block_bits / 8;
    const int n_block = (digest_bytes + block_bytes - 1) / block_bytes;

    const int n_m128_per_block  = (block_bits  + 128 - 1) / 128; // _m128i reg
    const int n_m128_per_digest = (digest_bits + 128 - 1) / 128; // _m128i reg
    const int n_m128_per_iter   = n_m128_per_block < n_m128_per_digest ? n_m128_per_block : n_m128_per_digest;

    uint8_t buffer[3][768 / 8];

    for (int i = 0; i < n_block; ++i) { // max: 3 (the 1024 case)
        for (int j = 0; j < n_m128_per_iter; ++j) // max: 6 (the 768 case)
            memcpy(buffer[i] + 16 * j, state->row[j], 16);

        transform(state);
    }

    if (digest_bytes <= block_bytes) {
        memcpy(digest, buffer[0], digest_bytes);
    } else if (digest_bytes <= 2 * block_bytes) {
        memcpy(digest, buffer[0], block_bytes);
        memcpy(digest + block_bytes, buffer[1], digest_bytes - block_bytes);
    } else if (digest_bytes <= 3 * block_bytes) {
        memcpy(digest, buffer[0], block_bytes);
        memcpy(digest + block_bytes, buffer[1], block_bytes);
        memcpy(digest + 2 * block_bytes, buffer[2], digest_bytes - 2 * block_bytes);
    }

    return;
}


int MasterCube768_plain(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest)
{
    struct mc_state state = {0};

    enum {
        digest_bits = 768, // bits
        block_bits = 704 // bits
    };

    _sponge_absorb_helper(mc_transform, &state, block_bits, message, message_bit_len);
    _sponge_squeeze_helper(mc_transform, &state, block_bits, digest, digest_bits);

    return 0;
}

#else

int MasterCube768_plain(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest)
{
    UNUSED(message);
    UNUSED(message_bit_len);
    UNUSED(digest);
    return 1;
}

#endif
