# x86_64_plain Round2 进展

本轮完成 C015-C018 四个源码候选。C016 经 digest-only 拆分后仅保留 1024 的 `CrossMixs` row64 direct-register；C015、C017、C018 拒绝。

最终 retained 语义 `KAT_2_12 + random 50000` 全 PASS；最终 pair CSV 为 `version_results/server_final_x86_64_plain_retained_vs_reference_pair_r21/pair_cycles_summary.csv`。
