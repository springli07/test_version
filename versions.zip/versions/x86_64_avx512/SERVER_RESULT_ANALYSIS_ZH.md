# x86_64_avx512 服务器结果分析

- 保留：A003 512-only `CrossMixs_a512` direct-register；A004 768/1024-only aligned `AddConstant_a512` 常量表；A022 768 short squeeze XMM-tail；clean 1024 short squeeze continuation。
- 拒绝：A001 state copy、A002 final xor、A005 SwapRows、A006 inverse swap；A007-A019 在严格 6/6 规则下拒绝；A027、A032、A035-A047 在平均规则复测后仍低于 retained 或存在明显退化，拒绝。
- 最终语义：`KAT_2_12 + random 50000` 全 PASS，日志 `version_results/server_final_x86_64_avx512_retained_after_A022_A033_clean_semantic50000/semantic_kat_random.log`。
- 最终 pair CSV：`version_results/server_final_x86_64_avx512_retained_after_A022_A033_vs_original_pair_r21/pair_cycles_summary.csv`。

固定长度顺序为 `16B/64B/256B/1KB/16KB/64KB`。最终 retained-vs-original r21 speedup：

| digest | speedup | 平均 |
| --- | --- | --- |
| 512 | `1.4128/1.4192/1.1669/1.0588/1.0101/1.0040` | `1.1786` |
| 768 | `1.4534/1.4658/1.2682/1.1074/1.0267/1.0294` | `1.2251` |
| 1024 | `1.3232/1.2544/1.1534/1.0867/1.0244/1.0517` | `1.1490` |

2026-06-14 复查结论：按用户更新后的平均提升规则，768 通过 A022 从原先约 2%-4% 提升到平均 `1.2251`，已经超过 20%。1024 继续尝试了 short squeeze、long squeeze skip-final、zip copy/xor、CrossMixs direct、SwapRows explicit、fixed absorb、all-length direct squeeze、byte-aligned absorb、MAndRXs unroll 和 inline 调整；最终所有固定长度都快于 original，但平均为 `1.1490`，未达到 20%。1024 未继续保留噪声区候选，以避免把局部慢化混入 retained。
