# x86_64_avx512 Round2 进展

本轮在 AVX-512 真机上完成 45 个源码候选。按 512/768/1024 独立判定：A003 保留 512，A004 保留 768/1024 的 aligned constants，A022 保留 768 short squeeze，干净的 1024 short squeeze continuation 保留到 `MasterCube-1024.c`；其余候选拒绝。

固定长度顺序均为 `16B,64B,256B,1KB,16KB,64KB`。最终 retained 语义 `KAT_2_12 + random 50000` 全 PASS，最终 pair CSV 为 `version_results/server_final_x86_64_avx512_retained_after_A022_A033_vs_original_pair_r21/pair_cycles_summary.csv`。

2026-06-14 继续针对 768/1024 做了额外候选：direct/short squeeze、skip final transform、`CrossMixs_a512` direct、fixed-parameter `MAndRXs_a512`、fixed-block absorb helper。所有候选均通过 `KAT_2_12 + random 10000`，但没有一个候选满足目标 digest 六个固定长度全部严格加速，因此没有复制回 retained 源码。

代表性拒绝结果：

- A014 768 short-squeeze only：768 r21 `1.4337/1.4383/1.2375/1.0746/0.9915/1.0007`，短消息快但 16KB 慢。
- A016 1024 cold short-squeeze：1024 r21 `1.1732/1.1223/1.0667/1.0199/0.9943/0.9880`，16KB/64KB 慢。
- A018 768-only `MAndRXs_a512` specialization：768 r41 `1.0063/1.0048/1.0007/0.9987/0.9983/1.0063`，1KB/16KB 未严格加速。
- A019 768-only absorb specialization：768 r41 `0.9980/1.0000/0.9993/0.9980/0.9994/0.9977`，未严格加速。

2026-06-14 用户更新保留规则：目标 digest 平均 speedup 增加即可保留，单点退化仍记录。按该规则继续优化并保留：

- A022 768 short squeeze XMM-tail：r41 vs previous-retained 的 768 speedup `1.4331/1.4548/1.2398/1.0673/0.9907/1.0014`，平均 `1.1979`，保留。
- 1024 clean short squeeze continuation：最终 retained-vs-original 的 1024 speedup `1.3232/1.2544/1.1534/1.0867/1.0244/1.0517`，平均 `1.1490`，保留。该实现只保留 AVX-512 short squeeze 路径，不保留尝试目录中误带的 fallback skip-final 代码。

额外拒绝候选：

- A027 768 byte-tail absorb：r41 平均低于 A022，拒绝。
- A032 1024 short squeeze XMM-tail：r21 1024 `1.2979/1.2272/1.1402/1.0389/0.9962/0.9998`，长消息退化，拒绝。
- A035 1024 core unroll：r21 1024 平均 `0.9761`，拒绝。
- A036/A037/A039/A040/A041/A044/A045：语义均通过，但收益处于噪声区或存在固定长度退化，拒绝。
- A038/A042/A043：对应 digest 明显变慢，拒绝。
- A046 512 direct squeeze：语义通过；r21 512=`1.0029/0.9952/1.0058/1.0034/1.0013/1.0032`，平均只有 `1.0020` 且 64B 回退，拒绝。
- A047 1024 gated fixed absorb：语义通过；r21 1024=`0.8715/0.8548/0.8416/0.8353/0.8312/0.8352`，明显变慢，拒绝。

最终 retained-vs-original r21 结果：

| digest | speedup | 平均 |
| --- | --- | --- |
| 512 | `1.4128/1.4192/1.1669/1.0588/1.0101/1.0040` | `1.1786` |
| 768 | `1.4534/1.4658/1.2682/1.1074/1.0267/1.0294` | `1.2251` |
| 1024 | `1.3232/1.2544/1.1534/1.0867/1.0244/1.0517` | `1.1490` |
