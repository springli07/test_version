# MasterCube x86-64 Word Test Package

This package contains standalone x86-64 implementations and test scripts for
the Word self-evaluation report.

## Directories

- `64/Reference_Implementation`
- `64/Performance_Optimized_Implementation`
- `64/Resource_Optimized_Implementation`
- `64/AVX512_Implementation`
- `tools`

## Recommended One-Command Markdown Report

Use this command to build, run, and write one Markdown report containing the
Word-required correctness, performance, static memory, peak memory, data-size,
and round-count data:

```bash
RUN_AVX512=1 SECONDS_PER_POINT=3 PIN_CPU=0 ./tools/run_formal_markdown_report.sh
```

Generated report:

```text
metrics/formal_report.md
```

The script follows the same separation as the formal workflow internally:
correctness, performance timing, static size, and peak RSS are run as separate
steps. Temporary CSV files are written only under `build/formal_report/tmp` and
deleted by default. Set `KEEP_INTERMEDIATE=1` only if you need to inspect the
temporary CSV evidence.

For a quick smoke check:

```bash
SECONDS_PER_POINT=0.10 MEMORY_SECONDS=0.10 PIN_CPU=0 ./tools/run_formal_markdown_report.sh
```

## Important Rule

Formal performance and memory/resource tests should be run separately.

Use the pure performance benchmark for timing data:

```bash
RUN_AVX512=1 SECONDS_PER_POINT=3 PIN_CPU=0 ./tools/run_x86_64_word_versions.sh
```

Use separate scripts for correctness and resource metrics:

```bash
RUN_AVX512=1 ./tools/run_correctness_tests.sh
./tools/run_size_report.sh
RUN_AVX512=1 SECONDS_PER_POINT=0.10 ./tools/run_memory_report.sh
```

`run_all_metrics.sh` is a convenience smoke/summary script. Do not use it as
the formal source for performance timing, because it also runs memory/resource
measurement steps.

See `RUN_WORD_TESTS.md` for detailed commands, output files, and metric
definitions.
