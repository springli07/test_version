#ifndef MACROS_H
#define MACROS_H

#define UNUSED(x) (void)(x)

#define _MM_SHUFFLE_R(w, x, y, z) _MM_SHUFFLE(z, y, x, w)

#endif
