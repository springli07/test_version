# MasterCube x86-64 Performance-Optimized Implementation

This directory contains the x86-64 implementation used for the Word report's
`Performance-optimized` implementation type.

Compile command:

```sh
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto \
  -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra
```

With this command, `mastercube.h` selects the AVX2 entry points.
Only the x86-64 AVX2 code path is kept in this delivery directory.

For the Word report build and benchmark steps, see `../../RUN_WORD_TESTS.md`.
