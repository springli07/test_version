#ifndef MASTERCUBE_H
#define MASTERCUBE_H

#ifdef __cplusplus
extern "C"
{
#endif

#ifndef MasterCube512
#define MasterCube512 MasterCube512_avx2
#endif
#ifndef MasterCube768
#define MasterCube768 MasterCube768_avx2
#endif
#ifndef MasterCube1024
#define MasterCube1024 MasterCube1024_avx2
#endif

int MasterCube512(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
int MasterCube768(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
int MasterCube1024(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);

int MasterCube512_avx2(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
int MasterCube768_avx2(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
int MasterCube1024_avx2(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);

#ifdef __cplusplus
}
#endif

#endif
