#include <stdint.h>

/*
 * pad10*1 on a zero-initialized last_block.
 *
 * last_block: zeroed buffer that may be larger than the real block
 * msg_bits:   number of valid message bits already stored in last_block
 * block_bits: real logical block size in bits, always a multiple of 8
 *
 * Bit order inside each byte: MSB-first.
 */
static inline void pad10star1(uint8_t last_block[136], const int message_bits, const int block_bits)
{
    /* append the first '1' bit immediately after the message */
    last_block[message_bits / 8] |= (uint8_t)(0x80u >> (message_bits % 8));

    /* set the last bit of the real block to 1 */
    last_block[(block_bits / 8) - 1] |= 0x01u;

    return;
}