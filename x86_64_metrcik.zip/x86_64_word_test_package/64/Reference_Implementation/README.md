# MasterCube x86-64 Reference Implementation

This directory contains the x86-64 reference implementation used for the Word
report's `Reference` implementation type.

Compile command:

```sh
gcc -std=c99 -Wpedantic -Wall -Wextra -O2
```

The source is scalar C and does not use SSE, AVX2, or AVX-512 entry points.
The scalar core keeps semantics identical to the original reference
implementation while applying x86-64 scalar cleanups such as 64-bit row
operations and direct squeeze paths.

For the Word report build and benchmark steps, see `../../RUN_WORD_TESTS.md`.
