#ifndef MASTERCUBE_H
#define MASTERCUBE_H

#ifdef __cplusplus
extern "C"
{
#endif

#define MasterCube512 MasterCube512_plain
#define MasterCube768 MasterCube768_plain
#define MasterCube1024 MasterCube1024_plain

int MasterCube512(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
int MasterCube768(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
int MasterCube1024(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);

int MasterCube512_plain(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
int MasterCube768_plain(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);
int MasterCube1024_plain(const unsigned char *message, unsigned long long message_bit_len, unsigned char *digest);

#ifdef __cplusplus
}
#endif

#endif
