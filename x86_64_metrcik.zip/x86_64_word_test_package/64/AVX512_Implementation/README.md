# MasterCube x86-64 AVX512 Implementation

This directory contains the x86-64 AVX-512 implementation extracted from
`x86/64/Optimized_Implementation` for standalone Word-package testing.

Compile command:

```sh
gcc -O3 -march=x86-64 -mavx512f -mavx512bw -mavx512vl -mtune=native -flto \
  -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra
```

With this command, `mastercube.h` selects the AVX512 entry points. Only the
x86-64 AVX512 code path is kept in this delivery directory.

For the Word report build and benchmark steps, see `../../RUN_WORD_TESTS.md`.
