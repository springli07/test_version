# MasterCube x86-64 Word Test Guide

This guide describes how to build and run the three x86-64 implementation
types used by the Word self-evaluation report:

- `Reference_Implementation`
- `Performance_Optimized_Implementation`
- `Resource_Optimized_Implementation`
- `AVX512_Implementation`

All commands below are run from this package root directory.

```bash
cd /path/to/x86_64_word_test_package
```

On this workspace through WSL:

```bash
cd /mnt/d/AIcode/mastercubeopt/software/x86_64_word_test_package
```

## Requirements

- x86-64 Linux or WSL environment.
- GCC with AVX2 support for the optimized versions.
- Python 3 for summary CSV generation.
- CPU support for AVX2 when running Performance-optimized or
  Resource-optimized binaries.
- CPU support for AVX-512F, AVX-512BW, and AVX-512VL when running the AVX512
  binary.

Check AVX2 support:

```bash
grep -m1 -o 'avx2' /proc/cpuinfo
```

If the command prints `avx2`, the CPU supports the required AVX2 path.

Check AVX512 support:

```bash
grep -m1 -E -o 'avx512f|avx512bw|avx512vl' /proc/cpuinfo
```

The AVX512 benchmark requires all three feature names to be present.

## Word Compile Commands

The Word report uses the following compile commands.

### Reference

```bash
gcc -std=c99 -Wpedantic -Wall -Wextra -O2 \
  -c 64/Reference_Implementation/MasterCube-512.c \
  -o build/ref512.o
```

To compile all three Reference objects:

```bash
mkdir -p build/word_compile_check

gcc -std=c99 -Wpedantic -Wall -Wextra -O2 \
  -c 64/Reference_Implementation/MasterCube-512.c \
  -o build/word_compile_check/ref512.o
gcc -std=c99 -Wpedantic -Wall -Wextra -O2 \
  -c 64/Reference_Implementation/MasterCube-768.c \
  -o build/word_compile_check/ref768.o
gcc -std=c99 -Wpedantic -Wall -Wextra -O2 \
  -c 64/Reference_Implementation/MasterCube-1024.c \
  -o build/word_compile_check/ref1024.o
```

### Performance-Optimized

```bash
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto \
  -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra \
  -c 64/Performance_Optimized_Implementation/MasterCube-512.c \
  -o build/perf512.o
```

To compile all three Performance-optimized objects:

```bash
mkdir -p build/word_compile_check

gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto \
  -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra \
  -c 64/Performance_Optimized_Implementation/MasterCube-512.c \
  -o build/word_compile_check/perf512.o
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto \
  -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra \
  -c 64/Performance_Optimized_Implementation/MasterCube-768.c \
  -o build/word_compile_check/perf768.o
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto \
  -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra \
  -c 64/Performance_Optimized_Implementation/MasterCube-1024.c \
  -o build/word_compile_check/perf1024.o
```

### Resource-Optimized

```bash
gcc -Os -march=x86-64 -mavx2 -flto \
  -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra \
  -c 64/Resource_Optimized_Implementation/MasterCube-512.c \
  -o build/res512.o
```

To compile all three Resource-optimized objects:

```bash
mkdir -p build/word_compile_check

gcc -Os -march=x86-64 -mavx2 -flto \
  -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra \
  -c 64/Resource_Optimized_Implementation/MasterCube-512.c \
  -o build/word_compile_check/res512.o
gcc -Os -march=x86-64 -mavx2 -flto \
  -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra \
  -c 64/Resource_Optimized_Implementation/MasterCube-768.c \
  -o build/word_compile_check/res768.o
gcc -Os -march=x86-64 -mavx2 -flto \
  -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra \
  -c 64/Resource_Optimized_Implementation/MasterCube-1024.c \
  -o build/word_compile_check/res1024.o
```

### AVX512

The AVX512 version uses the Performance-optimized compile command style, with
the AVX2 flag replaced by AVX512 feature flags:

```bash
gcc -O3 -march=x86-64 -mavx512f -mavx512bw -mavx512vl -mtune=native -flto \
  -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra \
  -c 64/AVX512_Implementation/MasterCube-512.c \
  -o build/avx512_512.o
```

To compile all three AVX512 objects:

```bash
mkdir -p build/word_compile_check

gcc -O3 -march=x86-64 -mavx512f -mavx512bw -mavx512vl -mtune=native -flto \
  -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra \
  -c 64/AVX512_Implementation/MasterCube-512.c \
  -o build/word_compile_check/avx512_512.o
gcc -O3 -march=x86-64 -mavx512f -mavx512bw -mavx512vl -mtune=native -flto \
  -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra \
  -c 64/AVX512_Implementation/MasterCube-768.c \
  -o build/word_compile_check/avx512_768.o
gcc -O3 -march=x86-64 -mavx512f -mavx512bw -mavx512vl -mtune=native -flto \
  -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra \
  -c 64/AVX512_Implementation/MasterCube-1024.c \
  -o build/word_compile_check/avx512_1024.o
```

## Recommended Markdown Report

For normal use, run one command and generate a single Markdown report:

```bash
RUN_AVX512=1 SECONDS_PER_POINT=3 PIN_CPU=0 ./tools/run_formal_markdown_report.sh
```

Output:

```text
metrics/formal_report.md
```

This report contains:

- functional correctness;
- cycles/byte performance data for the Word message lengths;
- cycles per block / MiB/s performance data;
- static memory from `size` as `text + data + bss`;
- peak RSS memory sampled from `/proc/<pid>/status`;
- digest output sizes and round count.

The script uses temporary CSV files only under `build/formal_report/tmp` while
running and deletes them by default. Use `KEEP_INTERMEDIATE=1` if you need to
keep those temporary files for audit.

For a quick smoke run:

```bash
SECONDS_PER_POINT=0.10 MEMORY_SECONDS=0.10 PIN_CPU=0 ./tools/run_formal_markdown_report.sh
```

## One-Command Word Benchmark

Use the prepared script to build all three report versions and benchmark the
Word input lengths. The script also builds the AVX512 version. It runs AVX512
automatically only when the CPU reports `avx512f`, `avx512bw`, and `avx512vl`:

```bash
SECONDS_PER_POINT=3 PIN_CPU=0 ./tools/run_x86_64_word_versions.sh
```

The script benchmarks these message lengths:

```text
32B, 128B, 512B, 1024B, 4096B, 8192B, 16384B, 65536B
```

The script creates a timestamped output directory under:

```text
data/x86_64_word_versions_YYYYMMDD_HHMMSS/
```

Important output files:

- `raw/x86_64_reference.csv`
- `raw/x86_64_performance_optimized.csv`
- `raw/x86_64_resource_optimized.csv`
- `raw/x86_64_avx512.csv`
- `summary/combined_raw.csv`
- `summary/word_cpb_wide.csv`
- `summary/word_cpb_throughput_wide.csv`

`summary/word_cpb_wide.csv` is the table to use for Word cycles/byte data.

`summary/word_cpb_throughput_wide.csv` contains:

```text
cycles per block / MiB/s
```

## Faster Smoke Test

For a quick local check, reduce the seconds per benchmark point:

```bash
SECONDS_PER_POINT=0.2 PIN_CPU=0 \
OUT_DIR=data/x86_64_word_versions_smoke \
BUILD_DIR=build/x86_64_word_versions_smoke \
./tools/run_x86_64_word_versions.sh
```

Use the 3-second command for report data. The smoke test is only for checking
that the build and benchmark pipeline runs correctly.

## Optional Environment Variables

- `CC=gcc`: C compiler.
- `SECONDS_PER_POINT=3`: benchmark seconds per digest/length point.
- `PIN_CPU=0`: pin benchmark execution to one CPU with `taskset -c`.
- `OUT_DIR=...`: output directory for raw and summary CSV files.
- `BUILD_DIR=...`: build directory for benchmark binaries.
- `RUN_AVX512=auto`: run AVX512 only when CPU support is detected.
- `RUN_AVX512=1`: force running AVX512. Use only on a CPU that supports
  AVX-512F, AVX-512BW, and AVX-512VL.

## Formal Test Workflow

Run performance and memory/resource tests separately for formal report data.
Do not use the peak-memory script while collecting performance timing data,
because memory sampling reads `/proc/<pid>/status` while the benchmark process
is running and can perturb timing.

### 1. Formal Performance Test

Use this command for Word performance data:

```bash
RUN_AVX512=1 SECONDS_PER_POINT=3 PIN_CPU=0 ./tools/run_x86_64_word_versions.sh
```

If AVX512 should be auto-detected instead of forced:

```bash
SECONDS_PER_POINT=3 PIN_CPU=0 ./tools/run_x86_64_word_versions.sh
```

Use these output files for the Word tables:

```text
data/x86_64_word_versions_*/summary/word_cpb_wide.csv
data/x86_64_word_versions_*/summary/word_cpb_throughput_wide.csv
```

### 2. Correctness And Resource Tests

Run correctness, static memory, and peak memory separately:

```bash
RUN_AVX512=1 ./tools/run_correctness_tests.sh
./tools/run_size_report.sh
RUN_AVX512=1 SECONDS_PER_POINT=0.10 ./tools/run_memory_report.sh
```

Use these output files:

```text
metrics/correctness/correctness_summary.csv
metrics/size/static_size.csv
metrics/memory/peak_memory.csv
```

`SECONDS_PER_POINT=0.10` is enough for peak RSS measurement because the memory
metric is not a timing benchmark. Increase it only if the process exits too
quickly to sample on a target platform.

## Convenience Full Metric Report

Run correctness, performance, static memory, peak memory, data-size, and round
count reporting in one command:

```bash
SECONDS_PER_POINT=3 PIN_CPU=0 ./tools/run_all_metrics.sh
```

This script is useful for smoke testing and producing a combined Markdown
report, but it is not the recommended source for formal performance numbers.
For formal submission, use the separated workflow above.

For a short smoke run of the full pipeline:

```bash
SECONDS_PER_POINT=0.10 PIN_CPU=0 ./tools/run_all_metrics.sh
```

Generated report:

```text
metrics/summary_metrics.md
```

Metric definitions used by the scripts:

- Static memory: `text + data + bss` from the `size` command.
- Peak memory: process-level peak RSS sampled from `/proc/<pid>/status` `VmRSS`
  while the benchmark process is running. This includes benchmark program
  runtime overhead.

## Expected Output

During a normal run, the script prints build and benchmark progress:

```text
[build] x86_64_reference
[build] x86_64_performance_optimized
[build] x86_64_resource_optimized
[build] x86_64_avx512
[bench] x86_64_reference seconds=3
[bench] x86_64_performance_optimized seconds=3
[bench] x86_64_resource_optimized seconds=3
combined raw: ...
cycles/byte summary: ...
cycles per block / MiB/s summary: ...
Done: ...
```

After the run, open:

```text
summary/word_cpb_wide.csv
```

and copy the rows into the Word report table for x86-64.

## Notes

- The Reference implementation is scalar C and does not require AVX2.
- The Performance-optimized and Resource-optimized directories are x86-64 AVX2
  delivery directories.
- The AVX512 directory requires AVX-512F, AVX-512BW, and AVX-512VL at compile
  and run time.
- The Reference compile command may emit `-Wpedantic` warnings for anonymous
  structs/unions. These are inherited from the original C layout and do not
  prevent compilation.
