#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "mastercube.h"

static uint64_t xorshift64(uint64_t *state)
{
    uint64_t x = *state;
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    *state = x;
    return x;
}

static void fill_message(unsigned char *message, size_t bytes)
{
    uint64_t seed = 0x13198a2e03707344ULL ^ (uint64_t)bytes;
    for (size_t i = 0; i < bytes; ++i)
        message[i] = (unsigned char)(xorshift64(&seed) >> 56);
}

static void print_hex(const unsigned char *buf, size_t bytes)
{
    for (size_t i = 0; i < bytes; ++i)
        printf("%02x", buf[i]);
}

static void run_one(const char *label, int digest_bits,
                    int (*fn)(const unsigned char *, unsigned long long, unsigned char *),
                    unsigned long long msg_bits)
{
    enum { max_msg_bytes = 8192, max_digest_bytes = 128 };
    unsigned char message[max_msg_bytes];
    unsigned char digest[max_digest_bytes];
    const size_t msg_bytes = (size_t)((msg_bits + 7ULL) / 8ULL);
    const size_t digest_bytes = (size_t)digest_bits / 8u;

    if (msg_bytes > max_msg_bytes) {
        fprintf(stderr, "message too large: %llu bits\n", msg_bits);
        exit(2);
    }

    fill_message(message, msg_bytes);
    memset(digest, 0, sizeof(digest));
    if (fn(message, msg_bits, digest) != 0) {
        fprintf(stderr, "hash failed digest=%d bits=%llu\n", digest_bits, msg_bits);
        exit(3);
    }

    printf("%s,%d,%llu,", label, digest_bits, msg_bits);
    print_hex(digest, digest_bytes);
    putchar('\n');
}

int main(int argc, char **argv)
{
    const char *label = argc >= 2 ? argv[1] : "implementation";
    static const unsigned long long cases[] = {
        0ULL, 1ULL, 7ULL, 8ULL, 31ULL, 32ULL, 63ULL, 64ULL,
        255ULL, 256ULL, 511ULL, 512ULL, 1024ULL, 4096ULL,
        8192ULL, 32768ULL, 65536ULL
    };

    puts("label,digest_bits,msg_bits,digest_hex");
    for (size_t i = 0; i < sizeof(cases) / sizeof(cases[0]); ++i) {
        run_one(label, 512, MasterCube512, cases[i]);
        run_one(label, 768, MasterCube768, cases[i]);
        run_one(label, 1024, MasterCube1024, cases[i]);
    }

    return 0;
}
