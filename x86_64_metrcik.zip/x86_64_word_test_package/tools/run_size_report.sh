#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
OUT_DIR="${OUT_DIR:-$PKG_ROOT/metrics/size}"
BUILD_DIR="${BUILD_DIR:-$PKG_ROOT/build/size}"
CC="${CC:-gcc}"

mkdir -p "$OUT_DIR" "$BUILD_DIR"

build_exe() {
    local label="$1"
    local src_dir="$2"
    local exe="$3"
    shift 3
    "$CC" "$SCRIPT_DIR/metric_digest_dump.c" "$src_dir"/MasterCube-*.c \
        -I"$src_dir" "$@" -o "$exe"
}

build_exe reference "$PKG_ROOT/64/Reference_Implementation" "$BUILD_DIR/reference" \
    -std=c99 -Wpedantic -Wall -Wextra -O2
build_exe performance_optimized "$PKG_ROOT/64/Performance_Optimized_Implementation" "$BUILD_DIR/performance_optimized" \
    -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra
build_exe resource_optimized "$PKG_ROOT/64/Resource_Optimized_Implementation" "$BUILD_DIR/resource_optimized" \
    -Os -march=x86-64 -mavx2 -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra
build_exe avx512 "$PKG_ROOT/64/AVX512_Implementation" "$BUILD_DIR/avx512" \
    -O3 -march=x86-64 -mavx512f -mavx512bw -mavx512vl -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra

{
    echo "implementation,text,data,bss,dec,hex,file_bytes"
    for label in reference performance_optimized resource_optimized avx512; do
        read -r text data bss dec hex name < <(size -B "$BUILD_DIR/$label" | awk 'NR==2 {print $1, $2, $3, $4, $5, $6}')
        file_bytes=$(stat -c '%s' "$BUILD_DIR/$label")
        echo "$label,$text,$data,$bss,$dec,$hex,$file_bytes"
    done
} > "$OUT_DIR/static_size.csv"

cat "$OUT_DIR/static_size.csv"
