#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
OUT_DIR="${OUT_DIR:-$PKG_ROOT/metrics/memory}"
BUILD_DIR="${BUILD_DIR:-$PKG_ROOT/build/memory}"
SECONDS_PER_POINT="${SECONDS_PER_POINT:-0.05}"
RUN_AVX512="${RUN_AVX512:-auto}"
CC="${CC:-gcc}"

mkdir -p "$OUT_DIR/raw" "$BUILD_DIR"

BENCH_SRC="$SCRIPT_DIR/openssl_style_3s_cpb_bench.c"
STUB_INCLUDE="$SCRIPT_DIR/openssl_stub"

build_bench() {
    local label="$1"
    local src_dir="$2"
    local exe="$3"
    shift 3
    "$CC" "$@" -D_GNU_SOURCE -D__USE_MINGW_ANSI_STDIO=1 -DMCUBE_WORD_LENGTHS \
        -I"$STUB_INCLUDE" -I"$src_dir" "$BENCH_SRC" "$src_dir"/MasterCube-*.c -o "$exe"
}

build_bench reference "$PKG_ROOT/64/Reference_Implementation" "$BUILD_DIR/reference" \
    -std=c99 -Wpedantic -Wall -Wextra -O2
build_bench performance_optimized "$PKG_ROOT/64/Performance_Optimized_Implementation" "$BUILD_DIR/performance_optimized" \
    -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra
build_bench resource_optimized "$PKG_ROOT/64/Resource_Optimized_Implementation" "$BUILD_DIR/resource_optimized" \
    -Os -march=x86-64 -mavx2 -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra
build_bench avx512 "$PKG_ROOT/64/AVX512_Implementation" "$BUILD_DIR/avx512" \
    -O3 -march=x86-64 -mavx512f -mavx512bw -mavx512vl -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra

avx512_supported=0
if [[ -r /proc/cpuinfo ]] \
    && grep -m1 -qw avx512f /proc/cpuinfo \
    && grep -m1 -qw avx512bw /proc/cpuinfo \
    && grep -m1 -qw avx512vl /proc/cpuinfo; then
    avx512_supported=1
fi

run_one() {
    local label="$1"
    local exe="$2"
    local status="PASS"
    local peak_kb=0
    local current_kb=0

    "$exe" "$label" "$SECONDS_PER_POINT" > "$OUT_DIR/raw/${label}.csv" 2> "$OUT_DIR/raw/${label}.stderr" &
    local pid=$!

    while kill -0 "$pid" 2>/dev/null; do
        if [[ -r "/proc/$pid/status" ]]; then
            current_kb=$(awk '/^VmRSS:/ {print $2}' "/proc/$pid/status" 2>/dev/null || true)
            current_kb="${current_kb:-0}"
            if (( current_kb > peak_kb )); then
                peak_kb="$current_kb"
            fi
        fi
        sleep 0.001
    done

    if ! wait "$pid"; then
        status="FAIL"
    fi

    echo "$label,$status,$peak_kb,$((peak_kb * 1024))"
}

{
    echo "implementation,status,max_rss_kb,max_rss_bytes"
    run_one reference "$BUILD_DIR/reference"
    run_one performance_optimized "$BUILD_DIR/performance_optimized"
    run_one resource_optimized "$BUILD_DIR/resource_optimized"
    if [[ "$RUN_AVX512" == "1" || "$RUN_AVX512" == "yes" || "$RUN_AVX512" == "true" ]] \
        || [[ "$RUN_AVX512" == "auto" && "$avx512_supported" == "1" ]]; then
        run_one avx512 "$BUILD_DIR/avx512"
    else
        echo "avx512,SKIPPED,0,0"
    fi
} > "$OUT_DIR/peak_memory.csv"

cat "$OUT_DIR/peak_memory.csv"
