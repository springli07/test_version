#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

CC="${CC:-gcc}"
SECONDS_PER_POINT="${SECONDS_PER_POINT:-3}"
MEMORY_SECONDS="${MEMORY_SECONDS:-0.10}"
PIN_CPU="${PIN_CPU:-0}"
RUN_AVX512="${RUN_AVX512:-auto}"
OUT_MD="${OUT_MD:-$PKG_ROOT/metrics/formal_report.md}"
BUILD_DIR="${BUILD_DIR:-$PKG_ROOT/build/formal_report}"
KEEP_INTERMEDIATE="${KEEP_INTERMEDIATE:-0}"

TMP_DIR="$BUILD_DIR/tmp"
BIN_DIR="$BUILD_DIR/bin"
mkdir -p "$TMP_DIR" "$BIN_DIR" "$(dirname "$OUT_MD")"

BENCH_SRC="$SCRIPT_DIR/openssl_style_3s_cpb_bench.c"
DUMP_SRC="$SCRIPT_DIR/metric_digest_dump.c"
STUB_INCLUDE="$SCRIPT_DIR/openssl_stub"

avx512_supported=0
if [[ -r /proc/cpuinfo ]] \
    && grep -m1 -qw avx512f /proc/cpuinfo \
    && grep -m1 -qw avx512bw /proc/cpuinfo \
    && grep -m1 -qw avx512vl /proc/cpuinfo; then
    avx512_supported=1
fi

run_avx512=0
if [[ "$RUN_AVX512" == "1" || "$RUN_AVX512" == "yes" || "$RUN_AVX512" == "true" ]]; then
    run_avx512=1
elif [[ "$RUN_AVX512" == "auto" && "$avx512_supported" == "1" ]]; then
    run_avx512=1
fi

run_prefix=()
if [[ -n "$PIN_CPU" ]] && command -v taskset >/dev/null 2>&1; then
    run_prefix=(taskset -c "$PIN_CPU")
fi

build_bench() {
    local label="$1"
    local src_dir="$2"
    local exe="$3"
    shift 3
    echo "[build bench] $label"
    "$CC" "$@" -D_GNU_SOURCE -D__USE_MINGW_ANSI_STDIO=1 -DMCUBE_WORD_LENGTHS \
        -I"$STUB_INCLUDE" -I"$src_dir" "$BENCH_SRC" "$src_dir"/MasterCube-*.c -o "$exe"
}

build_dump() {
    local label="$1"
    local src_dir="$2"
    local exe="$3"
    shift 3
    echo "[build correctness] $label"
    "$CC" "$DUMP_SRC" "$src_dir"/MasterCube-*.c -I"$src_dir" "$@" -o "$exe"
}

build_all() {
    build_bench reference "$PKG_ROOT/64/Reference_Implementation" "$BIN_DIR/bench_reference" \
        -std=c99 -Wpedantic -Wall -Wextra -O2
    build_bench performance_optimized "$PKG_ROOT/64/Performance_Optimized_Implementation" "$BIN_DIR/bench_performance_optimized" \
        -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra
    build_bench resource_optimized "$PKG_ROOT/64/Resource_Optimized_Implementation" "$BIN_DIR/bench_resource_optimized" \
        -Os -march=x86-64 -mavx2 -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra
    build_bench avx512 "$PKG_ROOT/64/AVX512_Implementation" "$BIN_DIR/bench_avx512" \
        -O3 -march=x86-64 -mavx512f -mavx512bw -mavx512vl -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra

    build_dump reference "$PKG_ROOT/64/Reference_Implementation" "$BIN_DIR/dump_reference" \
        -std=c99 -Wpedantic -Wall -Wextra -O2
    build_dump performance_optimized "$PKG_ROOT/64/Performance_Optimized_Implementation" "$BIN_DIR/dump_performance_optimized" \
        -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra
    build_dump resource_optimized "$PKG_ROOT/64/Resource_Optimized_Implementation" "$BIN_DIR/dump_resource_optimized" \
        -Os -march=x86-64 -mavx2 -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra
    build_dump avx512 "$PKG_ROOT/64/AVX512_Implementation" "$BIN_DIR/dump_avx512" \
        -O3 -march=x86-64 -mavx512f -mavx512bw -mavx512vl -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra
}

run_performance() {
    echo "[performance] seconds_per_point=$SECONDS_PER_POINT"
    "${run_prefix[@]}" "$BIN_DIR/bench_reference" x86_64_reference "$SECONDS_PER_POINT" > "$TMP_DIR/perf_reference.csv"
    "${run_prefix[@]}" "$BIN_DIR/bench_performance_optimized" x86_64_performance_optimized "$SECONDS_PER_POINT" > "$TMP_DIR/perf_performance_optimized.csv"
    "${run_prefix[@]}" "$BIN_DIR/bench_resource_optimized" x86_64_resource_optimized "$SECONDS_PER_POINT" > "$TMP_DIR/perf_resource_optimized.csv"
    if [[ "$run_avx512" == "1" ]]; then
        "${run_prefix[@]}" "$BIN_DIR/bench_avx512" x86_64_avx512 "$SECONDS_PER_POINT" > "$TMP_DIR/perf_avx512.csv"
    else
        echo "[skip] AVX512 runtime requires avx512f,avx512bw,avx512vl"
    fi
}

run_correctness() {
    echo "[correctness]"
    "$BIN_DIR/dump_reference" reference > "$TMP_DIR/correct_reference.csv"
    "$BIN_DIR/dump_performance_optimized" performance_optimized > "$TMP_DIR/correct_performance_optimized.csv"
    "$BIN_DIR/dump_resource_optimized" resource_optimized > "$TMP_DIR/correct_resource_optimized.csv"
    if [[ "$run_avx512" == "1" ]]; then
        "$BIN_DIR/dump_avx512" avx512 > "$TMP_DIR/correct_avx512.csv"
    fi
}

write_size() {
    echo "[static size]"
    {
        echo "implementation,text,data,bss,dec,hex,file_bytes"
        for label in reference performance_optimized resource_optimized avx512; do
            read -r text data bss dec hex name < <(size -B "$BIN_DIR/bench_$label" | awk 'NR==2 {print $1, $2, $3, $4, $5, $6}')
            file_bytes=$(stat -c '%s' "$BIN_DIR/bench_$label")
            echo "$label,$text,$data,$bss,$dec,$hex,$file_bytes"
        done
    } > "$TMP_DIR/static_size.csv"
}

sample_memory_one() {
    local label="$1"
    local exe="$2"
    local status="PASS"
    local peak_kb=0
    local current_kb=0

    "$exe" "$label" "$MEMORY_SECONDS" > "$TMP_DIR/mem_${label}.csv" 2> "$TMP_DIR/mem_${label}.stderr" &
    local pid=$!

    while kill -0 "$pid" 2>/dev/null; do
        if [[ -r "/proc/$pid/status" ]]; then
            current_kb=$(awk '/^VmRSS:/ {print $2}' "/proc/$pid/status" 2>/dev/null || true)
            current_kb="${current_kb:-0}"
            if (( current_kb > peak_kb )); then
                peak_kb="$current_kb"
            fi
        fi
        sleep 0.001
    done

    if ! wait "$pid"; then
        status="FAIL"
    fi
    echo "$label,$status,$peak_kb,$((peak_kb * 1024))"
}

write_memory() {
    echo "[peak RSS] memory_seconds=$MEMORY_SECONDS"
    {
        echo "implementation,status,max_rss_kb,max_rss_bytes"
        sample_memory_one reference "$BIN_DIR/bench_reference"
        sample_memory_one performance_optimized "$BIN_DIR/bench_performance_optimized"
        sample_memory_one resource_optimized "$BIN_DIR/bench_resource_optimized"
        if [[ "$run_avx512" == "1" ]]; then
            sample_memory_one avx512 "$BIN_DIR/bench_avx512"
        else
            echo "avx512,SKIPPED,0,0"
        fi
    } > "$TMP_DIR/peak_memory.csv"
}

build_all
run_correctness
run_performance
write_size
write_memory

python3 - "$TMP_DIR" "$OUT_MD" "$SECONDS_PER_POINT" "$MEMORY_SECONDS" "$run_avx512" <<'PY'
import csv
import math
import sys
from pathlib import Path

tmp = Path(sys.argv[1])
out_md = Path(sys.argv[2])
seconds_per_point = sys.argv[3]
memory_seconds = sys.argv[4]
run_avx512 = sys.argv[5] == "1"

display = {
    "reference": "Reference",
    "performance_optimized": "Performance-optimized",
    "resource_optimized": "Resource-optimized",
    "avx512": "AVX512",
    "x86_64_reference": "Reference",
    "x86_64_performance_optimized": "Performance-optimized",
    "x86_64_resource_optimized": "Resource-optimized",
    "x86_64_avx512": "AVX512",
}
lengths = [32, 128, 512, 1024, 4096, 8192, 16384, 65536]

def read_csv(path):
    if not path.exists():
        return []
    with path.open(newline="") as f:
        return list(csv.DictReader(f))

ref_rows = read_csv(tmp / "correct_reference.csv")
ref = {(r["digest_bits"], r["msg_bits"]): r["digest_hex"] for r in ref_rows}
correctness = []
for key in ["performance_optimized", "resource_optimized", "avx512"]:
    path = tmp / f"correct_{key}.csv"
    if not path.exists():
        correctness.append((display[key], "SKIPPED", 0, 0))
        continue
    rows = read_csv(path)
    mismatches = 0
    for r in rows:
        if ref.get((r["digest_bits"], r["msg_bits"])) != r["digest_hex"]:
            mismatches += 1
    correctness.append((display[key], "PASS" if mismatches == 0 else "FAIL", len(rows), mismatches))

perf_rows = []
for path in sorted(tmp.glob("perf_*.csv")):
    perf_rows.extend(read_csv(path))

def perf_table(metric):
    rows = []
    labels = ["x86_64_reference", "x86_64_performance_optimized", "x86_64_resource_optimized", "x86_64_avx512"]
    for label in labels:
        if not any(r["label"] == label for r in perf_rows):
            continue
        for digest in [512, 768, 1024]:
            rec = ["X86-64", f"MasterCube-{digest}", display[label]]
            for n in lengths:
                match = [
                    r for r in perf_rows
                    if r["label"] == label and int(r["digest_bits"]) == digest and int(r["msg_bytes"]) == n
                ]
                if not match:
                    rec.append("")
                    continue
                r = match[0]
                cpb = float(r["cycles_per_byte"])
                if metric == "cpb":
                    rec.append(f"{cpb:.6f}")
                else:
                    ops = float(r["ops_per_second"])
                    throughput_mib_s = ops * n / (1024.0 * 1024.0)
                    cycles_per_block = cpb * n
                    rec.append(f"{cycles_per_block:.2f}/{throughput_mib_s:.2f}")
            rows.append(rec)
    return rows

size_rows = read_csv(tmp / "static_size.csv")
mem_rows = read_csv(tmp / "peak_memory.csv")

lines = []
lines.append("# MasterCube x86-64 Formal Metric Report")
lines.append("")
lines.append(f"- Performance timing seconds per point: `{seconds_per_point}`")
lines.append(f"- Peak RSS memory sampling run seconds: `{memory_seconds}`")
lines.append("- Static memory: `text + data + bss` from `size`.")
lines.append("- Peak memory: sampled from `/proc/<pid>/status` `VmRSS`; process-level RSS including benchmark overhead.")
lines.append("")

lines.append("## Functional Correctness")
lines.append("")
lines.append("| Implementation | Status | Cases | Mismatches |")
lines.append("| --- | --- | ---: | ---: |")
for impl, status, cases, mismatches in correctness:
    lines.append(f"| {impl} | {status} | {cases} | {mismatches} |")
lines.append("")

lines.append("## Performance: Cycles Per Byte")
lines.append("")
headers = ["architecture", "algorithm", "implementation_type"] + [f"{n}B" for n in lengths]
lines.append("| " + " | ".join(headers) + " |")
lines.append("| " + " | ".join(["---"] * len(headers)) + " |")
for row in perf_table("cpb"):
    lines.append("| " + " | ".join(row) + " |")
lines.append("")

lines.append("## Performance: Cycles Per Block / MiB/s")
lines.append("")
lines.append("| " + " | ".join(headers) + " |")
lines.append("| " + " | ".join(["---"] * len(headers)) + " |")
for row in perf_table("throughput"):
    lines.append("| " + " | ".join(row) + " |")
lines.append("")

lines.append("## Static Memory Footprint")
lines.append("")
lines.append("| Implementation | text | data | bss | static bytes | file bytes |")
lines.append("| --- | ---: | ---: | ---: | ---: | ---: |")
for r in size_rows:
    lines.append(f"| {display.get(r['implementation'], r['implementation'])} | {r['text']} | {r['data']} | {r['bss']} | {r['dec']} | {r['file_bytes']} |")
lines.append("")

lines.append("## Peak Memory Footprint")
lines.append("")
lines.append("| Implementation | Status | Max RSS KB | Max RSS Bytes |")
lines.append("| --- | --- | ---: | ---: |")
for r in mem_rows:
    lines.append(f"| {display.get(r['implementation'], r['implementation'])} | {r['status']} | {r['max_rss_kb']} | {r['max_rss_bytes']} |")
lines.append("")

lines.append("## Data Size And Rounds")
lines.append("")
lines.append("| Algorithm | Digest size bytes | Core rounds | Interaction rounds |")
lines.append("| --- | ---: | ---: | --- |")
lines.append("| MasterCube-512 | 64 | 18 | N/A for hash |")
lines.append("| MasterCube-768 | 96 | 18 | N/A for hash |")
lines.append("| MasterCube-1024 | 128 | 18 | N/A for hash |")
lines.append("")

if not run_avx512:
    lines.append("AVX512 runtime data is skipped because this CPU does not report `avx512f`, `avx512bw`, and `avx512vl`, or `RUN_AVX512` was not enabled.")
    lines.append("")

out_md.write_text("\n".join(lines), encoding="utf-8")
print(out_md)
PY

if [[ "$KEEP_INTERMEDIATE" != "1" ]]; then
    rm -rf "$TMP_DIR"
fi

echo "Markdown report: $OUT_MD"
