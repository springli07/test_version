#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
BUILD_DIR="${BUILD_DIR:-$PKG_ROOT/build/avx512_compile_check}"

mkdir -p "$BUILD_DIR"

CFLAGS='-O3 -march=x86-64 -mavx512f -mavx512bw -mavx512vl -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra'

gcc $CFLAGS -c "$PKG_ROOT/64/AVX512_Implementation/MasterCube-512.c" \
  -o "$BUILD_DIR/avx512_512.o"
gcc $CFLAGS -c "$PKG_ROOT/64/AVX512_Implementation/MasterCube-768.c" \
  -o "$BUILD_DIR/avx512_768.o"
gcc $CFLAGS -c "$PKG_ROOT/64/AVX512_Implementation/MasterCube-1024.c" \
  -o "$BUILD_DIR/avx512_1024.o"

ls -l "$BUILD_DIR"/*.o
