#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
OUT_DIR="${OUT_DIR:-$PKG_ROOT/metrics/correctness}"
BUILD_DIR="${BUILD_DIR:-$PKG_ROOT/build/correctness}"
RUN_AVX512="${RUN_AVX512:-auto}"
CC="${CC:-gcc}"

mkdir -p "$OUT_DIR/raw" "$BUILD_DIR"

build_dump() {
    local label="$1"
    local src_dir="$2"
    local exe="$3"
    shift 3
    "$CC" "$SCRIPT_DIR/metric_digest_dump.c" "$src_dir"/MasterCube-*.c \
        -I"$src_dir" "$@" -o "$exe"
}

avx512_supported=0
if [[ -r /proc/cpuinfo ]] \
    && grep -m1 -qw avx512f /proc/cpuinfo \
    && grep -m1 -qw avx512bw /proc/cpuinfo \
    && grep -m1 -qw avx512vl /proc/cpuinfo; then
    avx512_supported=1
fi

build_dump reference "$PKG_ROOT/64/Reference_Implementation" "$BUILD_DIR/reference" \
    -std=c99 -Wpedantic -Wall -Wextra -O2
build_dump performance_optimized "$PKG_ROOT/64/Performance_Optimized_Implementation" "$BUILD_DIR/performance_optimized" \
    -O3 -march=x86-64 -mavx2 -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra
build_dump resource_optimized "$PKG_ROOT/64/Resource_Optimized_Implementation" "$BUILD_DIR/resource_optimized" \
    -Os -march=x86-64 -mavx2 -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra
build_dump avx512 "$PKG_ROOT/64/AVX512_Implementation" "$BUILD_DIR/avx512" \
    -O3 -march=x86-64 -mavx512f -mavx512bw -mavx512vl -mtune=native -flto -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra

"$BUILD_DIR/reference" reference > "$OUT_DIR/raw/reference.csv"
"$BUILD_DIR/performance_optimized" performance_optimized > "$OUT_DIR/raw/performance_optimized.csv"
"$BUILD_DIR/resource_optimized" resource_optimized > "$OUT_DIR/raw/resource_optimized.csv"

if [[ "$RUN_AVX512" == "1" || "$RUN_AVX512" == "yes" || "$RUN_AVX512" == "true" ]] \
    || [[ "$RUN_AVX512" == "auto" && "$avx512_supported" == "1" ]]; then
    "$BUILD_DIR/avx512" avx512 > "$OUT_DIR/raw/avx512.csv"
else
    echo "avx512,SKIPPED,CPU lacks avx512f avx512bw avx512vl" > "$OUT_DIR/avx512_skipped.txt"
fi

python3 - "$OUT_DIR" <<'PY'
import csv
import sys
from pathlib import Path

out = Path(sys.argv[1])
raw = out / "raw"
ref_rows = list(csv.DictReader((raw / "reference.csv").open()))
ref = {(r["digest_bits"], r["msg_bits"]): r["digest_hex"] for r in ref_rows}
summary = []

for path in sorted(raw.glob("*.csv")):
    if path.name == "reference.csv":
        continue
    rows = list(csv.DictReader(path.open()))
    mismatches = []
    for r in rows:
        key = (r["digest_bits"], r["msg_bits"])
        if ref.get(key) != r["digest_hex"]:
            mismatches.append(key)
    summary.append({
        "implementation": path.stem,
        "cases": str(len(rows)),
        "status": "PASS" if not mismatches else "FAIL",
        "mismatches": str(len(mismatches)),
    })

if (out / "avx512_skipped.txt").exists():
    summary.append({
        "implementation": "avx512",
        "cases": "0",
        "status": "SKIPPED",
        "mismatches": "0",
    })

with (out / "correctness_summary.csv").open("w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=["implementation", "cases", "status", "mismatches"])
    writer.writeheader()
    writer.writerows(summary)

for row in summary:
    print(f"{row['implementation']},{row['status']},cases={row['cases']},mismatches={row['mismatches']}")
PY
