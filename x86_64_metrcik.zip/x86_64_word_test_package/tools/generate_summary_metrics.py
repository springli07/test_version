#!/usr/bin/env python3
import csv
import sys
from pathlib import Path

root = Path(sys.argv[1])
metrics = root / "metrics"
out = metrics / "summary_metrics.md"

def read_csv(path):
    if not path.exists():
        return []
    with path.open(newline="") as f:
        return list(csv.DictReader(f))

correctness = read_csv(metrics / "correctness" / "correctness_summary.csv")
size_rows = read_csv(metrics / "size" / "static_size.csv")
memory_rows = read_csv(metrics / "memory" / "peak_memory.csv")
cpb_rows = read_csv(metrics / "performance" / "summary" / "word_cpb_wide.csv")
throughput_rows = read_csv(metrics / "performance" / "summary" / "word_cpb_throughput_wide.csv")

impl_names = {
    "reference": "Reference",
    "performance_optimized": "Performance-optimized",
    "resource_optimized": "Resource-optimized",
    "avx512": "AVX512",
}

lines = []
lines.append("# MasterCube x86-64 Metric Summary")
lines.append("")
lines.append("## Functional Correctness")
lines.append("")
lines.append("| Implementation | Status | Cases | Mismatches |")
lines.append("| --- | --- | ---: | ---: |")
for row in correctness:
    lines.append(f"| {impl_names.get(row['implementation'], row['implementation'])} | {row['status']} | {row['cases']} | {row['mismatches']} |")

lines.append("")
lines.append("## Performance: Cycles Per Byte")
lines.append("")
if cpb_rows:
    fields = cpb_rows[0].keys()
    header = list(fields)
    lines.append("| " + " | ".join(header) + " |")
    lines.append("| " + " | ".join(["---"] * len(header)) + " |")
    for row in cpb_rows:
        lines.append("| " + " | ".join(row[h] for h in header) + " |")

lines.append("")
lines.append("## Performance: Cycles Per Block / MiB/s")
lines.append("")
if throughput_rows:
    fields = list(throughput_rows[0].keys())
    lines.append("| " + " | ".join(fields) + " |")
    lines.append("| " + " | ".join(["---"] * len(fields)) + " |")
    for row in throughput_rows:
        lines.append("| " + " | ".join(row[h] for h in fields) + " |")

lines.append("")
lines.append("## Static Memory Footprint")
lines.append("")
lines.append("Static memory is calculated as `text + data + bss` from `size` output.")
lines.append("")
lines.append("| Implementation | text | data | bss | static bytes | file bytes |")
lines.append("| --- | ---: | ---: | ---: | ---: | ---: |")
for row in size_rows:
    lines.append(f"| {impl_names.get(row['implementation'], row['implementation'])} | {row['text']} | {row['data']} | {row['bss']} | {row['dec']} | {row['file_bytes']} |")

lines.append("")
lines.append("## Peak Memory Footprint")
lines.append("")
lines.append("Peak memory is sampled from `/proc/<pid>/status` `VmRSS` while the benchmark process is running. It is a process-level peak RSS and includes benchmark program overhead.")
lines.append("")
lines.append("| Implementation | Status | Max RSS KB | Max RSS Bytes |")
lines.append("| --- | --- | ---: | ---: |")
for row in memory_rows:
    lines.append(f"| {impl_names.get(row['implementation'], row['implementation'])} | {row['status']} | {row['max_rss_kb']} | {row['max_rss_bytes']} |")

lines.append("")
lines.append("## Data Size And Rounds")
lines.append("")
lines.append("| Algorithm | Digest size bytes | Core rounds | Interaction rounds |")
lines.append("| --- | ---: | ---: | --- |")
lines.append("| MasterCube-512 | 64 | 18 | N/A for hash |")
lines.append("| MasterCube-768 | 96 | 18 | N/A for hash |")
lines.append("| MasterCube-1024 | 128 | 18 | N/A for hash |")

lines.append("")
lines.append("Notes:")
lines.append("- Performance benchmark uses the Word message lengths: 32B, 128B, 512B, 1024B, 4096B, 8192B, 16384B, 65536B.")
lines.append("- AVX512 runtime metrics are SKIPPED when the CPU lacks avx512f, avx512bw, and avx512vl.")
lines.append("- Reference may emit -Wpedantic warnings for anonymous structs/unions; this does not prevent compilation.")

out.write_text("\n".join(lines) + "\n")
print(out)
