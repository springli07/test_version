#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
METRICS_DIR="${METRICS_DIR:-$PKG_ROOT/metrics}"
SECONDS_PER_POINT="${SECONDS_PER_POINT:-0.10}"
PIN_CPU="${PIN_CPU:-0}"
RUN_AVX512="${RUN_AVX512:-auto}"

mkdir -p "$METRICS_DIR"

echo "[1/4] correctness"
OUT_DIR="$METRICS_DIR/correctness" RUN_AVX512="$RUN_AVX512" \
    "$SCRIPT_DIR/run_correctness_tests.sh"

echo "[2/4] performance"
OUT_DIR="$METRICS_DIR/performance" BUILD_DIR="$PKG_ROOT/build/performance_metrics" \
    SECONDS_PER_POINT="$SECONDS_PER_POINT" PIN_CPU="$PIN_CPU" RUN_AVX512="$RUN_AVX512" \
    "$SCRIPT_DIR/run_x86_64_word_versions.sh"

echo "[3/4] static size"
OUT_DIR="$METRICS_DIR/size" "$SCRIPT_DIR/run_size_report.sh"

echo "[4/4] peak memory"
OUT_DIR="$METRICS_DIR/memory" BUILD_DIR="$PKG_ROOT/build/memory_metrics" \
    SECONDS_PER_POINT="$SECONDS_PER_POINT" RUN_AVX512="$RUN_AVX512" \
    "$SCRIPT_DIR/run_memory_report.sh"

python3 "$SCRIPT_DIR/generate_summary_metrics.py" "$PKG_ROOT"
