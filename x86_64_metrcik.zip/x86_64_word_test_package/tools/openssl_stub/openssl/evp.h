#ifndef ROUND4_OPENSSL_EVP_STUB_H
#define ROUND4_OPENSSL_EVP_STUB_H

/* MasterCube plain sources include <openssl/evp.h> but do not use EVP APIs. */

#endif
