# MasterCube x86 V4 vs V4.1 benchmark package

Run the full local comparison with one command from this directory:

```sh
sh run_all.sh
```

The command also works from another working directory if you give the path to
`run_all.sh`. No absolute source or build paths are stored in the package.
On Windows, run it in WSL Ubuntu. Required tools are Bash, GCC, Python 3,
`sha256sum`, and an x86-64 Linux environment. `taskset` is optional.

## Contents

```text
MasterCube_x86_V4_vs_V4.1_benchmark/
|-- run_all.sh
|-- README.md
|-- sources.sha256
|-- tools/
|   |-- compare_versions.sh
|   |-- run_x86_64_word_versions.sh
|   |-- openssl_style_3s_cpb_bench.c
|   |-- summarize.py
|   `-- openssl_stub/openssl/evp.h
|-- versions/
|   |-- old/Implementations/
|   |   |-- Reference_Implementation/MasterCube-{512,768,1024}/
|   |   |-- Optimized_Implementation/MasterCube-{512,768,1024}/
|   |   `-- Additional_Implementation/MasterCube-{512,768,1024}/X86/
|   |       |-- Resource_Optimized_Implementation/
|   |       `-- AVX512_Implementation/
|   `-- new/Implementations/        (same x86 layout)
|-- examples/local_20260923/      (previous local run; not refreshed)
`-- results/                     (created by run_all.sh)
```

Each of the 24 implementation directories contains its original algorithm,
API, KAT, and DRNG source files. `old` comes from `MasterCube` source V4;
`new` comes from `MasterCube-889c5b6799fd1ff6c45f2aee925df7cb54d08374.zip`
(SHA-256 `C03EEBD57C40719E104FCEF3BDB0A4BE3D5B54F41D44DB46599645F89BB5A378`).
The files under `versions/` are unchanged; `sources.sha256` records every
source file and is checked before benchmarking. Hardware implementations and
test vectors are outside the scope of this performance-only package.

## Measurement

The script uses the same C benchmark and compiler flags for both versions.
It measures 512/768/1024-bit digests at 32, 128, 512, 1024, 4096, 8192,
16384, and 65536 message bytes. The order is old, new, new, old, giving two
measurements per version for every available point. Each point runs for one
second by default. When `taskset` is available, the script pins all runs to
the first CPU allowed for the process.

```sh
SECONDS_PER_POINT=3 sh run_all.sh
PIN_CPU=8 SECONDS_PER_POINT=3 sh run_all.sh
```

The script runs the reference implementation on x86-64, AVX2 variants when
the CPU supports AVX2, and AVX512 when the CPU supports its required features.
Unsupported variants remain blank in the output tables. Set `RUN_AVX512=0`
to skip AVX512 even on a supporting CPU.

## Results

The terminal prints five complete tables: old cycles/byte, new cycles/byte,
new-versus-old percentage, old throughput (MiB/s), and new throughput.
Positive percentage means V4.1 takes more cycles/byte and is slower.

Every run creates a new `results/run_<UTC timestamp>/` directory containing:

```text
old_1/, new_1/, new_2/, old_2/   raw CSV and per-run summary CSV
summary/REPORT.md                readable result tables and environment
summary/detailed_comparison.csv  all paired measurements and means
summary/old_cycles_per_byte.csv
summary/new_cycles_per_byte.csv
summary/difference_percent.csv
summary/old_throughput_mib_s.csv
summary/new_throughput_mib_s.csv
build/                           local binaries
```

Cycles/byte can vary with CPU frequency, temperature, and other load. The
four-run order helps expose drift; inspect the individual measurements before
interpreting a small percentage difference. This tool measures speed and
does not run KAT correctness checks.

With GCC 11.4, both versions' AVX2 resource-optimized sources emit a
`-Wstringop-overflow` warning around `pad10star1` during compilation. The
sources are preserved unchanged; a completed speed run does not resolve that
warning or establish memory safety.

`examples/local_20260923/summary/REPORT.md` contains the previous local
measurement and all five generated tables. It is a dated example. Running
`sh run_all.sh` always makes a fresh result directory.
