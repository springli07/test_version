# MasterCube x86 V4 vs V4.1 performance

- Host: Intel(R) Core(TM) i9-14900HX (x86_64)
- Compiler: gcc (Ubuntu 11.4.0-1ubuntu1~22.04.3) 11.4.0
- CPU affinity: 8
- Seconds per point: 1
- Run order: old, new, new, old; each available point has two measurements per version.
- Positive percentages mean V4.1 used more cycles per byte.
- `run_all.sh` verifies packaged source files against `sources.sha256` before each new run.
- Blank cells mean the CPU lacks the required instructions or execution was disabled.

## Geometric mean change across eight lengths and three digest sizes

| Implementation | V4.1 vs V4 |
| --- | ---: |
| Reference | -0.36% |
| AVX2 performance | +1.02% |
| AVX2 resource | +1.14% |
| AVX512 |  |

## Old cycles/byte

| implementation | algorithm | 32B | 128B | 512B | 1024B | 4096B | 8192B | 16384B | 65536B |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Reference | MasterCube-512 | 685.822395 | 244.580622 | 123.111996 | 105.866274 | 96.894257 | 96.016770 | 92.125603 | 89.083527 |
| Reference | MasterCube-768 | 961.622322 | 319.801899 | 165.817322 | 148.503284 | 132.582828 | 128.518834 | 120.157461 | 115.096669 |
| Reference | MasterCube-1024 | 1308.320972 | 500.165310 | 284.271784 | 241.430588 | 207.493080 | 195.376779 | 188.573554 | 190.670870 |
| AVX2 performance | MasterCube-512 | 27.851768 | 12.810305 | 7.655850 | 6.718553 | 6.513310 | 6.077146 | 6.277797 | 6.412601 |
| AVX2 performance | MasterCube-768 | 55.658164 | 19.461455 | 10.689940 | 9.604526 | 8.539006 | 8.502244 | 8.825972 | 8.903507 |
| AVX2 performance | MasterCube-1024 | 81.340683 | 31.753952 | 17.501268 | 14.952482 | 13.817538 | 13.991521 | 14.041319 | 13.730048 |
| AVX2 resource | MasterCube-512 | 32.296694 | 13.895050 | 8.323172 | 7.421088 | 7.371378 | 7.635305 | 7.460627 | 7.365067 |
| AVX2 resource | MasterCube-768 | 62.451949 | 20.426034 | 11.445496 | 10.901207 | 10.352289 | 10.284166 | 10.066375 | 9.929989 |
| AVX2 resource | MasterCube-1024 | 85.765712 | 34.450512 | 20.330768 | 18.092945 | 16.529650 | 15.781679 | 15.283818 | 15.018815 |
| AVX512 | MasterCube-512 |  |  |  |  |  |  |  |  |
| AVX512 | MasterCube-768 |  |  |  |  |  |  |  |  |
| AVX512 | MasterCube-1024 |  |  |  |  |  |  |  |  |

## New cycles/byte

| implementation | algorithm | 32B | 128B | 512B | 1024B | 4096B | 8192B | 16384B | 65536B |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Reference | MasterCube-512 | 672.251403 | 237.910650 | 126.796172 | 102.780274 | 92.656177 | 88.181639 | 87.408365 | 87.042187 |
| Reference | MasterCube-768 | 1021.629057 | 345.390193 | 167.800162 | 144.302682 | 128.120441 | 133.981737 | 126.379238 | 124.487107 |
| Reference | MasterCube-1024 | 1281.447564 | 507.454341 | 266.343619 | 235.735953 | 200.918574 | 193.437696 | 200.057667 | 188.396006 |
| AVX2 performance | MasterCube-512 | 29.850737 | 12.872657 | 7.593035 | 6.788063 | 6.531054 | 6.428652 | 6.117132 | 6.565460 |
| AVX2 performance | MasterCube-768 | 58.633137 | 19.348220 | 10.613200 | 9.706990 | 9.014898 | 8.883826 | 8.713861 | 8.382820 |
| AVX2 performance | MasterCube-1024 | 79.244922 | 31.502859 | 18.270701 | 16.160950 | 13.689478 | 13.905307 | 13.857200 | 13.432717 |
| AVX2 resource | MasterCube-512 | 31.944934 | 14.384795 | 8.894222 | 7.768498 | 7.301750 | 7.119599 | 7.429070 | 7.550444 |
| AVX2 resource | MasterCube-768 | 62.717404 | 22.879496 | 12.729423 | 11.432830 | 10.035957 | 9.813258 | 9.896845 | 9.868016 |
| AVX2 resource | MasterCube-1024 | 87.047387 | 36.034574 | 20.486845 | 17.584236 | 15.730059 | 15.483564 | 15.643751 | 15.501776 |
| AVX512 | MasterCube-512 |  |  |  |  |  |  |  |  |
| AVX512 | MasterCube-768 |  |  |  |  |  |  |  |  |
| AVX512 | MasterCube-1024 |  |  |  |  |  |  |  |  |

## New vs old cycles/byte (%)

| implementation | algorithm | 32B | 128B | 512B | 1024B | 4096B | 8192B | 16384B | 65536B |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Reference | MasterCube-512 | -1.98 | -2.73 | +2.99 | -2.91 | -4.37 | -8.16 | -5.12 | -2.29 |
| Reference | MasterCube-768 | +6.24 | +8.00 | +1.20 | -2.83 | -3.37 | +4.25 | +5.18 | +8.16 |
| Reference | MasterCube-1024 | -2.05 | +1.46 | -6.31 | -2.36 | -3.17 | -0.99 | +6.09 | -1.19 |
| AVX2 performance | MasterCube-512 | +7.18 | +0.49 | -0.82 | +1.03 | +0.27 | +5.78 | -2.56 | +2.38 |
| AVX2 performance | MasterCube-768 | +5.35 | -0.58 | -0.72 | +1.07 | +5.57 | +4.49 | -1.27 | -5.85 |
| AVX2 performance | MasterCube-1024 | -2.58 | -0.79 | +4.40 | +8.08 | -0.93 | -0.62 | -1.31 | -2.17 |
| AVX2 resource | MasterCube-512 | -1.09 | +3.52 | +6.86 | +4.68 | -0.94 | -6.75 | -0.42 | +2.52 |
| AVX2 resource | MasterCube-768 | +0.43 | +12.01 | +11.22 | +4.88 | -3.06 | -4.58 | -1.68 | -0.62 |
| AVX2 resource | MasterCube-1024 | +1.49 | +4.60 | +0.77 | -2.81 | -4.84 | -1.89 | +2.35 | +3.22 |
| AVX512 | MasterCube-512 |  |  |  |  |  |  |  |  |
| AVX512 | MasterCube-768 |  |  |  |  |  |  |  |  |
| AVX512 | MasterCube-1024 |  |  |  |  |  |  |  |  |

## Old throughput (MiB/s)

| implementation | algorithm | 32B | 128B | 512B | 1024B | 4096B | 8192B | 16384B | 65536B |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Reference | MasterCube-512 | 3.39 | 9.46 | 18.77 | 21.80 | 23.84 | 24.06 | 25.05 | 26.00 |
| Reference | MasterCube-768 | 2.40 | 7.22 | 13.93 | 15.54 | 17.42 | 17.98 | 19.25 | 20.05 |
| Reference | MasterCube-1024 | 1.76 | 4.61 | 8.12 | 9.58 | 11.15 | 11.83 | 12.24 | 12.10 |
| AVX2 performance | MasterCube-512 | 82.85 | 180.24 | 302.24 | 344.94 | 356.07 | 379.68 | 367.51 | 359.81 |
| AVX2 performance | MasterCube-768 | 41.50 | 118.64 | 216.33 | 241.01 | 270.53 | 271.43 | 261.49 | 259.68 |
| AVX2 performance | MasterCube-1024 | 28.41 | 72.93 | 131.93 | 154.32 | 166.97 | 164.92 | 164.51 | 168.06 |
| AVX2 resource | MasterCube-512 | 71.58 | 166.14 | 277.22 | 310.89 | 313.00 | 302.80 | 309.65 | 315.41 |
| AVX2 resource | MasterCube-768 | 37.34 | 112.98 | 201.61 | 211.67 | 222.87 | 224.43 | 229.36 | 232.71 |
| AVX2 resource | MasterCube-1024 | 26.92 | 67.00 | 113.53 | 127.59 | 139.83 | 146.39 | 151.37 | 153.74 |
| AVX512 | MasterCube-512 |  |  |  |  |  |  |  |  |
| AVX512 | MasterCube-768 |  |  |  |  |  |  |  |  |
| AVX512 | MasterCube-1024 |  |  |  |  |  |  |  |  |

## New throughput (MiB/s)

| implementation | algorithm | 32B | 128B | 512B | 1024B | 4096B | 8192B | 16384B | 65536B |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Reference | MasterCube-512 | 3.44 | 9.70 | 18.22 | 22.57 | 24.97 | 26.20 | 26.41 | 26.55 |
| Reference | MasterCube-768 | 2.26 | 6.69 | 13.78 | 16.02 | 18.03 | 17.23 | 18.28 | 18.54 |
| Reference | MasterCube-1024 | 1.81 | 4.56 | 8.70 | 9.83 | 11.48 | 11.93 | 11.58 | 12.30 |
| AVX2 performance | MasterCube-512 | 77.79 | 179.81 | 303.85 | 339.88 | 353.26 | 358.88 | 377.91 | 351.98 |
| AVX2 performance | MasterCube-768 | 39.39 | 119.35 | 217.48 | 237.81 | 256.18 | 259.87 | 265.53 | 275.60 |
| AVX2 performance | MasterCube-1024 | 29.11 | 73.24 | 126.28 | 142.86 | 168.68 | 166.17 | 166.56 | 171.75 |
| AVX2 resource | MasterCube-512 | 72.24 | 160.59 | 259.45 | 297.37 | 316.33 | 325.22 | 310.99 | 305.74 |
| AVX2 resource | MasterCube-768 | 36.87 | 101.04 | 183.36 | 202.94 | 230.44 | 235.10 | 233.50 | 233.89 |
| AVX2 resource | MasterCube-1024 | 26.51 | 64.16 | 112.84 | 131.60 | 146.72 | 149.03 | 147.58 | 148.92 |
| AVX512 | MasterCube-512 |  |  |  |  |  |  |  |  |
| AVX512 | MasterCube-768 |  |  |  |  |  |  |  |  |
| AVX512 | MasterCube-1024 |  |  |  |  |  |  |  |  |

Per-run raw and summary CSV files are in `old_1/`, `new_1/`,
`new_2/`, and `old_2/`. All paired measurements are in
`summary/detailed_comparison.csv`.
