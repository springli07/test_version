# Previous local measurement

`local_20260923/` is a copy of the earlier four-run measurement on an
Intel Core i9-14900HX under WSL2 Ubuntu, pinned to CPU 8 for one second per
point. It includes raw CSV data, a generated full report, and the separate
focused retest (`focus.csv`). It is an example, not the result of running this
package after extraction. Use `sh run_all.sh` for fresh measurements.
