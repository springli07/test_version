#!/bin/sh
set -eu

PACKAGE_DIR=$(CDPATH= cd "$(dirname "$0")" && pwd)
exec bash "$PACKAGE_DIR/tools/compare_versions.sh"
