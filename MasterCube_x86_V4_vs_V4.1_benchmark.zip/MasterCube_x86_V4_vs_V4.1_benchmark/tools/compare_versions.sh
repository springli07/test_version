#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
OLD_ROOT="$PKG_ROOT/versions/old/Implementations"
NEW_ROOT="$PKG_ROOT/versions/new/Implementations"
SECONDS_PER_POINT="${SECONDS_PER_POINT:-1}"
COMPARE_OUT_DIR="${COMPARE_OUT_DIR:-$PKG_ROOT/results/run_$(date -u +%Y%m%d_%H%M%S)}"

for command in bash gcc python3 sha256sum; do
    command -v "$command" >/dev/null 2>&1 || {
        echo "Missing required command: $command" >&2
        exit 2
    }
done

[[ "$(uname -m)" == x86_64 ]] || {
    echo "This benchmark requires an x86-64 Linux host" >&2
    exit 2
}

[[ -d "$OLD_ROOT" && -d "$NEW_ROOT" ]] || {
    echo "Both versions/old and versions/new must be present" >&2
    exit 2
}

(cd "$PKG_ROOT" && sha256sum --check --quiet sources.sha256)

PIN_CPU="${PIN_CPU:-}"
if [[ -z "$PIN_CPU" ]] && command -v taskset >/dev/null 2>&1; then
    allowed="$(taskset -pc "$$" | sed 's/.*: //')"
    PIN_CPU="${allowed%%[-,]*}"
fi
if [[ -n "$PIN_CPU" ]] && command -v taskset >/dev/null 2>&1; then
    taskset -c "$PIN_CPU" true || {
        echo "PIN_CPU=$PIN_CPU is not allowed" >&2
        exit 2
    }
fi

mkdir -p "$COMPARE_OUT_DIR"
printf 'CPU affinity: %s\n' "${PIN_CPU:-unfixed}"
printf 'Seconds per point: %s\n' "$SECONDS_PER_POINT"

for run in old_1 new_1 new_2 old_2; do
    version="${run%%_*}"
    if [[ "$version" == old ]]; then
        source_root="$OLD_ROOT"
    else
        source_root="$NEW_ROOT"
    fi
    echo "[compare] $run"
    MCUBE_SOURCE_ROOT="$source_root" \
    OUT_DIR="$COMPARE_OUT_DIR/$run" \
    BUILD_DIR="$COMPARE_OUT_DIR/build/$version" \
    REUSE_BINARIES=1 \
    PIN_CPU="$PIN_CPU" \
    SECONDS_PER_POINT="$SECONDS_PER_POINT" \
        bash "$SCRIPT_DIR/run_x86_64_word_versions.sh"
done

python3 "$SCRIPT_DIR/summarize.py" "$COMPARE_OUT_DIR" "$SECONDS_PER_POINT" "${PIN_CPU:-unfixed}"
