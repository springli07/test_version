#!/usr/bin/env python3
"""Summarize four interleaved MasterCube benchmark runs."""

import csv
import math
import platform
import statistics
import subprocess
import sys
from pathlib import Path


RUNS = ("old_1", "new_1", "new_2", "old_2")
IMPLEMENTATIONS = (
    ("x86_64_reference", "Reference"),
    ("x86_64_performance_optimized", "AVX2 performance"),
    ("x86_64_resource_optimized", "AVX2 resource"),
    ("x86_64_avx512", "AVX512"),
)
DIGESTS = (512, 768, 1024)
LENGTHS = (32, 128, 512, 1024, 4096, 8192, 16384, 65536)


def load_run(root, name, seconds):
    path = root / name / "summary" / "combined_raw.csv"
    with path.open(newline="", encoding="utf-8") as handle:
        data = list(csv.DictReader(handle))
    result = {}
    for row in data:
        key = (row["label"], int(row["digest_bits"]), int(row["msg_bytes"]))
        if key in result:
            raise ValueError(f"duplicate benchmark point: {name} {key}")
        if (float(row["cycles_per_byte"]) <= 0
                or float(row["ops_per_second"]) <= 0
                or float(row["elapsed_seconds"]) < seconds * 0.95):
            raise ValueError(f"invalid benchmark point: {name} {key}")
        result[key] = row
    return result


def write_csv(path, fields, rows):
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def wide_rows(metrics, field, fmt):
    rows = []
    for label, display in IMPLEMENTATIONS:
        for digest in DIGESTS:
            row = {"implementation": display, "algorithm": f"MasterCube-{digest}"}
            for length in LENGTHS:
                point = metrics.get((label, digest, length))
                row[f"{length}B"] = fmt(point[field]) if point else ""
            rows.append(row)
    return rows


def console_table(title, rows):
    fields = ("implementation", "algorithm") + tuple(f"{n}B" for n in LENGTHS)
    widths = [max(len(field), *(len(row[field]) for row in rows)) for field in fields]
    print(f"\n{title}")
    print("  ".join(field.ljust(width) for field, width in zip(fields, widths)))
    for row in rows:
        print("  ".join(row[field].ljust(width) for field, width in zip(fields, widths)))


def markdown_table(rows):
    fields = ("implementation", "algorithm") + tuple(f"{n}B" for n in LENGTHS)
    lines = ["| " + " | ".join(fields) + " |",
             "| " + " | ".join("---" for _ in fields) + " |"]
    lines.extend("| " + " | ".join(row[field] for field in fields) + " |" for row in rows)
    return "\n".join(lines)


def cpu_model():
    path = Path("/proc/cpuinfo")
    if path.exists():
        for line in path.read_text(errors="replace").splitlines():
            if line.startswith("model name"):
                return line.split(":", 1)[1].strip()
    return platform.processor() or "unknown"


def main():
    if len(sys.argv) != 4:
        raise SystemExit("usage: summarize.py <run-dir> <seconds-per-point> <pin-cpu>")
    root = Path(sys.argv[1]).resolve()
    seconds = float(sys.argv[2])
    pin_cpu = sys.argv[3]
    runs = {name: load_run(root, name, seconds) for name in RUNS}
    keys = set(runs["old_1"])
    if not keys or any(set(data) != keys for data in runs.values()):
        raise ValueError("the four runs do not have identical point sets")
    known_labels = {label for label, _ in IMPLEMENTATIONS}
    labels = {key[0] for key in keys}
    if "x86_64_reference" not in labels or not labels <= known_labels:
        raise ValueError("unexpected implementation set")
    for label in labels:
        expected = {(label, digest, length) for digest in DIGESTS for length in LENGTHS}
        if {key for key in keys if key[0] == label} != expected:
            raise ValueError(f"incomplete measurements for {label}")

    summary_dir = root / "summary"
    summary_dir.mkdir(exist_ok=True)
    detailed = []
    metrics = {}
    for label, digest, length in sorted(keys):
        key = (label, digest, length)
        cpb = {name: float(runs[name][key]["cycles_per_byte"]) for name in RUNS}
        mib = {name: float(runs[name][key]["ops_per_second"]) * length / 1048576
               for name in RUNS}
        old_cpb = statistics.mean((cpb["old_1"], cpb["old_2"]))
        new_cpb = statistics.mean((cpb["new_1"], cpb["new_2"]))
        point = {
            "old_cpb": old_cpb,
            "new_cpb": new_cpb,
            "change_pct": (new_cpb / old_cpb - 1) * 100,
            "old_mib": statistics.mean((mib["old_1"], mib["old_2"])),
            "new_mib": statistics.mean((mib["new_1"], mib["new_2"])),
        }
        metrics[key] = point
        detailed.append({
            "implementation": label, "digest_bits": digest, "msg_bytes": length,
            "old_1_cpb": f"{cpb['old_1']:.6f}",
            "new_1_cpb": f"{cpb['new_1']:.6f}",
            "new_2_cpb": f"{cpb['new_2']:.6f}",
            "old_2_cpb": f"{cpb['old_2']:.6f}",
            "old_mean_cpb": f"{old_cpb:.6f}",
            "new_mean_cpb": f"{new_cpb:.6f}",
            "new_vs_old_pct": f"{point['change_pct']:+.2f}",
            "old_mean_mib_s": f"{point['old_mib']:.2f}",
            "new_mean_mib_s": f"{point['new_mib']:.2f}",
        })

    write_csv(summary_dir / "detailed_comparison.csv", list(detailed[0]), detailed)
    tables = (
        ("Old cycles/byte", "old_cycles_per_byte.csv", "old_cpb", lambda n: f"{n:.6f}"),
        ("New cycles/byte", "new_cycles_per_byte.csv", "new_cpb", lambda n: f"{n:.6f}"),
        ("New vs old cycles/byte (%)", "difference_percent.csv", "change_pct", lambda n: f"{n:+.2f}"),
        ("Old throughput (MiB/s)", "old_throughput_mib_s.csv", "old_mib", lambda n: f"{n:.2f}"),
        ("New throughput (MiB/s)", "new_throughput_mib_s.csv", "new_mib", lambda n: f"{n:.2f}"),
    )
    fields = ["implementation", "algorithm"] + [f"{n}B" for n in LENGTHS]
    rendered = []
    for title, filename, field, fmt in tables:
        rows = wide_rows(metrics, field, fmt)
        write_csv(summary_dir / filename, fields, rows)
        console_table(title, rows)
        rendered.append(f"## {title}\n\n{markdown_table(rows)}")

    gcc = subprocess.check_output(["gcc", "--version"], text=True).splitlines()[0]
    geomeans = []
    for label, display in IMPLEMENTATIONS:
        ratios = [metrics[key]["new_cpb"] / metrics[key]["old_cpb"]
                  for key in sorted(keys) if key[0] == label]
        value = f"{(math.exp(statistics.mean(math.log(r) for r in ratios)) - 1) * 100:+.2f}%" if ratios else ""
        geomeans.append(f"| {display} | {value} |")
    report = [
        "# MasterCube x86 V4 vs V4.1 performance",
        "",
        f"- Host: {cpu_model()} ({platform.machine()})",
        f"- Compiler: {gcc}",
        f"- CPU affinity: {pin_cpu}",
        f"- Seconds per point: {seconds:g}",
        "- Run order: old, new, new, old; each available point has two measurements per version.",
        "- Positive percentages mean V4.1 used more cycles per byte.",
        "- `run_all.sh` verifies packaged source files against `sources.sha256` before each new run.",
        "- Blank cells mean the CPU lacks the required instructions or execution was disabled.",
        "",
        "## Geometric mean change across eight lengths and three digest sizes",
        "",
        "| Implementation | V4.1 vs V4 |",
        "| --- | ---: |",
        *geomeans,
    ]
    for table in rendered:
        report.extend(("", table))
    report.extend(("", "Per-run raw and summary CSV files are in `old_1/`, `new_1/`,",
                   "`new_2/`, and `old_2/`. All paired measurements are in",
                   "`summary/detailed_comparison.csv`.", ""))
    (summary_dir / "REPORT.md").write_text("\n".join(report), encoding="utf-8")
    print(f"\nCompared {len(keys)} points. Full report: {summary_dir / 'REPORT.md'}")


if __name__ == "__main__":
    main()
