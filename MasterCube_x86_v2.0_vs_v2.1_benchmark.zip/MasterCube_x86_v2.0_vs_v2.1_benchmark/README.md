# MasterCube x86 v2.0 vs v2.1 benchmark

Unpack on an x86-64 Linux machine (or WSL) and run from the package root:

```sh
sh run_all.sh
```

The script works from any current directory and uses paths relative to itself.
It requires Bash, GCC, Python 3, and `sha256sum`; `taskset` is optional.
No AVX512 binary is run unless the CPU reports `avx512f`, `avx512bw`, and
`avx512vl`. Thus the same ZIP works on both AVX2-only and AVX512 machines.
`RUN_AVX512=0 sh run_all.sh` forces AVX512 to be skipped.

## Sources

```text
MasterCube_x86_v2.0_vs_v2.1_benchmark/
|-- run_all.sh
|-- README.md
|-- sources.sha256
|-- tools/
|   |-- compare_versions.sh
|   |-- run_x86_64_word_versions.sh
|   |-- openssl_style_3s_cpb_bench.c
|   |-- summarize.py
|   `-- openssl_stub/openssl/evp.h
|-- versions/
|   |-- v2.0/Implementations/
|   |   |-- Reference_Implementation/MasterCube-{512,768,1024}/
|   |   |-- Optimized_Implementation/MasterCube-{512,768,1024}/
|   |   `-- Additional_Implementation/MasterCube-{512,768,1024}/X86/
|   |       |-- Resource_Optimized_Implementation/
|   |       `-- AVX512_Implementation/
|   `-- v2.1/Implementations/       (same layout)
`-- results/                       (created by a run)
```

The v2.0 sources are copied unchanged from `MasterCube源码V4.zip` (V4.0).
The v2.1 sources are copied unchanged from `MasterCube-code-only.zip`
(SHA-256 `8A61CDBEDED9CD1A7503BE131B9F485B3C8EEECAF54413303D3BCF941B842603`).
`sources.sha256` protects all 168 packaged source files and is checked
before every run. This package excludes ARM and ASIC because it runs on x86.

## Measurement and Output

The same C harness and compiler flags are used for both versions. Each
available implementation measures 512/768/1024 digest bits at 32, 128, 512,
1024, 4096, 8192, 16384, and 65536 message bytes. Run order is v2.0,
v2.1, v2.1, v2.0, with two measurements per version per point. A point
defaults to one second. To run longer:

```sh
SECONDS_PER_POINT=3 sh run_all.sh
```

If `taskset` is available, one allowed CPU is selected automatically.
Override it with `PIN_CPU=<allowed-number>` when needed.

The terminal prints five full tables: v2.0 cycles/byte, v2.1 cycles/byte,
v2.1 versus v2.0 percentage, v2.0 throughput (MiB/s), and v2.1 throughput.
A positive percentage means v2.1 is slower. Unsupported implementations
remain blank, never estimated. Each run saves raw CSVs and
`results/run_<UTC timestamp>/summary/REPORT.md`, plus all five CSV tables
and `detailed_comparison.csv`. Send back that run's `summary/` directory or
the complete `results/run_<UTC timestamp>/` directory for analysis.

Benchmarking does not run KAT correctness tests. Small differences can be
affected by CPU frequency, temperature, and system load; inspect the four
individual measurements before interpreting them.
