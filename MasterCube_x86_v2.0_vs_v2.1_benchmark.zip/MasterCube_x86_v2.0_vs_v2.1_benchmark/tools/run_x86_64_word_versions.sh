#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

CC="${CC:-gcc}"
SECONDS_PER_POINT="${SECONDS_PER_POINT:-3}"
OUT_DIR="${OUT_DIR:-$PKG_ROOT/results/v2.1_only_$(date -u +%Y%m%d_%H%M%S)}"
BUILD_DIR="${BUILD_DIR:-$PKG_ROOT/build/x86_64_word_versions}"
PIN_CPU="${PIN_CPU:-}"
RUN_AVX512="${RUN_AVX512:-auto}"
REUSE_BINARIES="${REUSE_BINARIES:-0}"

BENCH_SRC="$SCRIPT_DIR/openssl_style_3s_cpb_bench.c"
STUB_INCLUDE="$SCRIPT_DIR/openssl_stub"
SRC_ROOT="${MCUBE_SOURCE_ROOT:-$PKG_ROOT/versions/v2.1/Implementations}"

mkdir -p "$BUILD_DIR" "$OUT_DIR/raw" "$OUT_DIR/summary"

run_prefix=()
if [[ -n "$PIN_CPU" ]] && command -v taskset >/dev/null 2>&1; then
    run_prefix=(taskset -c "$PIN_CPU")
fi

build_bench() {
    local label="$1"
    local exe="$2"
    shift 2
    local flags=("$@")
    local sources=()
    local src_dir=""

    for bits in 512 768 1024; do
        case "$label" in
            x86_64_reference)
                src_dir="$SRC_ROOT/Reference_Implementation/MasterCube-$bits" ;;
            x86_64_performance_optimized)
                src_dir="$SRC_ROOT/Optimized_Implementation/MasterCube-$bits" ;;
            x86_64_resource_optimized)
                src_dir="$SRC_ROOT/Additional_Implementation/MasterCube-$bits/X86/Resource_Optimized_Implementation" ;;
            x86_64_avx512)
                src_dir="$SRC_ROOT/Additional_Implementation/MasterCube-$bits/X86/AVX512_Implementation" ;;
            *) echo "Unknown implementation: $label" >&2; exit 2 ;;
        esac
        [[ -f "$src_dir/MasterCube-$bits.c" && -f "$src_dir/mastercube.h" ]] || {
            echo "Missing source or header in $src_dir" >&2
            exit 2
        }
        sources+=("$src_dir/MasterCube-$bits.c")
        if [[ "$bits" == 512 ]]; then
            include_dir="$src_dir"
        fi
    done

    if [[ "$REUSE_BINARIES" == 1 && -f "$exe" ]]; then
        echo "[reuse] $label"
        return
    fi

    echo "[build] $label"
    "$CC" "${flags[@]}" \
        -D_GNU_SOURCE -D__USE_MINGW_ANSI_STDIO=1 -DMCUBE_WORD_LENGTHS \
        -I"$STUB_INCLUDE" -I"$include_dir" \
        "$BENCH_SRC" "${sources[@]}" -o "$exe"
}

run_bench() {
    local label="$1"
    local exe="$2"
    local raw="$OUT_DIR/raw/${label}.csv"

    echo "[bench] $label seconds=$SECONDS_PER_POINT"
    "${run_prefix[@]}" "$exe" "$label" "$SECONDS_PER_POINT" > "$raw"
}

avx2_supported=0
if [[ -r /proc/cpuinfo ]] && grep -m1 -qw avx2 /proc/cpuinfo; then
    avx2_supported=1
fi

avx512_supported=0
if [[ -r /proc/cpuinfo ]] \
    && grep -m1 -qw avx512f /proc/cpuinfo \
    && grep -m1 -qw avx512bw /proc/cpuinfo \
    && grep -m1 -qw avx512vl /proc/cpuinfo; then
    avx512_supported=1
fi

build_bench x86_64_reference "$BUILD_DIR/bench_x86_64_reference" \
    -std=c99 -Wpedantic -Wall -Wextra -O2

if [[ "$avx2_supported" == 1 ]]; then
    build_bench x86_64_performance_optimized "$BUILD_DIR/bench_x86_64_performance_optimized" \
        -O3 -march=x86-64 -mavx2 -mtune=native -flto \
        -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra

    build_bench x86_64_resource_optimized "$BUILD_DIR/bench_x86_64_resource_optimized" \
        -Os -march=x86-64 -mavx2 -flto \
        -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra
else
    echo "[skip] AVX2 implementations: CPU does not expose avx2"
fi

if [[ "$avx512_supported" == 1 && "$RUN_AVX512" != 0 ]]; then
    build_bench x86_64_avx512 "$BUILD_DIR/bench_x86_64_avx512" \
        -O3 -march=x86-64 -mavx512f -mavx512bw -mavx512vl -mtune=native -flto \
        -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra
fi

run_bench x86_64_reference "$BUILD_DIR/bench_x86_64_reference"
if [[ "$avx2_supported" == 1 ]]; then
    run_bench x86_64_performance_optimized "$BUILD_DIR/bench_x86_64_performance_optimized"
    run_bench x86_64_resource_optimized "$BUILD_DIR/bench_x86_64_resource_optimized"
fi

if [[ "$avx512_supported" == 1 && "$RUN_AVX512" != 0 ]]; then
    run_bench x86_64_avx512 "$BUILD_DIR/bench_x86_64_avx512"
else
    echo "[skip] AVX512 implementation: CPU lacks avx512f/avx512bw/avx512vl or RUN_AVX512=0"
fi

python3 - "$OUT_DIR" <<'PY'
import csv
import sys
from pathlib import Path

out_dir = Path(sys.argv[1])
raw_dir = out_dir / "raw"
summary_dir = out_dir / "summary"
summary_dir.mkdir(parents=True, exist_ok=True)

impl_map = {
    "x86_64_reference": "Reference",
    "x86_64_performance_optimized": "Performance-optimized",
    "x86_64_resource_optimized": "Resource-optimized",
    "x86_64_avx512": "AVX512",
}

rows = []
for path in sorted(raw_dir.glob("*.csv")):
    with path.open(newline="") as f:
        for row in csv.DictReader(f):
            row["source_file"] = path.name
            rows.append(row)

present_labels = [label for label in impl_map if any(r["label"] == label for r in rows)]

combined = summary_dir / "combined_raw.csv"
with combined.open("w", newline="") as f:
    if rows:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

lengths = [32, 128, 512, 1024, 4096, 8192, 16384, 65536]

cpb_wide = summary_dir / "word_cpb_wide.csv"
with cpb_wide.open("w", newline="") as f:
    fields = ["architecture", "algorithm", "implementation_type"] + [f"{n}B" for n in lengths]
    writer = csv.DictWriter(f, fieldnames=fields)
    writer.writeheader()
    for label in present_labels:
        for digest in (512, 768, 1024):
            rec = {
                "architecture": "X86-64",
                "algorithm": f"MasterCube-{digest}",
                "implementation_type": impl_map[label],
            }
            for n in lengths:
                match = [
                    r for r in rows
                    if r["label"] == label
                    and int(r["digest_bits"]) == digest
                    and int(r["msg_bytes"]) == n
                ]
                rec[f"{n}B"] = f"{float(match[0]['cycles_per_byte']):.6f}" if match else ""
            writer.writerow(rec)

perf_wide = summary_dir / "word_cpb_throughput_wide.csv"
with perf_wide.open("w", newline="") as f:
    fields = ["architecture", "algorithm", "implementation_type"] + [f"{n}B" for n in lengths]
    writer = csv.DictWriter(f, fieldnames=fields)
    writer.writeheader()
    for label in present_labels:
        for digest in (512, 768, 1024):
            rec = {
                "architecture": "X86-64",
                "algorithm": f"MasterCube-{digest}",
                "implementation_type": impl_map[label],
            }
            for n in lengths:
                match = [
                    r for r in rows
                    if r["label"] == label
                    and int(r["digest_bits"]) == digest
                    and int(r["msg_bytes"]) == n
                ]
                if match:
                    cycles_per_byte = float(match[0]["cycles_per_byte"])
                    ops_per_second = float(match[0]["ops_per_second"])
                    throughput_mib_s = ops_per_second * n / (1024.0 * 1024.0)
                    cycles_per_block = cycles_per_byte * n
                    rec[f"{n}B"] = f"{cycles_per_block:.2f}/{throughput_mib_s:.2f}"
                else:
                    rec[f"{n}B"] = ""
            writer.writerow(rec)

print(f"combined raw: {combined}")
print(f"cycles/byte summary: {cpb_wide}")
print(f"cycles per block / MiB/s summary: {perf_wide}")
PY

echo "Done: $OUT_DIR"
