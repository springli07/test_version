# MasterCube x86-64 v2.0 vs v2.1 benchmark

Run on a native x86-64 Linux host or WSL. The package is relocatable: the
script resolves all source and tool paths relative to itself.

```sh
sh run_all.sh
```

Requires Bash, GCC, Python 3, `sha256sum`, and `tar`. `taskset` is optional.
The default is one second per point. A complete run takes roughly 5-7 minutes
of measurement time, depending on AVX512 support, plus compilation and setup.

```sh
SECONDS_PER_POINT=0.05 sh run_all.sh  # compile/report smoke test only
SECONDS_PER_POINT=3 sh run_all.sh     # longer full measurement
PIN_CPU=8 sh run_all.sh              # optional allowed CPU affinity
RUN_AVX512=0 sh run_all.sh           # explicitly skip AVX512
```

AVX512 is run only if the CPU exposes `avx512f`, `avx512bw`, and `avx512vl`.
Unsupported rows stay blank. They are not emulated or estimated.

## Version identity

- v2.0: unchanged software files from the previous
  `MasterCube_x86_v2.0_vs_v2.1_benchmark` v2.0 snapshot, originally V4.0.
- v2.1: software files extracted from the user-supplied
  `MasterCube-code-onlyV2.1.zip`, SHA-256
  `F602BB33413CBD09131F8E38DD69E597265B9EEADD6971628AD635067825BCA2`.
- The uploaded archive's x86 and ARM software files are byte-identical to
  `MasterCube-code-only.zip` from 2026-09-25. The 18 changed archive files
  are ASIC Verilog files, which this software benchmark does not include.
- All 170 packaged source/build-description files are checked against
  `sources.sha256` before each run. No source file is edited by the benchmark.

## Method

The historical `openssl_style_3s_cpb_bench.c` harness and x86 compiler
options are retained for both versions. Reference uses `-O2`, AVX2
performance and AVX512 use `-O3`, and AVX2 resource uses `-Os` with the
original architecture/LTO options in `tools/run_x86_64_word_versions.sh`.
For each available implementation, all three digest sizes (512/768/1024
bits) and eight message lengths (32, 128, 512, 1024, 4096, 8192, 16384,
65536 **bytes**) are measured. The run order is `old_1`, `new_1`, `new_2`,
`old_2`; each point has two measurements per version. A deterministic input
is used. CPU cycles come from the historical x86 RDTSC/RDTSCP counter.

The same `tools/summarize.py` file is packaged for x86 and ARM. It computes
each run-level value from the raw counters, then averages the two values for
each version:

```text
cycles/byte = cycles / (iterations * message_bytes)
ns/byte     = elapsed_seconds * 1e9 / (iterations * message_bytes)
MiB/s       = iterations * message_bytes / elapsed_seconds / 1048576
change (%)  = 100 * (mean_v2.1 / mean_v2.0 - 1)
```

Positive cycle/time changes mean v2.1 is slower. Geometric means aggregate
24 new/old ratios per implementation. These are descriptive measurements,
not statistical equivalence tests. The benchmark does not run a full KAT.

## Outputs

Each run creates `results/run_<UTC>_<PID>/summary/REPORT.md` and prints the
same eight full tables to the terminal as the ARM package: old/new
cycles/byte, cycle difference, old/new ns/byte, time difference, and old/new
MiB/s. The summary directory contains the matching eight CSV files plus
`detailed_comparison.csv` with all four measurements per point. The four
run directories contain raw CSVs; `system.txt` records the host. A result
archive is written as `results/run_<UTC>_<PID>_results.tar.gz` and copied to
`results/latest_results.tar.gz` for transfer. Send back the archive or its
`summary/` directory.

```text
MasterCube_x86_v2.0_vs_v2.1_retest_20260927/
|-- README.md
|-- run_all.sh
|-- sources.sha256
|-- tools/
|   |-- compare_versions.sh
|   |-- run_x86_64_word_versions.sh
|   |-- openssl_style_3s_cpb_bench.c
|   |-- summarize.py
|   `-- openssl_stub/openssl/evp.h
|-- versions/
|   |-- v2.0/Implementations/
|   `-- v2.1/Implementations/
`-- results/  (created by a run)
```
