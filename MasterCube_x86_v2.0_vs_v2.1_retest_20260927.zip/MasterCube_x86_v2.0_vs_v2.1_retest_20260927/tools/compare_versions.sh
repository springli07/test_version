#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
OLD_ROOT="$PKG_ROOT/versions/v2.0/Implementations"
NEW_ROOT="$PKG_ROOT/versions/v2.1/Implementations"
CC="${CC:-gcc}"
SECONDS_PER_POINT="${SECONDS_PER_POINT:-1}"
RESULTS_DIR="${RESULTS_DIR:-$PKG_ROOT/results}"
COMPARE_OUT_DIR="${COMPARE_OUT_DIR:-$RESULTS_DIR/run_$(date -u +%Y%m%d_%H%M%S)_$$}"

for command in bash "$CC" python3 sha256sum tar cp; do
    command -v "$command" >/dev/null 2>&1 || {
        echo "Missing required command: $command" >&2
        exit 2
    }
done

[[ "$(uname -m)" == x86_64 ]] || {
    echo "This benchmark requires an x86-64 Linux host" >&2
    exit 2
}

[[ -d "$OLD_ROOT" && -d "$NEW_ROOT" ]] || {
    echo "Both versions/v2.0 and versions/v2.1 must be present" >&2
    exit 2
}

(cd "$PKG_ROOT" && sha256sum --check --quiet sources.sha256)

PIN_CPU="${PIN_CPU:-}"
if [[ -z "$PIN_CPU" ]] && command -v taskset >/dev/null 2>&1; then
    allowed="$(taskset -pc "$$" | sed 's/.*: //')"
    PIN_CPU="${allowed%%[-,]*}"
fi
if [[ -n "$PIN_CPU" ]] && command -v taskset >/dev/null 2>&1; then
    taskset -c "$PIN_CPU" true || {
        echo "PIN_CPU=$PIN_CPU is not allowed" >&2
        exit 2
    }
fi

mkdir -p "$RESULTS_DIR" "$COMPARE_OUT_DIR"
{
    date -u
    uname -a
    "$CC" --version | head -1
    python3 --version
    if command -v lscpu >/dev/null 2>&1; then lscpu; fi
    printf 'CPU affinity: %s\n' "${PIN_CPU:-unfixed}"
    printf 'Seconds per point: %s\n' "$SECONDS_PER_POINT"
} > "$COMPARE_OUT_DIR/system.txt"
printf 'CPU affinity: %s\n' "${PIN_CPU:-unfixed}"
printf 'Seconds per point: %s\n' "$SECONDS_PER_POINT"

for run in old_1 new_1 new_2 old_2; do
    version="${run%%_*}"
    if [[ "$version" == old ]]; then
        source_root="$OLD_ROOT"
    else
        source_root="$NEW_ROOT"
    fi
    echo "[compare] $run"
    MCUBE_SOURCE_ROOT="$source_root" \
    OUT_DIR="$COMPARE_OUT_DIR/$run" \
    BUILD_DIR="$COMPARE_OUT_DIR/build/$version" \
    REUSE_BINARIES=1 \
    PIN_CPU="$PIN_CPU" \
    SECONDS_PER_POINT="$SECONDS_PER_POINT" \
        bash "$SCRIPT_DIR/run_x86_64_word_versions.sh"
done

python3 "$SCRIPT_DIR/summarize.py" "$COMPARE_OUT_DIR" "$SECONDS_PER_POINT" "${PIN_CPU:-unfixed}"
printf 'SUCCESS\n' > "$COMPARE_OUT_DIR/RUN_STATUS.txt"
archive="$RESULTS_DIR/$(basename "$COMPARE_OUT_DIR")_results.tar.gz"
tar -czf "$archive" -C "$(dirname "$COMPARE_OUT_DIR")" "$(basename "$COMPARE_OUT_DIR")"
cp "$archive" "$RESULTS_DIR/latest_results.tar.gz"
printf 'Result archive: %s\n' "$archive"
