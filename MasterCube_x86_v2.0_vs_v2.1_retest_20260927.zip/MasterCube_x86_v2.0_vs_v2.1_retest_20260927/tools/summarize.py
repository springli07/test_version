#!/usr/bin/env python3
"""Produce the same eight-table report on x86-64 and native AArch64."""

import csv
import math
import os
import platform
import statistics
import subprocess
import sys
from pathlib import Path


RUNS = ("old_1", "new_1", "new_2", "old_2")
DIGESTS = (512, 768, 1024)
LENGTHS = (32, 128, 512, 1024, 4096, 8192, 16384, 65536)
IMPLEMENTATIONS = {
    "x86-64": (
        ("x86_64_reference", "Reference"),
        ("x86_64_performance_optimized", "AVX2 performance"),
        ("x86_64_resource_optimized", "AVX2 resource"),
        ("x86_64_avx512", "AVX512"),
    ),
    "ARM": (
        ("arm64_reference", "Reference"),
        ("arm64_performance_optimized", "ARM performance"),
        ("arm64_resource_optimized", "ARM resource"),
    ),
}
FIELDS = ("implementation", "algorithm") + tuple(f"{length}B" for length in LENGTHS)


def write_csv(path, fields, rows):
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def read_run(root, run, seconds):
    path = root / run / "summary" / "combined_raw.csv"
    with path.open(newline="", encoding="utf-8") as handle:
        raw_rows = list(csv.DictReader(handle))
    result = {}
    for row in raw_rows:
        key = (row["label"], int(row["digest_bits"]), int(row["msg_bytes"]))
        if key in result:
            raise ValueError(f"Duplicate measurement in {run}: {key}")
        label, digest, length = key
        if digest not in DIGESTS or length not in LENGTHS:
            raise ValueError(f"Unexpected digest or length in {run}: {key}")
        iterations = int(row["iterations"])
        elapsed = float(row["elapsed_seconds"])
        if iterations <= 0 or elapsed < seconds * 0.95 or elapsed <= 0:
            raise ValueError(f"Invalid iterations/elapsed in {run}: {key}")
        total_bytes = iterations * length
        cycles = row.get("cycles", "")
        cycle_count = int(cycles) if cycles else None
        if cycle_count is not None and cycle_count <= 0:
            raise ValueError(f"Invalid CPU cycle count in {run}: {key}")
        point = {
            "label": label,
            "digest": digest,
            "length": length,
            "iterations": iterations,
            "elapsed": elapsed,
            "cycles": cycle_count,
            "cpb": cycle_count / total_bytes if cycle_count is not None else None,
            "ns": elapsed * 1e9 / total_bytes,
            "mib": total_bytes / elapsed / 1048576.0,
            "fingerprint": row.get("digest_fingerprint", ""),
        }
        reported_cpb = row.get("cycles_per_byte", "")
        if reported_cpb and abs(float(reported_cpb) - point["cpb"]) > 0.00001:
            raise ValueError(f"Raw cycles/byte does not match cycles / bytes in {run}: {key}")
        result[key] = point
    if not result:
        raise ValueError(f"Empty benchmark run: {run}")
    return result


def display_table(title, rows):
    widths = [max(len(field), *(len(row[field]) for row in rows)) for field in FIELDS]
    print(f"\n{title}")
    print("  ".join(field.ljust(width) for field, width in zip(FIELDS, widths)))
    for row in rows:
        print("  ".join(row[field].ljust(width) for field, width in zip(FIELDS, widths)))
    lines = ["| " + " | ".join(FIELDS) + " |",
             "| " + " | ".join("---" for _ in FIELDS) + " |"]
    lines.extend("| " + " | ".join(row[field] for field in FIELDS) + " |" for row in rows)
    return "## " + title + "\n\n" + "\n".join(lines)


def wide_rows(metrics, implementations, field, fmt):
    rows = []
    for label, name in implementations:
        for digest in DIGESTS:
            rec = {"implementation": name, "algorithm": f"MasterCube-{digest}"}
            for length in LENGTHS:
                point = metrics.get((label, digest, length))
                value = point[field] if point is not None else None
                rec[f"{length}B"] = fmt(value) if value is not None else ""
            rows.append(rec)
    return rows


def percent(old, new):
    return (new / old - 1.0) * 100.0 if old is not None and new is not None else None


def mean_optional(points, field):
    values = [point[field] for point in points]
    return statistics.mean(values) if all(value is not None for value in values) else None


def geomean_change(metrics, label, field):
    ratios = []
    for digest in DIGESTS:
        for length in LENGTHS:
            point = metrics.get((label, digest, length))
            if point is None or point[f"old_{field}"] is None or point[f"new_{field}"] is None:
                return None
            ratios.append(point[f"new_{field}"] / point[f"old_{field}"])
    return math.expm1(statistics.mean(math.log(ratio) for ratio in ratios)) * 100.0


def host_model():
    cpuinfo = Path("/proc/cpuinfo")
    if cpuinfo.exists():
        for line in cpuinfo.read_text(errors="replace").splitlines():
            if line.startswith(("model name", "Model name")):
                return line.split(":", 1)[1].strip()
    try:
        for line in subprocess.check_output(["lscpu"], universal_newlines=True).splitlines():
            if line.startswith("Model name:"):
                return line.split(":", 1)[1].strip()
    except (OSError, subprocess.CalledProcessError):
        pass
    return platform.processor() or "unknown"


def check_fingerprints(runs, labels):
    sample = next(iter(runs["old_1"].values()))
    if not sample["fingerprint"]:
        return None, None
    reference = "arm64_reference"
    if reference not in labels:
        raise ValueError("Fingerprint validation requires an ARM reference implementation")
    changed = 0
    for digest in DIGESTS:
        for length in LENGTHS:
            key = (reference, digest, length)
            old_fingerprint = runs["old_1"][key]["fingerprint"]
            new_fingerprint = runs["new_1"][key]["fingerprint"]
            changed += old_fingerprint != new_fingerprint
            for run in RUNS:
                expected = old_fingerprint if run.startswith("old") else new_fingerprint
                for label in labels:
                    if runs[run][(label, digest, length)]["fingerprint"] != expected:
                        raise ValueError(f"Inconsistent digest fingerprint: {run} {label} {digest} {length}")
    return changed, len(DIGESTS) * len(LENGTHS)


def main():
    if len(sys.argv) != 4:
        raise SystemExit("usage: summarize.py <run-dir> <seconds-per-point> <pin-cpu>")
    root = Path(sys.argv[1]).resolve()
    seconds = float(sys.argv[2])
    pin_cpu = sys.argv[3]
    runs = {run: read_run(root, run, seconds) for run in RUNS}
    keys = set(runs["old_1"])
    if any(set(run) != keys for run in runs.values()):
        raise ValueError("The four runs have different point sets")
    labels = {label for label, _, _ in keys}
    if all(label.startswith("x86_64_") for label in labels):
        architecture = "x86-64"
    elif all(label.startswith("arm64_") for label in labels):
        architecture = "ARM"
    else:
        raise ValueError(f"Mixed or unknown architecture labels: {labels}")
    implementations = IMPLEMENTATIONS[architecture]
    known = {label for label, _ in implementations}
    if ("x86_64_reference" if architecture == "x86-64" else "arm64_reference") not in labels:
        raise ValueError("Reference implementation is missing")
    if labels - known or (architecture == "ARM" and labels != known):
        raise ValueError(f"Unexpected or missing implementation labels: {labels}")
    for label in labels:
        expected = {(label, digest, length) for digest in DIGESTS for length in LENGTHS}
        if {key for key in keys if key[0] == label} != expected:
            raise ValueError(f"Incomplete 24-point grid: {label}")

    changed_fingerprints, fingerprint_total = check_fingerprints(runs, labels)
    metrics = {}
    detailed = []
    for label, digest, length in sorted(keys):
        key = (label, digest, length)
        points = {run: runs[run][key] for run in RUNS}
        old = [points["old_1"], points["old_2"]]
        new = [points["new_1"], points["new_2"]]
        record = {}
        for field in ("cpb", "ns", "mib"):
            record[f"old_{field}"] = mean_optional(old, field)
            record[f"new_{field}"] = mean_optional(new, field)
            if field != "mib":
                record[f"{field}_change_pct"] = percent(record[f"old_{field}"], record[f"new_{field}"])
        metrics[key] = record
        item = {"implementation": label, "digest_bits": digest, "msg_bytes": length}
        for run in RUNS:
            item[f"{run}_cycles_per_byte"] = f"{points[run]['cpb']:.6f}" if points[run]["cpb"] is not None else ""
            item[f"{run}_ns_per_byte"] = f"{points[run]['ns']:.6f}"
            item[f"{run}_throughput_mib_s"] = f"{points[run]['mib']:.2f}"
        for field, output_name in (("cpb", "cycles_per_byte"), ("ns", "ns_per_byte"),
                                   ("mib", "throughput_mib_s")):
            precision = 2 if field == "mib" else 6
            for version in ("old", "new"):
                value = record[f"{version}_{field}"]
                item[f"{version}_mean_{output_name}"] = f"{value:.{precision}f}" if value is not None else ""
        for field, name in (("cpb", "cycles"), ("ns", "time")):
            value = record[f"{field}_change_pct"]
            item[f"new_vs_old_{name}_pct"] = f"{value:+.2f}" if value is not None else ""
        item["old_digest_fingerprint"] = points["old_1"]["fingerprint"]
        item["new_digest_fingerprint"] = points["new_1"]["fingerprint"]
        detailed.append(item)

    summary = root / "summary"
    summary.mkdir(exist_ok=True)
    write_csv(summary / "detailed_comparison.csv", list(detailed[0]), detailed)
    tables = (
        ("v2.0 CPU cycles/byte", "old_cycles_per_byte.csv", "old_cpb", lambda n: f"{n:.6f}"),
        ("v2.1 CPU cycles/byte", "new_cycles_per_byte.csv", "new_cpb", lambda n: f"{n:.6f}"),
        ("v2.1 vs v2.0 CPU cycles (%)", "cycles_difference_percent.csv", "cpb_change_pct", lambda n: f"{n:+.2f}"),
        ("v2.0 time (ns/byte)", "old_ns_per_byte.csv", "old_ns", lambda n: f"{n:.6f}"),
        ("v2.1 time (ns/byte)", "new_ns_per_byte.csv", "new_ns", lambda n: f"{n:.6f}"),
        ("v2.1 vs v2.0 time (%)", "time_difference_percent.csv", "ns_change_pct", lambda n: f"{n:+.2f}"),
        ("v2.0 throughput (MiB/s)", "old_throughput_mib_s.csv", "old_mib", lambda n: f"{n:.2f}"),
        ("v2.1 throughput (MiB/s)", "new_throughput_mib_s.csv", "new_mib", lambda n: f"{n:.2f}"),
    )
    rendered = []
    for title, filename, field, fmt in tables:
        rows = wide_rows(metrics, implementations, field, fmt)
        write_csv(summary / filename, FIELDS, rows)
        rendered.append(display_table(title, rows))

    cc = os.environ.get("CC", "gcc")
    compiler = subprocess.check_output([cc, "--version"], universal_newlines=True).splitlines()[0]
    cycle_pairs = sum(record["cpb_change_pct"] is not None for record in metrics.values())
    geomeans = []
    for label, name in implementations:
        cycles = geomean_change(metrics, label, "cpb")
        time = geomean_change(metrics, label, "ns")
        geomeans.append(f"| {name} | {cycles:+.2f}% | {time:+.2f}% |" if cycles is not None
                        else f"| {name} |  | {time:+.2f}% |" if time is not None
                        else f"| {name} |  |  |")
    counter = "RDTSC/RDTSCP" if architecture == "x86-64" else "perf_event_open CPU cycles"
    report = [
        f"# MasterCube {architecture} v2.0 vs v2.1 performance",
        "",
        f"- Host: {host_model()} ({platform.machine()})",
        f"- Compiler: {compiler}",
        f"- CPU affinity: {pin_cpu}",
        f"- Seconds per point: {seconds:g}",
        "- Run order: old_1, new_1, new_2, old_2; two measurements per version and point.",
        "- Message lengths (bytes): 32, 128, 512, 1024, 4096, 8192, 16384, 65536.",
        "- Each run-level cycles/byte = CPU cycles / (iterations * message bytes).",
        "- Each run-level ns/byte = elapsed seconds * 1e9 / (iterations * message bytes).",
        "- Each run-level MiB/s = iterations * message bytes / elapsed seconds / 1048576.",
        "- The two run-level values for each version are averaged, then change (%) = 100 * (new / old - 1).",
        "- Positive cycles/time changes mean v2.1 is slower; blank cells mean unsupported/unavailable, not zero.",
        f"- Cycle counter: {counter}; paired cycles available for {cycle_pairs}/{len(metrics)} points.",
        "- The counter mechanisms differ by architecture; do not directly compare their absolute cycle counts.",
        "- This is a performance benchmark, not a full KAT correctness check.",
    ]
    if changed_fingerprints is None:
        report.append("- Per-point digest fingerprints are not emitted by the historical x86 harness.")
    else:
        report.append(f"- v2.0/v2.1 fixed-input reference digest fingerprints differ at "
                      f"{changed_fingerprints}/{fingerprint_total} points; this is not a pure optimization comparison.")
    system_file = root / "system.txt"
    if system_file.exists():
        report.extend(("", "## Host details", "", "~~~text",
                       *system_file.read_text(encoding="utf-8", errors="replace").splitlines()[:80], "~~~"))
    report.extend(("", "## Geometric mean change across 24 points per implementation", "",
                   "| Implementation | CPU cycles/byte | Time (ns/byte) |",
                   "| --- | ---: | ---: |", *geomeans))
    for table in rendered:
        report.extend(("", table))
    report.extend(("", "All four measurements for every point are in `summary/detailed_comparison.csv`.",
                   "Raw per-run CSVs are in `old_1/`, `new_1/`, `new_2/`, and `old_2/`.", ""))
    (summary / "REPORT.md").write_text("\n".join(report), encoding="utf-8")
    print(f"\nCompared {len(metrics)} points; hardware cycle pairs: {cycle_pairs}.")
    print(f"Full report: {summary / 'REPORT.md'}")


if __name__ == "__main__":
    main()
