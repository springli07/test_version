#include "stdio.h"
#include "stdlib.h"
#include "string.h"

#include "CryptHash_AlgorithmInstance.h"
#include "drng.h"

#define SEED_LENGTH_BYTE 64
#define MSG_LEN_BITS_2_12 (4096LLU)
#define MSG_LEN_BITS_2_13 (8192LLU)
#define MSG_LEN_BITS_2_23 (8388608LLU)
#define MSG_LEN_BITS_2_33 (8589934592LLU)

#define VERIFY_SUCCESS 0
#define VERIFY_FILE_FAILED 1
#define VERIFY_MISMATCH 2
#define VERIFY_MEMORY_FAILED 3
#define VERIFY_CRYPTHASH_FAILED 4

#define ARRAY_COUNT(x) (sizeof(x) / sizeof((x)[0]))

static void trim_line(char *line)
{
    size_t n = strlen(line);
    while (n > 0 && (line[n - 1] == '\n' || line[n - 1] == '\r' ||
                     line[n - 1] == ' ' || line[n - 1] == '\t'))
    {
        line[--n] = '\0';
    }
}

static void make_filename(char *out, size_t out_size, const char *prefix, int digestbitlen)
{
    snprintf(out, out_size, "%sMasterCube-%d.txt", prefix, digestbitlen);
}

static void make_path(char *out, size_t out_size, const char *dir, const char *filename)
{
    const size_t dir_len = strlen(dir);
    const char sep = (dir_len > 0 && (dir[dir_len - 1] == '/' || dir[dir_len - 1] == '\\')) ? '\0' : '/';
    if (sep)
    {
        snprintf(out, out_size, "%s/%s", dir, filename);
    }
    else
    {
        snprintf(out, out_size, "%s%s", dir, filename);
    }
}

static void make_seed(unsigned char *seed, const char *filename)
{
    for (unsigned long long i = 0; i < SEED_LENGTH_BYTE / 8; i++)
    {
        memcpy(seed + 8 * i, filename, 8);
    }
}

static int next_digest_line(FILE *fp, char *line, size_t line_size)
{
    while (fgets(line, (int)line_size, fp))
    {
        trim_line(line);
        if (strncmp(line, "Dst = ", 6) == 0)
        {
            return 1;
        }
    }
    return 0;
}

static int compare_digest_hex(const char *filename,
                              unsigned long long case_index,
                              const char *digest_line,
                              const unsigned char *digest,
                              int digestbitlen)
{
    const char *actual = digest_line + 6;
    const int digest_bytes = digestbitlen / 8;
    char expected[2 * 128 + 1];

    if ((int)strlen(actual) != 2 * digest_bytes)
    {
        fprintf(stderr, "FAIL %s case %llu: digest hex length mismatch.\n", filename, case_index);
        return VERIFY_MISMATCH;
    }

    for (int i = 0; i < digest_bytes; i++)
    {
        snprintf(expected + 2 * i, sizeof(expected) - (size_t)(2 * i), "%02X", digest[i]);
    }
    expected[2 * digest_bytes] = '\0';

    if (strcmp(actual, expected) != 0)
    {
        fprintf(stderr, "FAIL %s case %llu: digest mismatch.\n", filename, case_index);
        return VERIFY_MISMATCH;
    }

    return VERIFY_SUCCESS;
}

static int verify_2_12(const char *vector_dir, int digestbitlen, unsigned long long *case_count)
{
    char filename[128];
    char path[1024];
    char line[2048];
    unsigned char seed[SEED_LENGTH_BYTE];
    unsigned char *message;
    unsigned char *digest;
    DRNG_ctx drng_msg_2_12;
    FILE *fp;
    unsigned long long local_cases = 0;

    make_filename(filename, sizeof(filename), "KAT_2_12_", digestbitlen);
    make_path(path, sizeof(path), vector_dir, filename);
    fp = fopen(path, "rb");
    if (!fp)
    {
        fprintf(stderr, "ERROR: cannot open %s\n", path);
        return VERIFY_FILE_FAILED;
    }

    make_seed(seed, filename);
    message = (unsigned char *)malloc(MSG_LEN_BITS_2_12 / 8);
    digest = (unsigned char *)malloc((size_t)digestbitlen / 8);
    if (!message || !digest)
    {
        free(message);
        free(digest);
        fclose(fp);
        return VERIFY_MEMORY_FAILED;
    }

    init_random_number(&drng_msg_2_12, seed, sizeof(seed));
    for (unsigned long long messagebitlen = 0; messagebitlen <= MSG_LEN_BITS_2_12; messagebitlen += 8)
    {
        memset(message, 0, MSG_LEN_BITS_2_12 / 8);
        get_random_number(&drng_msg_2_12, message, messagebitlen);
        if (CryptHash(digestbitlen, message, messagebitlen, digest))
        {
            free(message);
            free(digest);
            fclose(fp);
            return VERIFY_CRYPTHASH_FAILED;
        }
        if (!next_digest_line(fp, line, sizeof(line)))
        {
            fprintf(stderr, "FAIL %s: missing digest for case %llu.\n", filename, local_cases);
            free(message);
            free(digest);
            fclose(fp);
            return VERIFY_MISMATCH;
        }
        if (compare_digest_hex(filename, local_cases, line, digest, digestbitlen) != VERIFY_SUCCESS)
        {
            free(message);
            free(digest);
            fclose(fp);
            return VERIFY_MISMATCH;
        }
        local_cases++;
    }

    if (next_digest_line(fp, line, sizeof(line)))
    {
        fprintf(stderr, "FAIL %s: extra digest lines found.\n", filename);
        free(message);
        free(digest);
        fclose(fp);
        return VERIFY_MISMATCH;
    }

    free(message);
    free(digest);
    fclose(fp);
    *case_count += local_cases;
    printf("PASS %s cases=%llu\n", filename, local_cases);
    return VERIFY_SUCCESS;
}

static int verify_large_file(const char *vector_dir,
                             const char *prefix,
                             unsigned long long messagebitlen,
                             int digestbitlen,
                             unsigned long long *case_count)
{
    char filename[128];
    char path[1024];
    char line[2048];
    unsigned char seed[SEED_LENGTH_BYTE];
    unsigned char *message;
    unsigned char *digest;
    DRNG_ctx drng;
    FILE *fp;

    make_filename(filename, sizeof(filename), prefix, digestbitlen);
    make_path(path, sizeof(path), vector_dir, filename);
    fp = fopen(path, "rb");
    if (!fp)
    {
        fprintf(stderr, "ERROR: cannot open %s\n", path);
        return VERIFY_FILE_FAILED;
    }

    make_seed(seed, filename);
    message = (unsigned char *)malloc((size_t)(messagebitlen / 8));
    digest = (unsigned char *)malloc((size_t)digestbitlen / 8);
    if (!message || !digest)
    {
        fprintf(stderr, "ERROR: memory allocation failed for %s.\n", filename);
        free(message);
        free(digest);
        fclose(fp);
        return VERIFY_MEMORY_FAILED;
    }

    init_random_number(&drng, seed, sizeof(seed));

    for (int case_index = 0; case_index < 3; case_index++)
    {
        if (case_index == 0)
        {
            memset(message, 0, (size_t)(messagebitlen / 8));
        }
        else if (case_index == 1)
        {
            memset(message, 0xFF, (size_t)(messagebitlen / 8));
        }
        else
        {
            memset(message, 0, (size_t)(messagebitlen / 8));
            get_random_number(&drng, message, messagebitlen);
        }

        if (CryptHash(digestbitlen, message, messagebitlen, digest))
        {
            free(message);
            free(digest);
            fclose(fp);
            return VERIFY_CRYPTHASH_FAILED;
        }
        if (!next_digest_line(fp, line, sizeof(line)))
        {
            fprintf(stderr, "FAIL %s: missing digest for case %d.\n", filename, case_index);
            free(message);
            free(digest);
            fclose(fp);
            return VERIFY_MISMATCH;
        }
        if (compare_digest_hex(filename, (unsigned long long)case_index, line, digest, digestbitlen) != VERIFY_SUCCESS)
        {
            free(message);
            free(digest);
            fclose(fp);
            return VERIFY_MISMATCH;
        }
        (*case_count)++;
    }

    if (next_digest_line(fp, line, sizeof(line)))
    {
        fprintf(stderr, "FAIL %s: extra digest lines found.\n", filename);
        free(message);
        free(digest);
        fclose(fp);
        return VERIFY_MISMATCH;
    }

    free(message);
    free(digest);
    fclose(fp);
    printf("PASS %s cases=3\n", filename);
    return VERIFY_SUCCESS;
}

static int verify_loop_file(const char *vector_dir, int digestbitlen, unsigned long long *case_count)
{
    char filename[128];
    char path[1024];
    char line[2048];
    unsigned char seed[SEED_LENGTH_BYTE];
    unsigned char *message;
    unsigned char *buffer;
    unsigned char *digest;
    DRNG_ctx drng;
    FILE *fp;

    make_filename(filename, sizeof(filename), "KAT_Loop_", digestbitlen);
    make_path(path, sizeof(path), vector_dir, filename);
    fp = fopen(path, "rb");
    if (!fp)
    {
        fprintf(stderr, "ERROR: cannot open %s\n", path);
        return VERIFY_FILE_FAILED;
    }

    make_seed(seed, filename);
    message = (unsigned char *)malloc(MSG_LEN_BITS_2_13 / 8);
    buffer = (unsigned char *)malloc((size_t)digestbitlen / 8);
    digest = (unsigned char *)malloc((size_t)digestbitlen / 8);
    if (!message || !buffer || !digest)
    {
        free(message);
        free(buffer);
        free(digest);
        fclose(fp);
        return VERIFY_MEMORY_FAILED;
    }

    init_random_number(&drng, seed, sizeof(seed));
    get_random_number(&drng, message, MSG_LEN_BITS_2_13);
    if (CryptHash(digestbitlen, message, MSG_LEN_BITS_2_13, digest))
    {
        free(message);
        free(buffer);
        free(digest);
        fclose(fp);
        return VERIFY_CRYPTHASH_FAILED;
    }

    for (int i = 0; i < 1000000; i++)
    {
        memcpy(buffer, message, (size_t)digestbitlen / 8);
        memmove(message, message + digestbitlen / 8, (MSG_LEN_BITS_2_13 - (unsigned long long)digestbitlen) / 8);
        memcpy(message + (MSG_LEN_BITS_2_13 - (unsigned long long)digestbitlen) / 8, buffer, (size_t)digestbitlen / 8);
        for (int j = 0; j < digestbitlen / 8; j++)
        {
            message[j] ^= digest[j];
        }
        CryptHash(digestbitlen, message, MSG_LEN_BITS_2_13, digest);
    }

    if (!next_digest_line(fp, line, sizeof(line)))
    {
        fprintf(stderr, "FAIL %s: missing loop digest.\n", filename);
        free(message);
        free(buffer);
        free(digest);
        fclose(fp);
        return VERIFY_MISMATCH;
    }
    if (compare_digest_hex(filename, 0, line, digest, digestbitlen) != VERIFY_SUCCESS)
    {
        free(message);
        free(buffer);
        free(digest);
        fclose(fp);
        return VERIFY_MISMATCH;
    }

    free(message);
    free(buffer);
    free(digest);
    fclose(fp);
    (*case_count)++;
    printf("PASS %s cases=1\n", filename);
    return VERIFY_SUCCESS;
}

int main(int argc, char **argv)
{
    const int digestbitlen[] = DIGEST_BIT_LENGTH_SET;
    const char *vector_dir = argc >= 2 ? argv[1] : "../Test_Vectors";
    const int full = argc >= 3 && strcmp(argv[2], "full") == 0;
    unsigned long long cases = 0;

    for (size_t i = 0; i < ARRAY_COUNT(digestbitlen); i++)
    {
        int rt = verify_2_12(vector_dir, digestbitlen[i], &cases);
        if (rt != VERIFY_SUCCESS)
        {
            return rt;
        }
    }

    if (full)
    {
        for (size_t i = 0; i < ARRAY_COUNT(digestbitlen); i++)
        {
            int rt = verify_large_file(vector_dir, "KAT_2_23_", MSG_LEN_BITS_2_23, digestbitlen[i], &cases);
            if (rt != VERIFY_SUCCESS)
            {
                return rt;
            }
            rt = verify_large_file(vector_dir, "KAT_2_33_", MSG_LEN_BITS_2_33, digestbitlen[i], &cases);
            if (rt != VERIFY_SUCCESS)
            {
                return rt;
            }
            rt = verify_loop_file(vector_dir, digestbitlen[i], &cases);
            if (rt != VERIFY_SUCCESS)
            {
                return rt;
            }
        }
    }

    printf("KAT vector verification PASS mode=%s cases=%llu\n", full ? "full" : "quick", cases);
    return VERIFY_SUCCESS;
}
