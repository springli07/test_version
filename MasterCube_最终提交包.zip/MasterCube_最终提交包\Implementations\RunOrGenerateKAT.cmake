foreach(required_var IN ITEMS
    MCUBE_TEST_VECTOR_DIR
    MCUBE_VERIFY_EXE
    MCUBE_KAT_EXECUTABLES
    MCUBE_KAT_WORKDIRS
    MCUBE_KAT_FILES
    MCUBE_KAT_OUTPUTS
)
    if(NOT DEFINED ${required_var})
        message(FATAL_ERROR "${required_var} is not defined")
    endif()
endforeach()

string(REPLACE "," ";" MCUBE_KAT_EXECUTABLES "${MCUBE_KAT_EXECUTABLES}")
string(REPLACE "," ";" MCUBE_KAT_WORKDIRS "${MCUBE_KAT_WORKDIRS}")
string(REPLACE "," ";" MCUBE_KAT_FILES "${MCUBE_KAT_FILES}")
string(REPLACE "," ";" MCUBE_KAT_OUTPUTS "${MCUBE_KAT_OUTPUTS}")

list(LENGTH MCUBE_KAT_EXECUTABLES exe_count)
list(LENGTH MCUBE_KAT_WORKDIRS workdir_count)
list(LENGTH MCUBE_KAT_FILES file_count)
list(LENGTH MCUBE_KAT_OUTPUTS output_count)

if(NOT exe_count EQUAL workdir_count)
    message(FATAL_ERROR "KAT executable count does not match KAT workdir count")
endif()
if(NOT file_count EQUAL output_count)
    message(FATAL_ERROR "KAT file count does not match KAT output count")
endif()

set(MCUBE_HAS_TEST_VECTORS TRUE)
foreach(kat_file IN LISTS MCUBE_KAT_FILES)
    set(kat_path "${MCUBE_TEST_VECTOR_DIR}/${kat_file}")
    if(NOT EXISTS "${kat_path}")
        set(MCUBE_HAS_TEST_VECTORS FALSE)
    endif()
endforeach()

if(MCUBE_HAS_TEST_VECTORS)
    message(STATUS "Existing Test_Vectors found; running quick KAT vector verification.")
    execute_process(
        COMMAND "${MCUBE_VERIFY_EXE}" "${MCUBE_TEST_VECTOR_DIR}" quick
        RESULT_VARIABLE verify_result
    )
    if(NOT verify_result EQUAL 0)
        message(FATAL_ERROR "KAT vector verification failed with exit code ${verify_result}")
    endif()
else()
    message(STATUS "Complete Test_Vectors not found; generating full KAT once.")
    file(MAKE_DIRECTORY "${MCUBE_TEST_VECTOR_DIR}")

    math(EXPR exe_last_index "${exe_count} - 1")
    foreach(index RANGE 0 ${exe_last_index})
        list(GET MCUBE_KAT_EXECUTABLES ${index} kat_exe)
        list(GET MCUBE_KAT_WORKDIRS ${index} kat_workdir)
        execute_process(
            COMMAND "${kat_exe}"
            WORKING_DIRECTORY "${kat_workdir}"
            RESULT_VARIABLE kat_result
        )
        if(NOT kat_result EQUAL 0)
            message(FATAL_ERROR "Full KAT generation failed with exit code ${kat_result}")
        endif()
    endforeach()

    math(EXPR file_last_index "${file_count} - 1")
    foreach(index RANGE 0 ${file_last_index})
        list(GET MCUBE_KAT_FILES ${index} kat_file)
        list(GET MCUBE_KAT_OUTPUTS ${index} kat_output)
        execute_process(
            COMMAND "${CMAKE_COMMAND}" -E copy_if_different
                    "${kat_output}"
                    "${MCUBE_TEST_VECTOR_DIR}/${kat_file}"
            RESULT_VARIABLE copy_result
        )
        if(NOT copy_result EQUAL 0)
            message(FATAL_ERROR "Failed to copy ${kat_file} to Test_Vectors")
        endif()
    endforeach()
endif()
