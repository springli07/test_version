# MasterCube x86-64 Word Test Guide

This guide describes how to build and run the three x86-64 implementation
types used by the Word self-evaluation report:

- `Reference_Implementation`
- `Performance_Optimized_Implementation`
- `Resource_Optimized_Implementation`

All commands below are run from this package root directory.

```bash
cd /path/to/x86_64_word_test_package
```

On this workspace through WSL:

```bash
cd /mnt/d/AIcode/mastercubeopt/software/x86_64_word_test_package
```

## Requirements

- x86-64 Linux or WSL environment.
- GCC with AVX2 support for the optimized versions.
- Python 3 for summary CSV generation.
- CPU support for AVX2 when running Performance-optimized or
  Resource-optimized binaries.

Check AVX2 support:

```bash
grep -m1 -o 'avx2' /proc/cpuinfo
```

If the command prints `avx2`, the CPU supports the required AVX2 path.

## Word Compile Commands

The Word report uses the following compile commands.

### Reference

```bash
gcc -std=c99 -Wpedantic -Wall -Wextra -O2 \
  -c 64/Reference_Implementation/MasterCube-512.c \
  -o build/ref512.o
```

To compile all three Reference objects:

```bash
mkdir -p build/word_compile_check

gcc -std=c99 -Wpedantic -Wall -Wextra -O2 \
  -c 64/Reference_Implementation/MasterCube-512.c \
  -o build/word_compile_check/ref512.o
gcc -std=c99 -Wpedantic -Wall -Wextra -O2 \
  -c 64/Reference_Implementation/MasterCube-768.c \
  -o build/word_compile_check/ref768.o
gcc -std=c99 -Wpedantic -Wall -Wextra -O2 \
  -c 64/Reference_Implementation/MasterCube-1024.c \
  -o build/word_compile_check/ref1024.o
```

### Performance-Optimized

```bash
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto \
  -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra \
  -c 64/Performance_Optimized_Implementation/MasterCube-512.c \
  -o build/perf512.o
```

To compile all three Performance-optimized objects:

```bash
mkdir -p build/word_compile_check

gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto \
  -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra \
  -c 64/Performance_Optimized_Implementation/MasterCube-512.c \
  -o build/word_compile_check/perf512.o
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto \
  -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra \
  -c 64/Performance_Optimized_Implementation/MasterCube-768.c \
  -o build/word_compile_check/perf768.o
gcc -O3 -march=x86-64 -mavx2 -mtune=native -flto \
  -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra \
  -c 64/Performance_Optimized_Implementation/MasterCube-1024.c \
  -o build/word_compile_check/perf1024.o
```

### Resource-Optimized

```bash
gcc -Os -march=x86-64 -mavx2 -flto \
  -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra \
  -c 64/Resource_Optimized_Implementation/MasterCube-512.c \
  -o build/res512.o
```

To compile all three Resource-optimized objects:

```bash
mkdir -p build/word_compile_check

gcc -Os -march=x86-64 -mavx2 -flto \
  -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra \
  -c 64/Resource_Optimized_Implementation/MasterCube-512.c \
  -o build/word_compile_check/res512.o
gcc -Os -march=x86-64 -mavx2 -flto \
  -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra \
  -c 64/Resource_Optimized_Implementation/MasterCube-768.c \
  -o build/word_compile_check/res768.o
gcc -Os -march=x86-64 -mavx2 -flto \
  -fomit-frame-pointer -std=c99 -Wpedantic -Wall -Wextra \
  -c 64/Resource_Optimized_Implementation/MasterCube-1024.c \
  -o build/word_compile_check/res1024.o
```

## One-Command Word Benchmark

Use the prepared script to build all three versions and benchmark the Word
input lengths:

```bash
SECONDS_PER_POINT=3 PIN_CPU=0 ./tools/run_x86_64_word_versions.sh
```

The script benchmarks these message lengths:

```text
32B, 128B, 512B, 1024B, 4096B, 8192B, 16384B, 65536B
```

The script creates a timestamped output directory under:

```text
data/x86_64_word_versions_YYYYMMDD_HHMMSS/
```

Important output files:

- `raw/x86_64_reference.csv`
- `raw/x86_64_performance_optimized.csv`
- `raw/x86_64_resource_optimized.csv`
- `summary/combined_raw.csv`
- `summary/word_cpb_wide.csv`
- `summary/word_cpb_throughput_wide.csv`

`summary/word_cpb_wide.csv` is the table to use for Word cycles/byte data.

`summary/word_cpb_throughput_wide.csv` contains:

```text
cycles per block / MiB/s
```

## Faster Smoke Test

For a quick local check, reduce the seconds per benchmark point:

```bash
SECONDS_PER_POINT=0.2 PIN_CPU=0 \
OUT_DIR=data/x86_64_word_versions_smoke \
BUILD_DIR=build/x86_64_word_versions_smoke \
./tools/run_x86_64_word_versions.sh
```

Use the 3-second command for report data. The smoke test is only for checking
that the build and benchmark pipeline runs correctly.

## Optional Environment Variables

- `CC=gcc`: C compiler.
- `SECONDS_PER_POINT=3`: benchmark seconds per digest/length point.
- `PIN_CPU=0`: pin benchmark execution to one CPU with `taskset -c`.
- `OUT_DIR=...`: output directory for raw and summary CSV files.
- `BUILD_DIR=...`: build directory for benchmark binaries.

## Expected Output

During a normal run, the script prints build and benchmark progress:

```text
[build] x86_64_reference
[build] x86_64_performance_optimized
[build] x86_64_resource_optimized
[bench] x86_64_reference seconds=3
[bench] x86_64_performance_optimized seconds=3
[bench] x86_64_resource_optimized seconds=3
combined raw: ...
cycles/byte summary: ...
cycles per block / MiB/s summary: ...
Done: ...
```

After the run, open:

```text
summary/word_cpb_wide.csv
```

and copy the rows into the Word report table for x86-64.

## Notes

- The Reference implementation is scalar C and does not require AVX2.
- The Performance-optimized and Resource-optimized directories are x86-64 AVX2
  delivery directories.
- The Reference compile command may emit `-Wpedantic` warnings for anonymous
  structs/unions. These are inherited from the original C layout and do not
  prevent compilation.
